﻿# Prepares a private Python in .venv (no admin needed), starts the app hidden, and starts it at every Windows login.
param([switch]$Restart)
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$port = if ($env:MPVA_PORT) { $env:MPVA_PORT } else { "1780" }
$url = "http://127.0.0.1:$port"

function Test-Running {
  try { Invoke-WebRequest "$url/api/remote/ping" -UseBasicParsing -TimeoutSec 3 | Out-Null; return $true } catch { return $false }
}

if ($Restart) {
  $owner = (Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue).OwningProcess
  if ($owner) { taskkill /PID $owner /T /F | Out-Null; Start-Sleep 2 }
} elseif (Test-Running) {
  Write-Host "MP Video Assistant 已经在运行，正在打开…"
  Start-Process $url
  exit 0
}

$python = Join-Path $root ".venv\Scripts\python.exe"
$ready = $false
if (Test-Path $python) {
  & $python -c "import fastapi, uvicorn, multipart, sherpa_onnx" 2>$null
  $ready = $LASTEXITCODE -eq 0
}

if (-not $ready) {
  Write-Host ""
  Write-Host "正在准备运行环境（约 2-5 分钟，只需要一次）…"
  $uv = (Get-Command uv -ErrorAction SilentlyContinue).Source
  if (-not $uv) { $uv = Join-Path $env:USERPROFILE ".local\bin\uv.exe" }
  if (-not (Test-Path $uv)) {
    Write-Host "· 下载安装工具"
    Invoke-RestMethod https://astral.sh/uv/install.ps1 | Invoke-Expression
    $uv = Join-Path $env:USERPROFILE ".local\bin\uv.exe"
  }
  if (-not (Test-Path $python)) {
    Write-Host "· 准备 Python"
    & $uv venv .venv --python 3.12
    if ($LASTEXITCODE -ne 0) { throw "Python 准备失败" }
  }
  Write-Host "· 安装组件"
  & $uv pip install --python $python -r requirements.txt
  if ($LASTEXITCODE -ne 0) { throw "组件安装失败，请检查网络后再试一次" }
}

New-Item -ItemType Directory -Force (Join-Path $root "data\mpva") | Out-Null
$launcher = Join-Path ([Environment]::GetFolderPath("Startup")) "MP Video Assistant.vbs"
$vbs = @"
Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = "$root"
sh.Run "cmd /c set PYTHONIOENCODING=utf-8&& .venv\Scripts\python.exe -m mpva > data\mpva\server.log 2>&1", 0, False
"@
[IO.File]::WriteAllText($launcher, $vbs, [Text.Encoding]::Unicode)
Start-Process wscript.exe -ArgumentList "`"$launcher`""

Write-Host "· 正在启动"
for ($i = 0; $i -lt 60 -and -not (Test-Running); $i++) { Start-Sleep 1 }
if (-not (Test-Running)) { throw "启动失败，请查看 $root\data\mpva\server.log" }
Write-Host ""
Write-Host "准备好了！浏览器会打开制作页面。以后开机会自动运行，这个窗口可以关掉。"
Start-Process $url
