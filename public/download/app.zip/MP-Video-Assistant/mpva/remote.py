"""Use this computer's assistant from the website: a password gate plus a Cloudflare quick tunnel.

The tunnel address changes on every start, so it is published to the website repo as public/tunnel.json.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import subprocess
import threading
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from mpva import autopilot
from mpva.paths import DATA, TOOLS

CLOUDFLARED_URL = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
TUNNEL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")
SITE_ORIGINS = ["https://takeadayoff.co.nz", "https://www.takeadayoff.co.nz"]

_state: dict = {"url": "", "error": "", "proc": None}


def password() -> str:
    return (os.environ.get("MPVA_REMOTE_PASSWORD") or "").strip()


def enabled() -> bool:
    return bool(password())


def _secret() -> str:
    path = DATA / "remote_secret"
    if not path.is_file():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(secrets.token_hex(32), encoding="utf-8")
    return path.read_text(encoding="utf-8").strip()


def token() -> str:
    return hashlib.sha256(f"{password()}:{_secret()}".encode("utf-8")).hexdigest()


def login(value: str) -> str | None:
    if enabled() and hmac.compare_digest(value.strip(), password()):
        return token()
    return None


def authorized(value: str) -> bool:
    return enabled() and bool(value) and hmac.compare_digest(value, token())


def is_remote(headers, port: int) -> bool:
    if headers.get("cf-connecting-ip"):
        return True
    host = (headers.get("host") or "").lower()
    return host not in {f"127.0.0.1:{port}", f"localhost:{port}"}


def status() -> dict:
    return {"url": _state["url"], "error": _state["error"]}


def start(port: int) -> None:
    if not enabled():
        return
    threading.Thread(target=_run, args=(port,), daemon=True).start()


def stop() -> None:
    proc = _state.get("proc")
    if proc and proc.poll() is None:
        autopilot._kill(proc)


def _cloudflared() -> Path:
    found = shutil.which("cloudflared", path=autopilot._search_path())
    if found:
        return Path(found)
    dest = TOOLS / "cloudflared.exe"
    if not dest.is_file():
        dest.parent.mkdir(parents=True, exist_ok=True)
        part = dest.with_suffix(".part")
        urllib.request.urlretrieve(CLOUDFLARED_URL, part)
        part.replace(dest)
    return dest


def _run(port: int) -> None:
    try:
        exe = _cloudflared()
        proc = subprocess.Popen(
            [str(exe), "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{port}"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        _state["proc"] = proc
        autopilot._bind_to_server(proc)
        for line in proc.stderr:
            match = TUNNEL_RE.search(line)
            if match and match.group(0) != _state["url"]:
                _state["url"] = match.group(0)
                print(f"Website access: {_state['url']}")
                threading.Thread(target=publish, args=(_state["url"],), daemon=True).start()
        _state["error"] = "tunnel stopped"
    except Exception as exc:  # noqa: BLE001 — show any tunnel failure, the local app still works
        _state["error"] = str(exc)[:300]
        print(f"Website access failed: {exc}")


def publish(url: str) -> None:
    repo = Path(os.environ.get("MPVA_SITE_REPO") or "")
    if not (repo / ".git").is_dir():
        return
    target = repo / "public" / "tunnel.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps({"url": url, "at": datetime.now(timezone.utc).isoformat(timespec="seconds")}),
        encoding="utf-8",
    )
    for args in (
        ["add", "public/tunnel.json"],
        ["commit", "-m", "Update studio address", "--", "public/tunnel.json"],
        ["push", "origin", "HEAD"],
    ):
        result = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True, timeout=120)
        if result.returncode != 0 and args[0] != "commit":
            _state["error"] = f"publish failed: {(result.stderr or result.stdout)[-200:]}"
            print(f"Website address publish failed: {result.stderr.strip()[-200:]}")
            return
    print("Website address published.")
