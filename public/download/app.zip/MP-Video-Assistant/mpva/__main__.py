import sys
import threading
import webbrowser

from mpva.envfile import load_env
from mpva.paths import ROOT
from mpva.web import PORT, create_app

URL = f"http://127.0.0.1:{PORT}"


def main() -> None:
    load_env(ROOT)
    import uvicorn

    from mpva import autopilot, envcheck, remote

    print(f"MP Video Assistant  {URL}")
    app = create_app()
    stopped = autopilot.stop_leftovers()
    if stopped:
        print(f"Stopped {stopped} AI agent run(s) left from the previous session.")
    envcheck.warm()
    remote.start(PORT)
    if "--open" in sys.argv:
        threading.Timer(2.5, webbrowser.open, [URL]).start()
    try:
        uvicorn.run(app, host="127.0.0.1", port=PORT, log_level="info")
    finally:
        remote.stop()
        autopilot.stop_all()


if __name__ == "__main__":
    main()
