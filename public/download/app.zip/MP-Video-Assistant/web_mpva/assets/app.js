const I18N = {
  zh: {
    heroTitle: "把口播视频，变成好看的动态短片",
    heroSub: "拖进原片就行。人物、标题、动画和音效一次做好，你说的每一句话都原样保留。",
    drop: "把视频拖到这里",
    dropSub: "或点击选择文件 · 手机拍的就可以",
    repick: "换一个",
    refLabel: "有喜欢的视频风格？传上来照着做（可选）",
    refAdd: "添加风格视频或截图",
    refHelp: "最多 3 个。只学它的排版、配色、节奏和转场，不会搬用里面的内容。",
    refTagVideo: "风格视频",
    refTagImage: "风格截图",
    wishLabel: "想要什么感觉？（可以不选）",
    wishPh: "也可以直接写，比如：竖屏，数字要醒目，整体干净一点。",
    chips: [
      ["竖屏短视频", "竖屏 9:16"],
      ["横屏", "横屏 16:9"],
      ["简洁大方", "整体简洁大方，留白多"],
      ["活泼可爱", "风格活泼可爱，色彩明快"],
      ["科技感", "有科技感，线条和光效"],
      ["温暖亲切", "温暖亲切，柔和配色"],
      ["正式稳重", "正式稳重，适合官方发布"],
      ["数字醒目", "讲到数字时放大强调"],
    ],
    start: "开始制作",
    startHelp: "视频只在这台电脑上处理，不会上传到别处。",
    needSetup: "先完成上面的准备，就可以开始了。",
    startHelpRemote: "视频只传给制作电脑处理，不会公开。",
    remoteNotReady: "制作电脑还在准备中，请稍后再来，或联系管理员。",
    uploading: "正在读取视频…",
    setupTitle: "第一次使用，先准备一下",
    setupSub: "只需要一次，大约 10 分钟。准备好以后每次都能直接用。",
    setupGo: "一键准备",
    setupBusy: "正在准备…可以先去忙别的",
    setupItems: { tools: "视频制作工具", speech: "语音识别（听懂你说的话）", extras: "字体与画面工具", agent: "AI 助手" },
    setupLogin: "需要登录一次",
    setupNote: "Windows 弹出“是否允许更改”时请点「是」。",
    setupFail: "准备没完成：",
    login: "登录 AI 助手",
    loginHint: "已打开登录页面，用你的账号确认后回到这里，会自动刷新。",
    f1t: "人物自动抠出",
    f1: "不用绿幕，人物干净地放进设计好的画面。",
    f2t: "画面跟着内容动",
    f2: "讲到数字、地名、重点时，画面自动配合出现。",
    f3t: "原话一字不改",
    f3: "只做包装，不剪改你说的话，发布前你说了算。",
    loginTitle: "请输入访问密码",
    loginSub: "内测中，输入密码后就能开始制作。",
    loginGo: "进入",
    loginNeeded: "请先输入访问密码",
    loginWrong: "密码不对，再试一次",
    agentTitle: "AI 助手（必须装一个才能制作）",
    agentSub: "任选一个安装并登录即可，装好后会显示「可以用 ✓」。",
    agentNone: "还没有可用的 AI 助手，请先在下面装一个，否则无法开始制作。",
    agentHints: { codex: "ChatGPT 账户登录即可", cursor: "Cursor 账户登录即可", claude: "Claude 账户登录即可" },
    engine: "用哪个来制作",
    install: "一键安装",
    loginBtn: "去登录",
    needLogin: "已安装，需要登录",
    ready: "可以用 ✓",
    missing: "未安装",
    installing: "安装中…",
    working: "正在为你制作",
    queuedTitle: "排队中，马上轮到你",
    listening: "正在听懂你的内容…",
    stages: ["上传", "听懂内容", "抠出人物", "设计画面", "合成检查", "完成"],
    tips: [
      "正在仔细看你的视频，找到最适合放标题的地方…",
      "人物会被干净地抠出来，不需要绿幕。",
      "每个画面都会对着你说的话来设计。",
      "做完会自己检查一遍画面和声音。",
      "好作品值得等一等，先去喝杯茶吧 ☕",
      "你说的每一句话都会原样保留。",
    ],
    etaLeft: (m, at) => `大约还要 <b>${m} 分钟</b> <em>· 预计 ${at} 左右完成</em>`,
    etaAlmost: "快好了，正在做最后的检查…",
    etaQueue: (n) => `前面还有 ${n} 部视频在做，轮到你会自动开始，不用重复点。`,
    restTitle: "可以先去休息，晚点回来看",
    restBody: "做好后会自动出现在这里。期间可以正常用电脑做别的事，只要不关闭、不刷新这个窗口就行。",
    startFilm: "开始制作",
    retry: "重新制作",
    stop: "停止制作",
    stopConfirm: "确定要停止吗？已经做的部分不会保留。",
    stopped: "已停止。需要的话可以重新制作。",
    failed: "这次没做成：",
    notReady: "还差一步准备，回首页完成后再来点「开始制作」。",
    done: "做好了！",
    doneSub: "先完整看一遍，满意再下载发布。",
    download: "下载视频",
    again: "再做一个",
    redoLabel: "想换个感觉重做？",
    redo: "按这个要求重做",
    redoConfirm: "重做会覆盖现在这版，确定吗？",
    titleWorking: (p) => `制作中 ${p}% · MP Video Assistant`,
    titleDone: "✓ 做好了 · MP Video Assistant",
    notify: "你的视频做好了，回来看看吧！",
  },
  en: {
    heroTitle: "Turn a talking video into a polished motion short",
    heroSub: "Just drop in the original. Cut-out, titles, animation and sound are done for you, and every word you said stays exactly as it was.",
    drop: "Drop your video here",
    dropSub: "or click to choose · phone footage is fine",
    repick: "Change",
    refLabel: "Like a certain style? Upload it and we will match it (optional)",
    refAdd: "Add a style video or screenshot",
    refHelp: "Up to 3. We learn the layout, colours, pacing and transitions, never the content.",
    refTagVideo: "Style video",
    refTagImage: "Screenshot",
    wishLabel: "What feel do you want? (optional)",
    wishPh: "Or write it: vertical, make numbers stand out, keep it clean.",
    chips: [
      ["Vertical", "vertical 9:16"],
      ["Landscape", "landscape 16:9"],
      ["Clean", "clean and minimal, lots of space"],
      ["Playful", "playful, bright colours"],
      ["Tech", "tech feel, lines and light"],
      ["Warm", "warm and friendly, soft colours"],
      ["Formal", "formal and steady, for official release"],
      ["Big numbers", "emphasise numbers when mentioned"],
    ],
    start: "Start",
    startHelp: "Your video is processed on this computer only.",
    needSetup: "Finish the one-time setup above first.",
    startHelpRemote: "Your video goes only to the studio computer and is never made public.",
    remoteNotReady: "The studio computer is still getting ready. Please try again later or contact the admin.",
    uploading: "Reading your video…",
    setupTitle: "First time? Quick one-time setup",
    setupSub: "About 10 minutes, only once. After that it is ready every time.",
    setupGo: "Set up",
    setupBusy: "Setting up… feel free to do something else",
    setupItems: { tools: "Video tools", speech: "Speech recognition", extras: "Font and image tools", agent: "AI assistant" },
    setupLogin: "sign in once",
    setupNote: "If Windows asks to allow changes, click Yes.",
    setupFail: "Setup did not finish: ",
    login: "Sign in to AI assistant",
    loginHint: "A sign-in page opened. Confirm with your account, then come back here.",
    f1t: "Automatic cut-out",
    f1: "No green screen. You are placed cleanly into a designed scene.",
    f2t: "Visuals follow your words",
    f2: "Numbers, places and key points appear right when you say them.",
    f3t: "Your words, unchanged",
    f3: "We only design around your speech. You approve before publishing.",
    loginTitle: "Enter the access password",
    loginSub: "Private beta. Enter the password to start making videos.",
    loginGo: "Enter",
    loginNeeded: "Please enter the access password first",
    loginWrong: "Wrong password, try again",
    agentTitle: "AI assistant (you need one to make videos)",
    agentSub: "Install and sign in to any one of them. It shows “Ready ✓” when done.",
    agentNone: "No AI assistant is ready yet. Install one below, otherwise videos can’t be made.",
    agentHints: { codex: "just sign in with your ChatGPT account", cursor: "just sign in with your Cursor account", claude: "just sign in with your Claude account" },
    engine: "Use this one",
    install: "Install",
    loginBtn: "Sign in",
    needLogin: "Installed, needs sign-in",
    ready: "Ready ✓",
    missing: "Not installed",
    installing: "Installing…",
    working: "Making your video",
    queuedTitle: "In line, almost your turn",
    listening: "Listening to your video…",
    stages: ["Upload", "Listen", "Cut-out", "Design", "Check", "Done"],
    tips: [
      "Finding the best places for titles…",
      "You will be cut out cleanly, no green screen needed.",
      "Every scene is designed around what you say.",
      "Picture and sound get checked before it is done.",
      "Good work takes a little time. Grab a tea ☕",
      "Every word you said stays exactly as it was.",
    ],
    etaLeft: (m, at) => `About <b>${m} min</b> left <em>· ready around ${at}</em>`,
    etaAlmost: "Almost there, doing the final checks…",
    etaQueue: (n) => `${n} video(s) ahead. Yours starts automatically.`,
    restTitle: "Feel free to step away",
    restBody: "It will appear here when ready. Use your computer as normal, just keep this window open and do not refresh it.",
    startFilm: "Start",
    retry: "Try again",
    stop: "Stop",
    stopConfirm: "Stop now? Progress will be lost.",
    stopped: "Stopped. You can start again any time.",
    failed: "It did not finish: ",
    notReady: "Setup is not finished. Complete it on the home page, then press Start.",
    done: "It's ready!",
    doneSub: "Watch it through once, then download and publish.",
    download: "Download video",
    again: "Make another",
    redoLabel: "Want a different feel?",
    redo: "Redo with this",
    redoConfirm: "Redoing replaces this version. Continue?",
    titleWorking: (p) => `Making ${p}% · MP Video Assistant`,
    titleDone: "✓ Ready · MP Video Assistant",
    notify: "Your video is ready!",
  },
};

const $ = (id) => document.getElementById(id);
const state = { job: null, ui: "zh", poll: null, file: null, refs: [], agents: [], agentDefault: null, env: null, tip: 0, notified: false };
const VIDEO = /\.(mp4|mov|mkv|m4v|webm|avi)$/i;
const STORE = "mpva.job";

function t(key) {
  return (I18N[state.ui] || I18N.zh)[key];
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
}

const REMOTE = !["127.0.0.1", "localhost"].includes(location.hostname);
const KEY_STORE = "mpva.key";
const CHUNK = 32 * 1024 * 1024;

function withKey(url) {
  const key = localStorage.getItem(KEY_STORE);
  if (!key || !url) return url;
  return `${url}${url.includes("?") ? "&" : "?"}k=${encodeURIComponent(key)}`;
}

async function api(path, options = {}) {
  const key = localStorage.getItem(KEY_STORE);
  if (key) options.headers = { ...(options.headers || {}), "X-MPVA-Key": key };
  const res = await fetch(path, options);
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && data.detail === "login") {
    showLogin();
    throw new Error(t("loginNeeded"));
  }
  if (!res.ok) throw new Error(data.detail || data.error || res.statusText);
  return data;
}

async function stageFile(file, onProgress) {
  const uid = Array.from(crypto.getRandomValues(new Uint8Array(12)), (b) => b.toString(16).padStart(2, "0")).join("");
  for (let offset = 0; offset < file.size; offset += CHUNK) {
    await api(`/api/uploads/${uid}?offset=${offset}`, { method: "PUT", body: file.slice(offset, offset + CHUNK) });
    if (onProgress) onProgress(Math.min(1, (offset + CHUNK) / file.size));
  }
  return `${uid}|${file.name}`;
}

function showLogin() {
  $("login").hidden = false;
  $("login-pw").focus();
}

async function submitLogin(e) {
  e.preventDefault();
  $("login-err").textContent = "";
  try {
    const res = await fetch("/api/remote/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: $("login-pw").value }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.key) throw new Error(t("loginWrong"));
    localStorage.setItem(KEY_STORE, data.key);
    $("login").hidden = true;
    loadAgents();
    loadEnv();
    restore();
  } catch (err) {
    $("login-err").textContent = err.message;
  }
}

function show(id) {
  ["step-upload", "step-work", "step-ready"].forEach((step) => ($(step).hidden = step !== id));
}

function applyUi() {
  document.documentElement.lang = state.ui === "zh" ? "zh-CN" : "en";
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const value = t(el.dataset.i18n);
    if (typeof value === "string") el.textContent = value;
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => (el.placeholder = t(el.dataset.i18nPlaceholder)));
  document.querySelectorAll("[data-ui]").forEach((el) => el.classList.toggle("on", el.dataset.ui === state.ui));
  renderChips();
  renderRefs();
  renderSetup();
  if (state.job) renderJob();
}

/* ---------- 首页 ---------- */

function renderChips() {
  const picked = new Set([...document.querySelectorAll(".chip.on")].map((el) => el.dataset.i));
  $("chips").innerHTML = t("chips")
    .map(([label], i) => `<button type="button" class="chip${picked.has(String(i)) ? " on" : ""}" data-i="${i}">${escapeHtml(label)}</button>`)
    .join("");
}

function briefText() {
  const chips = [...document.querySelectorAll(".chip.on")].map((el) => t("chips")[Number(el.dataset.i)][1]);
  return [...chips, ($("brief").value || "").trim()].filter(Boolean).join("；");
}

function pickFile(file) {
  if (!file || !VIDEO.test(file.name) || file.size < 32) return;
  state.file = file;
  $("picked-name").textContent = file.name;
  $("picked-size").textContent = `${(file.size / 1048576).toFixed(1)} MB`;
  $("picked").hidden = false;
  $("drop").hidden = true;
  updateStart();
}

const REF = /\.(mp4|mov|mkv|m4v|webm|avi|jpg|jpeg|png|webp|gif|bmp)$/i;

function addRefs(files) {
  for (const file of files) {
    if (state.refs.length >= 3) break;
    if (!file || !REF.test(file.name) || file.size < 32) continue;
    if (state.refs.some((r) => r.file.name === file.name && r.file.size === file.size)) continue;
    state.refs.push({ file, url: URL.createObjectURL(file), video: VIDEO.test(file.name) });
  }
  renderRefs();
}

function renderRefs() {
  const items = state.refs
    .map(
      (r, i) => `<div class="ref-item">
        ${r.video ? `<video src="${r.url}#t=0.5" muted playsinline preload="metadata"></video>` : `<img src="${r.url}" alt="" />`}
        <span class="tag">${r.video ? t("refTagVideo") : t("refTagImage")}</span>
        <button type="button" class="x" data-ref="${i}" aria-label="remove">×</button>
      </div>`
    )
    .join("");
  const add = $("ref-add");
  $("ref-grid").innerHTML = items;
  $("ref-grid").appendChild(add);
  add.hidden = state.refs.length >= 3;
}

function isReady() {
  const envOk = state.env ? state.env.ok : true;
  const agentOk = state.agents.some((a) => a.available && a.signed_in !== false);
  return envOk && agentOk;
}

function checked() {
  return Boolean(state.env && state.agentsLoaded);
}

function updateStart() {
  const ready = isReady();
  $("btn-generate").disabled = !state.file || !ready || !checked();
  const help = REMOTE ? t("startHelpRemote") : t("startHelp");
  $("upload-help").textContent = ready || !checked() ? help : REMOTE ? t("remoteNotReady") : t("needSetup");
}

async function loadAgents() {
  try {
    const data = await api("/api/agents");
    state.agents = data.runners || [];
    state.agentDefault = data.default;
  } catch {
    state.agents = [];
  }
  state.agentsLoaded = true;
  renderSetup();
  if (state.agents.some((a) => a.installing)) setTimeout(loadAgents, 3000);
}

async function loadEnv(refresh = false) {
  try {
    state.env = await api(`/api/env${refresh ? "?refresh=1" : ""}`);
  } catch {
    return;
  }
  renderSetup();
  if (state.env.fixing) setTimeout(() => loadEnv(), 4000);
  else if (state.envWasFixing) loadAgents();
  state.envWasFixing = state.env.fixing;
}

function renderSetup() {
  const env = state.env;
  const usable = state.agents.filter((a) => a.available);
  const signedIn = usable.some((a) => a.signed_in !== false);
  if (env) {
    const item = (key) => (env.items.find((i) => i.key === key) || {}).ok;
    const tools = item("ffmpeg") && item("node") && item("motion") && item("runtime");
    const rows = [
      ["tools", tools, ["motion", "ffmpeg", "node", "runtime"].includes(env.step)],
      ["speech", item("speech"), env.step === "speech"],
      ["extras", item("python"), env.step === "python"],
      ["agent", signedIn, env.step === "agent"],
    ];
    const names = t("setupItems");
    $("setup-list").innerHTML = rows
      .map(([key, ok, busy]) => {
        const extra = key === "agent" && usable.length && !signedIn ? ` · ${t("setupLogin")}` : "";
        return `<li class="${ok ? "ok" : busy ? "busy" : ""}"><span class="dot">${ok ? "✓" : ""}</span>${escapeHtml(names[key])}${extra}</li>`;
      })
      .join("");
    const fix = $("btn-env-fix");
    fix.disabled = env.fixing;
    fix.textContent = env.fixing ? t("setupBusy") : t("setupGo");
    fix.hidden = !env.fixing && rows.every(([key, ok]) => ok || key === "agent") && usable.length > 0;
    $("btn-login").hidden = env.fixing || !usable.length || signedIn;
    $("setup-note").textContent = env.error ? t("setupFail") + env.error : t("setupNote");
  }
  $("setup-card").hidden = REMOTE || !checked() || isReady();

  const select = $("agent-runner");
  select.innerHTML = usable.map((a) => `<option value="${escapeHtml(a.id)}">${escapeHtml(a.label)}</option>`).join("");
  if (state.agentDefault) select.value = state.agentDefault;
  const hints = t("agentHints");
  const rowsHtml = state.agents
    .filter((a) => a.install)
    .map((a) => {
      const needLogin = a.available && a.signed_in === false;
      const ok = a.available && !needLogin;
      const status = a.installing ? t("installing") : ok ? t("ready") : needLogin ? t("needLogin") : t("missing");
      let action = "";
      if (!a.available && !a.installing) action = `<button type="button" class="cta small" data-install="${escapeHtml(a.id)}">${t("install")}</button>`;
      else if (needLogin) action = `<button type="button" class="cta small" data-login="${escapeHtml(a.id)}">${t("loginBtn")}</button>`;
      const hint = hints[a.id] ? `<small>（${escapeHtml(hints[a.id])}）</small>` : "";
      const err = a.install_error ? `<em class="err">${escapeHtml(a.install_error)}</em>` : "";
      return `<div class="agent-row ${ok ? "ok" : ""}"><span class="agent-name"><b>${escapeHtml(a.label)}</b>${hint}</span><span class="state ${ok ? "good" : "warn"}">${status}</span>${action}${err}</div>`;
    })
    .join("");
  const noneReady = checked() && !signedIn;
  $("agent-setup").innerHTML = (noneReady ? `<p class="agent-alert">⚠️ ${t("agentNone")}</p>` : "") + rowsHtml;
  $("advanced").classList.toggle("alert", noneReady);
  const main = document.querySelector(".main-card");
  if (checked() && !isReady()) main.before($("setup-card"), $("advanced"));
  else main.after($("setup-card"), $("advanced"));
  $("advanced").hidden = REMOTE || state.agents.length === 0;
  updateStart();
}

async function startJob() {
  if (!state.file || !isReady()) return;
  $("btn-generate").disabled = true;
  $("upload-help").textContent = t("uploading");
  if ("Notification" in window && Notification.permission === "default") Notification.requestPermission().catch(() => {});
  const form = new FormData();
  form.append("language", "auto");
  form.append("brief", briefText());
  form.append("title", state.file.name.replace(/\.[^.]+$/, ""));
  form.append("auto_film", "1");
  form.append("agent", $("agent-runner").value || "");
  try {
    const progress = (p) => ($("upload-help").textContent = `${t("uploading")} ${Math.round(p * 100)}%`);
    if (state.file.size > CHUNK) form.append("staged", await stageFile(state.file, progress));
    else form.append("files", state.file, state.file.name);
    for (const r of state.refs) {
      if (r.file.size > CHUNK) form.append("staged_refs", await stageFile(r.file));
      else form.append("refs", r.file, r.file.name);
    }
    const job = await api("/api/jobs", { method: "POST", body: form });
    localStorage.setItem(STORE, job.id);
    state.notified = false;
    setJob(job);
    await api(`/api/jobs/${job.id}/generate`, { method: "POST" });
    pollJob(job.id);
  } catch (err) {
    $("upload-help").textContent = err.message;
    updateStart();
  }
}

/* ---------- 制作中 / 完成 ---------- */

function setJob(job) {
  state.job = job;
  renderJob();
}

function agentOf(job) {
  return (job && job.agent) || {};
}

function busy(job) {
  return ["working", "uploaded"].includes(job.status) || ["queued", "running"].includes(agentOf(job).state);
}

function filmUrl(job) {
  const clip = (job.clips || [])[0] || {};
  return withKey((clip.exports || {}).final || agentOf(job).film || "");
}

function renderJob() {
  const job = state.job;
  if (!job) return;
  const agent = agentOf(job);
  if (agent.state === "done" && filmUrl(job)) return renderDone(job);
  show("step-work");
  renderWork(job);
}

function stageIndex(job) {
  const agent = agentOf(job);
  if (["working", "uploaded"].includes(job.status)) return 1;
  if (agent.state === "running") return { cutout: 2, design: 3, finish: 4 }[agent.phase] || 2;
  return 2;
}

function renderWork(job) {
  const agent = agentOf(job);
  const now = stageIndex(job);
  $("stages").innerHTML = t("stages")
    .map((label, i) => `<li class="${i < now ? "done" : i === now ? "now" : ""}"><span class="n">${i < now ? "✓" : i + 1}</span>${escapeHtml(label)}</li>`)
    .join("");

  const queued = agent.state === "queued";
  $("work-title").textContent = queued ? t("queuedTitle") : t("working");
  const stopped = job.status === "failed" || ["failed", "cancelled"].includes(agent.state) || (job.status === "review" && !agent.state);
  let error = "";
  if (job.status === "failed") error = t("failed") + (job.error || "");
  else if (agent.state === "failed") error = t("failed") + (agent.error || "");
  else if (agent.state === "cancelled") error = t("stopped");
  else if (job.status === "review" && !agent.state && !isReady()) error = t("notReady");
  $("work-error").textContent = error;

  const film = $("btn-film");
  film.hidden = !stopped;
  film.textContent = agent.state || job.status === "failed" ? t("retry") : t("startFilm");
  $("btn-stop").hidden = !busy(job) || ["working", "uploaded"].includes(job.status);
  document.querySelector(".mascot").style.opacity = stopped ? 0.45 : 1;
  document.querySelector(".rest").hidden = stopped;

  let pct = 4;
  let html = "";
  if (["working", "uploaded"].includes(job.status)) {
    html = t("listening");
    pct = 6;
  } else if (queued) {
    html = t("etaQueue")((agent.ahead || []).length || 1);
    pct = 4;
  } else if (agent.state === "running" && agent.started) {
    const total = Number(agent.estimate_min || 60);
    const elapsed = (Date.now() - Date.parse(agent.started)) / 60000;
    const left = Math.round(total - elapsed);
    pct = Math.min(96, Math.max(8, Math.round((elapsed / total) * 100)));
    if (left <= 3) html = t("etaAlmost");
    else {
      const at = new Date(Date.parse(agent.started) + total * 60000).toLocaleTimeString(state.ui === "zh" ? "zh-CN" : "en-NZ", { hour: "2-digit", minute: "2-digit" });
      html = t("etaLeft")(left, at);
    }
  }
  $("eta").hidden = stopped;
  $("eta-fill").style.width = `${pct}%`;
  $("eta-text").innerHTML = html;
  document.title = stopped ? "MP Video Assistant" : t("titleWorking")(pct);
}

function renderDone(job) {
  show("step-ready");
  const url = filmUrl(job);
  const player = $("player");
  if (player.dataset.src !== url) {
    player.innerHTML = `<video src="${escapeHtml(url)}" controls playsinline></video>`;
    player.dataset.src = url;
  }
  const link = $("btn-download");
  link.href = url;
  link.setAttribute("download", `${(job.title || "video").replace(/[\\/:*?"<>|]/g, "")}.mp4`);
  document.title = t("titleDone");
  if (!state.notified) {
    state.notified = true;
    if ("Notification" in window && Notification.permission === "granted" && document.hidden) {
      try { new Notification("MP Video Assistant", { body: t("notify") }); } catch {}
    }
  }
}

function rotateTip() {
  const tips = t("tips");
  const el = $("work-tip");
  el.style.opacity = 0;
  setTimeout(() => {
    state.tip = (state.tip + 1) % tips.length;
    el.textContent = tips[state.tip];
    el.style.opacity = 1;
  }, 400);
}

function pollJob(id) {
  if (state.poll) clearInterval(state.poll);
  state.poll = setInterval(async () => {
    try {
      const job = await api(`/api/jobs/${id}`);
      setJob(job);
      if (!busy(job)) {
        clearInterval(state.poll);
        state.poll = null;
      }
    } catch {}
  }, 3000);
}

async function act(path, body) {
  const options = { method: "POST" };
  if (body) {
    options.headers = { "Content-Type": "application/json" };
    options.body = JSON.stringify(body);
  }
  const job = await api(path, options);
  if (job && job.id) setJob(job);
  pollJob(state.job.id);
}

function resetHome() {
  localStorage.removeItem(STORE);
  if (state.poll) clearInterval(state.poll);
  state.poll = null;
  state.job = null;
  state.file = null;
  $("picked").hidden = true;
  $("drop").hidden = false;
  $("brief").value = "";
  state.refs.forEach((r) => URL.revokeObjectURL(r.url));
  state.refs = [];
  renderRefs();
  document.querySelectorAll(".chip.on").forEach((el) => el.classList.remove("on"));
  document.title = "MP Video Assistant";
  show("step-upload");
  updateStart();
}

/* ---------- 事件 ---------- */

$("drop").addEventListener("click", () => $("file").click());
$("drop").addEventListener("dragover", (e) => {
  e.preventDefault();
  $("drop").classList.add("over");
});
$("drop").addEventListener("dragleave", () => $("drop").classList.remove("over"));
$("drop").addEventListener("drop", (e) => {
  e.preventDefault();
  $("drop").classList.remove("over");
  pickFile([...(e.dataTransfer.files || [])].find((f) => VIDEO.test(f.name)));
});
document.addEventListener("dragover", (e) => e.preventDefault());
document.addEventListener("drop", (e) => {
  e.preventDefault();
  if (!$("step-upload").hidden) pickFile([...(e.dataTransfer.files || [])].find((f) => VIDEO.test(f.name)));
});
$("file").addEventListener("change", (e) => {
  pickFile(e.target.files[0]);
  e.target.value = "";
});
$("btn-repick").addEventListener("click", () => $("file").click());
$("ref-add").addEventListener("click", () => $("ref-file").click());
$("ref-file").addEventListener("change", (e) => {
  addRefs([...e.target.files]);
  e.target.value = "";
});
$("ref-grid").addEventListener("dragover", (e) => {
  e.preventDefault();
  $("ref-add").classList.add("over");
});
$("ref-grid").addEventListener("dragleave", () => $("ref-add").classList.remove("over"));
$("ref-grid").addEventListener("drop", (e) => {
  e.preventDefault();
  e.stopPropagation();
  $("ref-add").classList.remove("over");
  addRefs([...(e.dataTransfer.files || [])]);
});
$("ref-grid").addEventListener("click", (e) => {
  const x = e.target.closest("[data-ref]");
  if (!x) return;
  const [gone] = state.refs.splice(Number(x.dataset.ref), 1);
  if (gone) URL.revokeObjectURL(gone.url);
  renderRefs();
});
$("chips").addEventListener("click", (e) => {
  const chip = e.target.closest(".chip");
  if (chip) chip.classList.toggle("on");
});
$("btn-generate").addEventListener("click", startJob);
$("login-form").addEventListener("submit", submitLogin);

$("btn-env-fix").addEventListener("click", async () => {
  $("btn-env-fix").disabled = true;
  await api("/api/env/fix", { method: "POST" }).catch((err) => ($("setup-note").textContent = err.message));
  loadEnv();
});
$("btn-login").addEventListener("click", async () => {
  const target = (state.agents.find((a) => a.available && a.signed_in === false) || {}).id;
  if (!target) return;
  try {
    await api(`/api/agents/${target}/login`, { method: "POST" });
    $("setup-note").textContent = t("loginHint");
    setTimeout(loadAgents, 15000);
    setTimeout(loadAgents, 40000);
  } catch (err) {
    $("setup-note").textContent = err.message;
  }
});
$("agent-setup").addEventListener("click", async (e) => {
  const login = e.target.closest("[data-login]");
  if (login) {
    login.disabled = true;
    try {
      await api(`/api/agents/${login.dataset.login}/login`, { method: "POST" });
      $("agent-note").textContent = t("loginHint");
      setTimeout(loadAgents, 15000);
      setTimeout(loadAgents, 40000);
    } catch (err) {
      $("agent-note").textContent = err.message;
      login.disabled = false;
    }
    return;
  }
  const btn = e.target.closest("[data-install]");
  if (!btn) return;
  btn.disabled = true;
  await api(`/api/agents/${btn.dataset.install}/install`, { method: "POST" }).catch(() => {});
  loadAgents();
});

$("btn-film").addEventListener("click", async () => {
  if (!state.job) return;
  try {
    if (state.job.status === "failed") await act(`/api/jobs/${state.job.id}/regenerate`, {});
    else await act(`/api/jobs/${state.job.id}/film`, { agent: $("agent-runner").value || "" });
  } catch (err) {
    $("work-error").textContent = err.message;
  }
});
$("btn-stop").addEventListener("click", async () => {
  if (!state.job || !window.confirm(t("stopConfirm"))) return;
  await act(`/api/jobs/${state.job.id}/film/cancel`);
});
$("btn-new").addEventListener("click", resetHome);
$("btn-rebrief").addEventListener("click", async () => {
  if (!state.job || !window.confirm(t("redoConfirm"))) return;
  state.notified = false;
  show("step-work");
  await act(`/api/jobs/${state.job.id}/regenerate`, { brief: ($("ready-brief").value || "").trim() });
});

document.querySelector(".lang-switch").addEventListener("click", (e) => {
  const btn = e.target.closest("[data-ui]");
  if (!btn) return;
  state.ui = btn.dataset.ui;
  applyUi();
});

window.addEventListener("beforeunload", (e) => {
  if (state.job && busy(state.job)) {
    e.preventDefault();
    e.returnValue = "";
  }
});

async function restore() {
  const id = localStorage.getItem(STORE);
  if (!id) return;
  try {
    const job = await api(`/api/jobs/${id}`);
    setJob(job);
    if (busy(job)) pollJob(id);
  } catch {
    localStorage.removeItem(STORE);
  }
}

applyUi();
$("work-tip").textContent = t("tips")[0];
setInterval(rotateTip, 8000);
setInterval(() => state.job && !$("step-work").hidden && renderWork(state.job), 30000);
loadAgents();
loadEnv();
restore();
