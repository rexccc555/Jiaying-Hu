@echo off
chcp 65001 >nul
cd /d "%~dp0"
title MP Video Assistant
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\setup.ps1"
if errorlevel 1 (
  echo.
  echo 出了点问题，请截图这个窗口发给我们。
  pause
)
