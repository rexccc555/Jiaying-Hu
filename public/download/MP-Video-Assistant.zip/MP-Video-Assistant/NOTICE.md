# Third-party code

MP Video Assistant is a branded office workflow. Local processing ideas come from:

- Cut/Storm — https://github.com/vorniches/cutstorm — MIT
  Silence keep-interval logic is adapted in `mpva/clean.py` (`cuts_from_words`).
  Source tree: `vendor/cutstorm/`

- Tribe Video Cleaner — https://github.com/grafup/Tribe-Video-Cleaner
  Filler / pause / double-take confirmation is adapted in `mpva/clean.py`.
  Source tree: `vendor/tribe-video-cleaner/`
