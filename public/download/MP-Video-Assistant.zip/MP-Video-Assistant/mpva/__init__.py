from mpva.envfile import load_env
from mpva.paths import ROOT
from mpva.web import create_app

load_env(ROOT)
app = create_app()
