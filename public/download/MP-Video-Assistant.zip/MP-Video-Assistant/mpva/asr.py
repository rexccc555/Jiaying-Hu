from __future__ import annotations

import json
import os
import re
import struct
import tarfile
import urllib.error
import urllib.request
import wave
from pathlib import Path

from mpva.paths import ROOT

WHISPER_URLS = {
    "tiny.en": "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-tiny.en.tar.bz2",
    "base.en": "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-base.en.tar.bz2",
}
API_MODELS = (
    "gpt-4o-mini-transcribe",
    "gpt-4o-transcribe",
    "whisper-large-v3",
    "whisper-1",
)


def transcribe_speech(wav: Path, language: str = "auto", on_line=None) -> tuple[list[dict], str, str]:
    log = on_line or (lambda _line: None)
    lang = _norm_lang(language)
    last = ""
    best = None
    engines = _engines_for(lang)
    for name, runner in engines:
        try:
            log(f"Transcription engine: {name}")
            words = runner(wav, log, lang)
            if words:
                detected = _detect_script(words) if lang == "auto" else lang
                score = _timing_quality(words)
                if score < 0.2:
                    log(f"{name} timestamps look uniform, trying next engine")
                    last = "timestamps missing"
                    if best is None or score > best[0]:
                        best = (score, words, name, detected)
                    continue
                return words, name, detected
        except Exception as exc:
            last = str(exc)
            log(f"{name} skipped: {last}")
    if best:
        return best[1], best[2], best[3]
    raise RuntimeError(
        "Transcription failed for Chinese/English. "
        "Local SenseVoice / Paraformer / Whisper did not finish. " + last
    )


def transcribe_english(wav: Path, on_line=None) -> list[dict]:
    words, _, _ = transcribe_speech(wav, language="en", on_line=on_line)
    return words


def _timing_quality(words: list[dict]) -> float:
    durs = []
    for item in words[:160]:
        text = str(item.get("text") or "").strip()
        if not text or text.startswith("["):
            continue
        durs.append(max(0.02, float(item["end"]) - float(item["start"])))
    if len(durs) < 8:
        return 0.0
    mean = sum(durs) / len(durs)
    stdev = (sum((item - mean) ** 2 for item in durs) / len(durs)) ** 0.5
    if mean <= 0:
        return 0.0
    cv = stdev / mean
    if cv < 0.22 and mean > 0.45:
        return 0.05
    return min(1.0, 0.35 + cv)


def _engines_for(lang: str):
    if lang == "zh":
        return (
            ("sensevoice-zh", lambda wav, log, _l: _local_sensevoice(wav, log, "zh")),
            ("paraformer-zh", lambda wav, log, _l: _local_paraformer(wav, log)),
            ("api-zh", lambda wav, log, _l: _api_whisper(wav, log, "zh")),
        )
    if lang == "en":
        return (
            ("whisper-en", lambda wav, log, _l: _local_whisper(wav, log)),
            ("sensevoice-en", lambda wav, log, _l: _local_sensevoice(wav, log, "en")),
            ("api-en", lambda wav, log, _l: _api_whisper(wav, log, "en")),
        )
    return (
        ("sensevoice-auto", lambda wav, log, _l: _local_sensevoice(wav, log, "")),
        ("whisper-en", lambda wav, log, _l: _local_whisper(wav, log)),
        ("paraformer-zh", lambda wav, log, _l: _local_paraformer(wav, log)),
        ("api-auto", lambda wav, log, _l: _api_whisper(wav, log, "")),
    )


def _norm_lang(language: str) -> str:
    value = (language or "auto").strip().lower()
    if value in {"zh", "zh-cn", "zh-hans", "chinese", "cn", "中文"}:
        return "zh"
    if value in {"en", "en-us", "en-nz", "english", "英文"}:
        return "en"
    return "auto"


def _detect_script(words: list[dict]) -> str:
    text = "".join(str(item.get("text") or "") for item in words)
    cjk = sum(1 for ch in text if "\u4e00" <= ch <= "\u9fff")
    latin = sum(1 for ch in text if ch.isascii() and ch.isalpha())
    if cjk >= 8 and cjk >= latin * 0.25:
        return "zh" if cjk >= latin else "mixed"
    if latin >= 12:
        return "en"
    return "mixed" if cjk else "en"


def _local_whisper(wav: Path, log, *_args) -> list[dict]:
    import sherpa_onnx

    name = os.environ.get("WHISPER_EN_MODEL", "tiny.en").strip() or "tiny.en"
    folder = _ensure_whisper_model(name, log)
    encoder = _first(folder, "encoder")
    decoder = _first(folder, "decoder")
    tokens = folder / "tiny.en-tokens.txt"
    if not tokens.is_file():
        found = next(folder.rglob("*tokens.txt"), None)
        if not found:
            raise RuntimeError("Whisper tokens.txt missing")
        tokens = found
    if not encoder or not decoder:
        raise RuntimeError("Whisper ONNX encoder/decoder missing")
    kwargs = dict(
        encoder=str(encoder),
        decoder=str(decoder),
        tokens=str(tokens),
        language="en",
        task="transcribe",
        num_threads=max(2, (os.cpu_count() or 4) // 2),
        enable_segment_timestamps=True,
    )
    try:
        rec = sherpa_onnx.OfflineRecognizer.from_whisper(**kwargs, enable_token_timestamps=True)
    except TypeError:
        rec = sherpa_onnx.OfflineRecognizer.from_whisper(**kwargs)
    except Exception:
        rec = sherpa_onnx.OfflineRecognizer.from_whisper(**kwargs)
    log("Using on-device English Whisper (no cloud speech API)")
    return _chunk_decode(rec, wav, log)


def _local_sensevoice(wav: Path, log, language: str) -> list[dict]:
    import sherpa_onnx

    folder = ROOT / "data" / "models" / "sensevoice"
    model = next(folder.rglob("*.onnx"), None) if folder.is_dir() else None
    tokens = next(folder.rglob("*tokens.txt"), None) if folder.is_dir() else None
    if not model or not tokens:
        raise RuntimeError("SenseVoice model missing")
    rec = sherpa_onnx.OfflineRecognizer.from_sense_voice(
        model=str(model),
        tokens=str(tokens),
        num_threads=max(2, (os.cpu_count() or 4) // 2),
        language=language or "",
        use_itn=True,
    )
    tag = language or "auto"
    log(f"Using on-device SenseVoice ({tag}) for Chinese/English")
    return _chunk_decode(rec, wav, log, chunk=20.0, hop=18.0)


def _local_paraformer(wav: Path, log, *_args) -> list[dict]:
    import sherpa_onnx

    folder = ROOT / "data" / "models" / "paraformer-zh"
    model = next(folder.rglob("*.onnx"), None) if folder.is_dir() else None
    tokens = next(folder.rglob("*tokens.txt"), None) if folder.is_dir() else None
    if not model or not tokens:
        raise RuntimeError("Paraformer-zh model missing")
    rec = sherpa_onnx.OfflineRecognizer.from_paraformer(
        paraformer=str(model),
        tokens=str(tokens),
        num_threads=max(2, (os.cpu_count() or 4) // 2),
    )
    log("Using on-device Chinese Paraformer")
    return _chunk_decode(rec, wav, log, chunk=20.0, hop=18.0)


def _chunk_decode(rec, wav: Path, log, chunk: float = 28.0, hop: float = 26.0) -> list[dict]:
    duration = _wav_duration(wav)
    sample_rate = 16000
    words: list[dict] = []
    index = 0
    start = 0.0
    while start < duration - 0.2:
        end = min(duration, start + chunk)
        log(f"Transcribing {start:.0f}s–{end:.0f}s of {duration:.0f}s")
        a = int(start * sample_rate)
        b = int(end * sample_rate)
        samples, sample_rate = _read_wav_slice(wav, a, b)
        stream = rec.create_stream()
        stream.accept_waveform(sample_rate, samples)
        rec.decode_stream(stream)
        piece = _result_to_words(stream.result, offset=start, start_id=index, chunk_end=end)
        if piece:
            words.extend(piece)
            tail = piece[-1]["id"][1:]
            index = int(tail) + 1 if tail.isdigit() else index + len(piece)
        start += hop
    if not words:
        raise RuntimeError("Local speech model returned empty text")
    return _dedupe_overlap(words)


def _result_to_words(result, offset: float, start_id: int, chunk_end: float | None = None) -> list[dict]:
    text = ""
    tokens = []
    times = []
    if hasattr(result, "text"):
        text = str(result.text or "")
    elif isinstance(result, dict):
        text = str(result.get("text") or "")
        tokens = result.get("tokens") or []
        times = result.get("timestamps") or []
    if hasattr(result, "tokens"):
        tokens = list(result.tokens or [])
    if hasattr(result, "timestamps"):
        times = list(result.timestamps or [])
    text = _clean_asr_text(text)
    words = []
    if tokens and times and len(tokens) == len(times) and max(float(stamp) for stamp in times) > 0.4:
        buf = ""
        buf_start = None
        buf_end = None
        for token, stamp in zip(tokens, times):
            piece = str(token).replace("▁", " ").replace("Ġ", " ")
            if _is_tag(piece):
                continue
            if _is_cjk_unit(piece) or (piece.startswith(" ") and buf):
                if buf.strip():
                    words.extend(_units_to_words(buf.strip(), buf_start + offset, buf_end + offset, start_id + len(words)))
                buf = piece.strip() or piece
                buf_start = float(stamp)
                buf_end = float(stamp) + 0.12
            else:
                if buf_start is None:
                    buf_start = float(stamp)
                buf += piece
                buf_end = float(stamp) + 0.12
        if buf.strip():
            words.extend(_units_to_words(buf.strip(), (buf_start or 0) + offset, (buf_end or 0) + offset, start_id + len(words)))
        return [item for item in words if item["text"]]
    end = chunk_end if chunk_end is not None else offset + max(1.2, 0.12 * max(1, len(text.strip())))
    return _units_to_words(text.strip(), offset, end, start_id)


def _units_to_words(text: str, start: float, end: float, start_id: int) -> list[dict]:
    parts = _split_units(text)
    if not parts:
        return []
    if len(parts) == 1:
        return [_word(start_id, parts[0], start, max(end, start + 0.08))]
    span = max(end - start, 0.08 * len(parts))
    step = span / len(parts)
    out = []
    for i, part in enumerate(parts):
        out.append(_word(start_id + i, part, start + i * step, start + (i + 1) * step))
    return out


def _clean_asr_text(text: str) -> str:
    return re.sub(r"<\|[^|>]+\|>", " ", text or "").strip()


def _is_tag(piece: str) -> bool:
    stripped = (piece or "").strip()
    return stripped.startswith("<|") and stripped.endswith("|>")


def _split_units(text: str) -> list[str]:
    text = (text or "").strip()
    if not text:
        return []
    return re.findall(
        r"[A-Za-z]+(?:['’-][A-Za-z]+)*|[0-9]+(?:\.[0-9]+)?|[\u4e00-\u9fff][，。！？、,.!?]*|[^\s]",
        text,
    )


def _is_cjk_unit(piece: str) -> bool:
    stripped = piece.strip()
    return bool(stripped) and "\u4e00" <= stripped[0] <= "\u9fff"


def _wav_duration(path: Path) -> float:
    with wave.open(str(path), "rb") as handle:
        return handle.getnframes() / max(1, handle.getframerate())


def _read_wav_slice(path: Path, start_frame: int, end_frame: int) -> tuple[list[float], int]:
    with wave.open(str(path), "rb") as handle:
        if handle.getnchannels() != 1 or handle.getsampwidth() != 2:
            raise RuntimeError("Need 16 kHz mono 16-bit WAV")
        sample_rate = handle.getframerate()
        start_frame = max(0, start_frame)
        end_frame = min(handle.getnframes(), end_frame)
        handle.setpos(start_frame)
        frames = handle.readframes(max(0, end_frame - start_frame))
    count = len(frames) // 2
    shorts = struct.unpack("<" + "h" * count, frames)
    return [value / 32768.0 for value in shorts], sample_rate


def _ensure_whisper_model(name: str, log) -> Path:
    url = WHISPER_URLS.get(name) or WHISPER_URLS["tiny.en"]
    dest = ROOT / "data" / "models" / f"whisper-{name}"
    if _first(dest, "encoder") and _first(dest, "decoder"):
        return dest
    dest.mkdir(parents=True, exist_ok=True)
    archive = dest / "model.tar.bz2"
    if not archive.is_file() or archive.stat().st_size < 10000:
        log(f"Downloading English Whisper {name} (one-time, stays on this PC)")
        urllib.request.urlretrieve(url, archive)
    log("Unpacking Whisper model")
    with tarfile.open(archive, "r:bz2") as tar:
        tar.extractall(dest)
    nested = next((p for p in dest.iterdir() if p.is_dir()), dest)
    if nested != dest:
        for child in nested.iterdir():
            target = dest / child.name
            if not target.exists():
                child.replace(target)
    return dest


def _first(folder: Path, kind: str) -> Path | None:
    if not folder.is_dir():
        return None
    matches = sorted(folder.rglob(f"*{kind}*.onnx"))
    return matches[0] if matches else None


def _api_whisper(wav: Path, log, language: str) -> list[dict]:
    key = os.environ.get("OPENAI_API_KEY") or ""
    if not key:
        raise RuntimeError("No API key")
    base = (os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
    if not base.endswith("/v1"):
        base += "/v1"
    extra = [part.strip() for part in (os.environ.get("OPENAI_WHISPER_MODEL") or "").split(",") if part.strip()]
    last = ""
    for model in extra + list(API_MODELS):
        log(f"API speech model: {model}")
        try:
            data = _post_transcription(base, key, wav, model, language)
        except Exception as exc:
            last = str(exc)
            if "无可用渠道" in last or "unknown model" in last.lower() or "not found" in last.lower():
                continue
            raise
        words = _parse_api(data)
        if words:
            return words
    raise RuntimeError(last or "No speech model available on the gateway")


def _post_transcription(base: str, key: str, wav: Path, model: str, language: str) -> dict:
    boundary = "----mpvaBoundary"
    fields = [
        ("model", model),
        ("response_format", "verbose_json"),
        ("timestamp_granularities[]", "word"),
    ]
    if language in {"en", "zh"}:
        fields.append(("language", language))
    header = "".join(
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{value}\r\n" for name, value in fields
    )
    body = (
        header.encode("utf-8")
        + (
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{wav.name}\"\r\n"
            "Content-Type: audio/wav\r\n\r\n"
        ).encode("utf-8")
        + wav.read_bytes()
        + f"\r\n--{boundary}--\r\n".encode("utf-8")
    )
    request = urllib.request.Request(
        base + "/audio/transcriptions",
        data=body,
        headers={"Authorization": f"Bearer {key}", "Content-Type": f"multipart/form-data; boundary={boundary}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=600) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:500]
        raise RuntimeError(detail) from exc


def _parse_api(data: dict) -> list[dict]:
    if data.get("error"):
        message = str((data.get("error") or {}).get("message") or data["error"])
        raise RuntimeError(message)
    words = []
    for index, item in enumerate(data.get("words") or []):
        text = str(item.get("word") or item.get("text") or "").strip()
        if text:
            words.extend(_units_to_words(text, float(item.get("start") or 0), float(item.get("end") or 0), index * 20))
    if words:
        for i, item in enumerate(words):
            item["id"] = f"w{i}"
        return words
    for index, seg in enumerate(data.get("segments") or []):
        text = str(seg.get("text") or "").strip()
        if text:
            words.extend(_units_to_words(text, float(seg.get("start") or 0), float(seg.get("end") or 0), index * 40))
    if words:
        for i, item in enumerate(words):
            item["id"] = f"w{i}"
        return words
    text = str(data.get("text") or "").strip()
    return _units_to_words(text, 0.0, 1.0, 0) if text else []


def _word(index: int, text: str, start: float, end: float) -> dict:
    return {
        "id": f"w{index}",
        "text": text,
        "start": round(float(start), 3),
        "end": round(max(float(end), float(start) + 0.04), 3),
        "kind": "speech",
        "keep": True,
        "suggested_cut": False,
        "override": None,
        "reason": "",
    }


def _dedupe_overlap(words: list[dict]) -> list[dict]:
    if not words:
        return []
    ordered = sorted(words, key=lambda item: (float(item["start"]), float(item["end"])))
    out = [ordered[0]]
    for item in ordered[1:]:
        prev = out[-1]
        same = str(item.get("text") or "").strip().lower() == str(prev.get("text") or "").strip().lower()
        if same and item["start"] <= prev["end"] + 0.85:
            prev["end"] = max(prev["end"], item["end"])
            continue
        if item["start"] + 0.12 < prev["end"]:
            continue
        out.append(item)
    for index, item in enumerate(out):
        item["id"] = f"w{index}"
    return out
