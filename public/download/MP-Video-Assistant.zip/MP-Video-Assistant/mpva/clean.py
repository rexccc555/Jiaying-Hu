"""Silence keep-ranges adapted from Cut/Storm (MIT). Filler/repeat adapted from Tribe Video Cleaner."""

from __future__ import annotations

import re
import uuid

from mpva.captions import squeeze_cjk

FILLERS = (
    "um",
    "uh",
    "ah",
    "er",
    "erm",
    "you know",
    "i mean",
)

FILLERS_ZH = (
    "那个",
    "嗯",
    "啊",
    "呃",
    "额",
    "唔",
)


def cuts_from_words(words: list[dict], threshold_sec: float = 1.5, padding_sec: float = 0.12, total_duration: float = 0) -> list[tuple[float, float]]:
    ordered = sorted((w for w in words if w.get("keep", True) and w.get("kind") != "silence"), key=lambda w: w["start"])
    if not ordered:
        return [(0.0, total_duration)] if total_duration > 0 else []
    keep: list[tuple[float, float]] = []
    cur_start = max(0.0, ordered[0]["start"] - padding_sec)
    cur_end = ordered[0]["end"] + padding_sec
    for prev, word in zip(ordered, ordered[1:]):
        gap = word["start"] - prev["end"]
        if gap > threshold_sec:
            keep.append((cur_start, cur_end))
            cur_start = max(cur_end, word["start"] - padding_sec)
        cur_end = max(cur_end, word["end"] + padding_sec)
    if total_duration > 0:
        cur_end = min(total_duration, cur_end)
    if cur_end > cur_start:
        keep.append((cur_start, cur_end))
    merged: list[tuple[float, float]] = []
    for start, end in keep:
        if merged and start <= merged[-1][1] + 1e-6:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    return merged


def apply_policy(
    words: list[dict],
    *,
    remove_fillers: bool = True,
    remove_pauses: bool = True,
    remove_repeats: bool = True,
) -> list[dict]:
    out = []
    for item in words:
        row = dict(item)
        override = row.get("override")
        if override == "keep":
            row["keep"] = True
        elif override == "cut":
            row["keep"] = False
        elif row.get("kind") == "filler" and remove_fillers:
            row["keep"] = False
        elif row.get("kind") == "silence" and remove_pauses:
            row["keep"] = False
        elif row.get("kind") == "repeat" and remove_repeats:
            row["keep"] = False
        else:
            row["keep"] = True
        out.append(row)
    return out


def mark_fillers(words: list[dict]) -> list[dict]:
    result = [dict(item) for item in words]
    fillers = sorted(FILLERS, key=lambda s: -len(s.split()))
    for filler in fillers:
        parts = filler.split()
        n = len(parts)
        for i in range(0, max(0, len(result) - n + 1)):
            window = result[i : i + n]
            if any(item.get("kind") not in {None, "speech", "normal"} for item in window):
                continue
            text = " ".join(_norm_en(item["text"]) for item in window)
            if text == filler:
                _suggest_cut(window, "filler", "Filler / false start")
    _mark_fillers_zh(result)
    return result


def _mark_fillers_zh(result: list[dict]) -> None:
    speech_idx = [i for i, item in enumerate(result) if item.get("kind") in {None, "speech", "normal"}]
    for filler in sorted(FILLERS_ZH, key=len, reverse=True):
        n = len(filler)
        i = 0
        while i < len(speech_idx):
            start_i = speech_idx[i]
            buf = ""
            used = []
            j = i
            while j < len(speech_idx) and len(buf) < n:
                item = result[speech_idx[j]]
                piece = _norm_zh(item.get("text") or "")
                if not piece:
                    j += 1
                    continue
                buf += piece
                used.append(item)
                j += 1
            if buf == filler:
                _suggest_cut(used, "filler", "口头语 / 假起势")
                i = j
            else:
                i += 1


def mark_silences(words: list[dict], min_duration: float = 1.5) -> list[dict]:
    speech = [item for item in words if item.get("kind") != "silence"]
    speech.sort(key=lambda w: w["start"])
    extra: list[dict] = []
    for left, right in zip(speech, speech[1:]):
        gap = right["start"] - left["end"]
        if gap < min_duration:
            continue
        extra.append(
            {
                "id": uuid.uuid4().hex[:10],
                "text": f"[pause {gap:.1f}s]",
                "start": left["end"],
                "end": right["start"],
                "kind": "silence",
                "keep": True,
                "suggested_cut": True,
                "reason": "Long pause",
            }
        )
    return sorted(speech + extra, key=lambda w: w["start"])


def mark_repeats(words: list[dict], sensitivity: float = 0.72) -> list[dict]:
    result = [dict(item) for item in words]
    sentences = _sentences(result)
    for left, right in zip(sentences, sentences[1:]):
        if min(len(left), len(right)) < 3:
            continue
        if _similar(_join(left), _join(right)) < sensitivity:
            continue
        _suggest_cut(left, "repeat", "Repeated take (keeping the later wording)")
    return result


def run_clean(words: list[dict]) -> list[dict]:
    cleaned = mark_fillers(words)
    cleaned = mark_silences(cleaned)
    cleaned = mark_repeats(cleaned)
    for item in cleaned:
        item.setdefault("kind", "speech")
        item.setdefault("keep", True)
        item.setdefault("suggested_cut", False)
        item.setdefault("reason", "")
        item.setdefault("override", None)
    return cleaned


def join_text(words: list[dict]) -> str:
    out = ""
    for item in words:
        text = squeeze_cjk((item.get("text") or "").strip())
        if not text or text.startswith("["):
            continue
        if out and not _is_cjk(out[-1]) and not _is_cjk(text[0]) and text[0] not in ".,!?，。！？、":
            out += " "
        out += text
    return squeeze_cjk(out.strip())


def _suggest_cut(window: list[dict], kind: str, reason: str) -> None:
    for item in window:
        item["kind"] = kind
        item["suggested_cut"] = True
        item["keep"] = True
        item["reason"] = reason


def _norm_en(text: str) -> str:
    return re.sub(r"[^a-z\s']", "", (text or "").lower()).strip()


def _norm_zh(text: str) -> str:
    return re.sub(r"[^\u4e00-\u9fff]", "", text or "")


def _is_cjk(ch: str) -> bool:
    return bool(ch) and "\u4e00" <= ch[0] <= "\u9fff"


def _join(words: list[dict]) -> str:
    return " ".join(_norm_en(item["text"]) or _norm_zh(item["text"]) for item in words)


def sentence_groups(words: list[dict], pause: float = 0.75) -> list[list[dict]]:
    speech = [item for item in words if item.get("kind") != "silence" and (item.get("text") or "").strip() and not str(item.get("text") or "").startswith("[")]
    if not speech:
        return []
    groups: list[list[dict]] = [[speech[0]]]
    for prev, item in zip(speech, speech[1:]):
        prev_text = str(prev.get("text") or "")
        if item["start"] - prev["end"] >= pause or prev_text.endswith((".", "?", "!", "。", "！", "？")):
            groups.append([item])
        else:
            groups[-1].append(item)
    return groups


def _sentences(words: list[dict], pause: float = 0.75) -> list[list[dict]]:
    return sentence_groups(words, pause=pause)


def _similar(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    set_a, set_b = set(a.split()), set(b.split())
    if not set_a or not set_b:
        return 0.0
    return len(set_a & set_b) / len(set_a | set_b)
