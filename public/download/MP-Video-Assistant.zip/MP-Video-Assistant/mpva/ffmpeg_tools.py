from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from mpva.paths import FFMPEG_DIR


class FFmpegError(RuntimeError):
    pass


def find_bin(name: str) -> str:
    path = shutil.which(name) or shutil.which(name, path=str(FFMPEG_DIR))
    if not path:
        raise FFmpegError(f"找不到 {name}，请先安装 FFmpeg 并加入 PATH")
    return path


def run(argv: list[str], *, timeout: int = 3600, cwd: str | Path | None = None) -> str:
    result = subprocess.run(
        argv,
        capture_output=True,
        text=True,
        timeout=timeout,
        encoding="utf-8",
        errors="replace",
        cwd=str(cwd) if cwd else None,
    )
    if result.returncode != 0:
        err = (result.stderr or result.stdout or "").strip()
        raise FFmpegError(err[-1200:] or "FFmpeg 失败")
    return result.stderr or result.stdout or ""


def probe(path: Path) -> dict:
    ffprobe = find_bin("ffprobe")
    raw = subprocess.check_output(
        [
            ffprobe,
            "-v",
            "error",
            "-show_entries",
            "format=duration:stream=codec_type,width,height",
            "-of",
            "json",
            str(path),
        ],
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    data = json.loads(raw)
    streams = data.get("streams") or []
    video = next((s for s in streams if s.get("codec_type") == "video"), streams[0] if streams else {})
    audio = next((s for s in streams if s.get("codec_type") == "audio"), None)
    duration = float((data.get("format") or {}).get("duration") or 0)
    return {
        "duration": duration,
        "width": int(video.get("width") or 0),
        "height": int(video.get("height") or 0),
        "has_audio": audio is not None,
    }


def extract_wav(src: Path, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    run(
        [
            find_bin("ffmpeg"),
            "-y",
            "-i",
            str(src),
            "-ac",
            "1",
            "-ar",
            "16000",
            "-vn",
            str(dest),
        ]
    )
    return dest


def write_concat_list(parts: list[Path], listing: Path) -> Path:
    listing.parent.mkdir(parents=True, exist_ok=True)
    root = listing.parent.resolve()
    lines = []
    for part in parts:
        rel = Path(os.path.relpath(part.resolve(), root)).as_posix().replace("'", r"'\''")
        lines.append(f"file '{rel}'")
    listing.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return listing


def concat_copy(parts: list[Path], dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if len(parts) == 1:
        src = Path(parts[0]).resolve()
        out = dest.resolve()
        if src != out:
            shutil.copy2(src, out)
        return dest
    listing = write_concat_list(parts, dest.parent / "_concat.txt")
    root = listing.parent.resolve()
    run(
        [
            find_bin("ffmpeg"),
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            listing.name,
            "-c",
            "copy",
            dest.name,
        ],
        cwd=root,
    )
    return dest
