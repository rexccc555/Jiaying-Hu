"""Edit Decision List: AI never touches pixels or invents speech."""

from __future__ import annotations

from mpva.clean import apply_policy, join_text


def build_job_edl(job: dict) -> dict:
    words = job.get("words") or []
    clips = []
    for clip in job.get("clips") or []:
        clips.append(clip.get("edl") or build_clip_edl(clip, words, suggested=True))
    return {
        "version": 1,
        "language": job.get("language_detected") or job.get("language") or "auto",
        "asr_engine": job.get("asr_engine") or "",
        "duration": job.get("duration") or 0,
        "original_transcript": original_lines(words),
        "clips": clips,
    }


def build_clip_edl(
    clip: dict,
    words: list[dict],
    *,
    suggested: bool = False,
    remove_fillers: bool = True,
    remove_pauses: bool = True,
    style: str = "clean",
    captions: bool = True,
    reframe: bool = True,
) -> dict:
    start = float(clip["start"])
    end = float(clip["end"])
    window = [item for item in words if item["end"] >= start and item["start"] <= end]
    if suggested:
        applied = [
            {**item, "keep": item.get("keep", True) and not item.get("suggested_cut")}
            for item in window
        ]
    else:
        applied = apply_policy(
            window,
            remove_fillers=remove_fillers,
            remove_pauses=remove_pauses,
        )
    original = [item for item in window if item.get("kind") != "silence"]
    kept = [item for item in applied if item.get("keep") is not False and item.get("kind") != "silence"]
    removed = [item for item in applied if item.get("keep") is False]
    cut_log = [
        {
            "start": round(float(item["start"]), 3),
            "end": round(float(item["end"]), 3),
            "text": item.get("text") or "",
            "reason": item.get("reason") or item.get("kind") or "cut",
            "restore": True,
        }
        for item in removed
    ]
    return {
        "clip_id": clip.get("id"),
        "topic": clip.get("topic") or "",
        "title": clip.get("title") or "",
        "source": {"start": round(start, 3), "end": round(end, 3)},
        "remove": [{"start": row["start"], "end": row["end"], "text": row["text"], "reason": row["reason"]} for row in cut_log],
        "original_transcript": join_text(original),
        "edited_transcript": join_text(kept),
        "final_transcript": join_text(kept),
        "cut_log": cut_log,
        "style": style,
        "captions": captions,
        "reframe": reframe,
        "confidence": {
            "transcript": float((clip.get("confidence") or {}).get("transcript") or 0.9),
            "topic": float((clip.get("confidence") or {}).get("topic") or 0.7),
        },
    }


def original_lines(words: list[dict]) -> list[dict]:
    lines = []
    for item in words:
        if item.get("kind") == "silence":
            continue
        text = (item.get("text") or "").strip()
        if not text:
            continue
        lines.append(
            {
                "start": round(float(item["start"]), 3),
                "end": round(float(item["end"]), 3),
                "text": text,
            }
        )
    return lines
