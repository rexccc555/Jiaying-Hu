"""Asset engine: execute a multi-source story on FFmpeg (J/L-cuts, photos, concat)."""

from __future__ import annotations

from pathlib import Path

from mpva.captions import pack_cues
from mpva.ffmpeg_tools import concat_copy, find_bin, run
from mpva.render import PRESETS, _fit


def assemble_story(story: dict, dest: Path, *, preset: str = "vertical") -> Path:
    spec = PRESETS[preset]
    folder = dest.parent / f"{dest.stem}_parts"
    folder.mkdir(parents=True, exist_ok=True)
    parts: list[Path] = []
    for index, beat in enumerate(story.get("beats") or []):
        part = folder / f"beat{index:02d}.mp4"
        _render_beat(beat, part, spec)
        if part.is_file() and part.stat().st_size > 500:
            parts.append(part)
    if not parts:
        raise RuntimeError("No usable beats in the edit script")
    dest.parent.mkdir(parents=True, exist_ok=True)
    if len(parts) == 1:
        parts[0].replace(dest)
        return dest
    concat_copy(parts, dest)
    return dest


def story_captions(story: dict, assets: list[dict]) -> list[dict]:
    by_id = {item["id"]: item for item in assets}
    out = []
    for beat in story.get("beats") or []:
        audio = beat.get("audio") or {}
        asset = by_id.get(audio.get("asset_id") or beat.get("words_from") or "")
        if not asset:
            continue
        src_in = float(audio.get("in") or 0)
        src_out = float(audio.get("out") or src_in)
        beat_start = float(beat.get("start") or 0)
        for word in asset.get("words") or []:
            if word["end"] <= src_in or word["start"] >= src_out:
                continue
            text = (word.get("text") or "").strip()
            if not text or text.startswith("["):
                continue
            start = beat_start + max(0.0, float(word["start"]) - src_in)
            end = beat_start + max(0.06, min(src_out, float(word["end"])) - src_in)
            out.append({"text": text, "start": round(start, 3), "end": round(end, 3), "emphasis": False})
    return pack_cues(out)


def _render_beat(beat: dict, dest: Path, spec: dict) -> None:
    duration = max(0.4, float(beat.get("end") or 0) - float(beat.get("start") or 0))
    vf = _fit(spec["width"], spec["height"], reframe=True)
    video = beat.get("video")
    photos = beat.get("photos") or []
    audio = beat.get("audio")
    if photos and not video:
        still = dest.with_name(dest.stem + "_still.mp4")
        _photos(photos, still if audio else dest, duration, vf, spec)
        if audio and Path(audio.get("path") or "").is_file():
            ain = float(audio.get("in") or 0)
            run(
                [
                    find_bin("ffmpeg"),
                    "-y",
                    "-i",
                    str(still),
                    "-ss",
                    f"{ain:.3f}",
                    "-t",
                    f"{duration:.3f}",
                    "-i",
                    str(audio["path"]),
                    "-map",
                    "0:v:0",
                    "-map",
                    "1:a:0",
                    "-c:v",
                    "copy",
                    "-c:a",
                    "aac",
                    "-shortest",
                    str(dest),
                ]
            )
        return
    if not video or not Path(video.get("path") or "").is_file():
        _color(dest, duration, spec)
        return
    vin = float(video.get("in") or 0)
    vdur = max(0.4, float(video.get("out") or vin + duration) - vin)
    argv = [
        find_bin("ffmpeg"),
        "-y",
        "-ss",
        f"{vin:.3f}",
        "-t",
        f"{vdur:.3f}",
        "-i",
        str(video["path"]),
    ]
    if audio and Path(audio.get("path") or "").is_file() and (audio.get("path") != video.get("path") or beat.get("jcut")):
        ain = float(audio.get("in") or 0)
        argv += ["-ss", f"{ain:.3f}", "-t", f"{vdur:.3f}", "-i", str(audio["path"]), "-map", "0:v:0", "-map", "1:a:0?"]
        af = "loudnorm=I=-16:TP=-1.5:LRA=11"
    else:
        af = "loudnorm=I=-16:TP=-1.5:LRA=11"
    argv += [
        "-vf",
        vf,
        "-af",
        af,
        "-t",
        f"{vdur:.3f}",
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "20",
        "-c:a",
        "aac",
        "-b:a",
        "160k",
        "-shortest",
        str(dest),
    ]
    try:
        run(argv)
    except Exception:
        _color(dest, duration, spec)


def _photos(photos: list[dict], dest: Path, duration: float, vf: str, spec: dict) -> None:
    usable = [item for item in photos if Path(item.get("path") or "").is_file()]
    if not usable:
        _color(dest, duration, spec)
        return
    each = max(1.2, duration / len(usable))
    parts = []
    folder = dest.parent
    for index, item in enumerate(usable):
        part = folder / f"{dest.stem}_p{index}.mp4"
        suffix = Path(item["path"]).suffix.lower()
        argv = [find_bin("ffmpeg"), "-y"]
        if suffix in {".jpg", ".jpeg", ".png", ".webp", ".bmp"}:
            argv += ["-loop", "1", "-t", f"{each:.3f}", "-i", str(item["path"])]
        else:
            argv += ["-t", f"{each:.3f}", "-i", str(item["path"])]
        argv += [
            "-vf",
            vf + ",format=yuv420p",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "20",
            "-pix_fmt",
            "yuv420p",
            "-an",
            str(part),
        ]
        run(argv)
        parts.append(part)
    if len(parts) == 1:
        # add silence so concat with video+audio later still works
        run(
            [
                find_bin("ffmpeg"),
                "-y",
                "-i",
                str(parts[0]),
                "-f",
                "lavfi",
                "-i",
                "anullsrc=r=48000:cl=stereo",
                "-c:v",
                "copy",
                "-c:a",
                "aac",
                "-shortest",
                str(dest),
            ]
        )
        return
    listing = folder / f"{dest.stem}_photos.txt"
    listing.write_text("\n".join(f"file '{str(part.resolve()).replace(chr(92), '/')}'" for part in parts) + "\n", encoding="utf-8")
    mid = folder / f"{dest.stem}_photos.mp4"
    run([find_bin("ffmpeg"), "-y", "-f", "concat", "-safe", "0", "-i", str(listing), "-c", "copy", str(mid)])
    run(
        [
            find_bin("ffmpeg"),
            "-y",
            "-i",
            str(mid),
            "-f",
            "lavfi",
            "-i",
            "anullsrc=r=48000:cl=stereo",
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-shortest",
            str(dest),
        ]
    )


def _color(dest: Path, duration: float, spec: dict) -> None:
    run(
        [
            find_bin("ffmpeg"),
            "-y",
            "-f",
            "lavfi",
            "-i",
            f"color=c=0x0b1a28:s={spec['width']}x{spec['height']}:d={duration:.3f}",
            "-f",
            "lavfi",
            "-i",
            "anullsrc=r=48000:cl=stereo",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-shortest",
            str(dest),
        ]
    )
