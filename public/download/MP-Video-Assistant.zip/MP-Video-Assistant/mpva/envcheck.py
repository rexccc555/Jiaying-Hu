﻿"""Check and pre-install everything an Agent Motion film needs, so the agent does not stop mid-film to install."""

from __future__ import annotations

import json
import shutil
import subprocess
import tarfile
import tempfile
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

from mpva import autopilot
from mpva.motion import MOTION_ROOT
from mpva.paths import FFMPEG_DIR, MODELS, TOOLS

# Packages the agent reached for mid-film (font cmap checks, image analysis).
PY_EXTRAS = {"fontTools": "fonttools", "scipy": "scipy", "PIL": "pillow", "numpy": "numpy"}

MOTION_ZIP = "https://github.com/erduo1998-cell/agent-motion/archive/refs/heads/main.zip"
FFMPEG_ZIP = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"
SPEECH_TAR = (
    "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/"
    "sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17.tar.bz2"
)
SPEECH_DIR = MODELS / "sensevoice"

_state: dict = {"fixing": False, "step": "", "error": "", "doctor": None, "doctor_at": 0.0}
_lock = threading.Lock()


def _venv_python() -> Path:
    return MOTION_ROOT / ".venv" / "Scripts" / "python.exe"


def _node_ok() -> tuple[bool, str]:
    node = shutil.which("node", path=autopilot._search_path())
    if not node:
        return False, "未安装"
    try:
        out = subprocess.run([node, "-v"], capture_output=True, text=True, timeout=15).stdout.strip()
        major = int(out.lstrip("v").split(".")[0])
        return major >= 22, out if major >= 22 else f"{out}（需要 22 以上）"
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return False, "无法运行 node"


def _doctor(refresh: bool = False) -> dict | None:
    if not refresh and _state["doctor"] and time.time() - _state["doctor_at"] < 600:
        return _state["doctor"]
    node = shutil.which("node", path=autopilot._search_path())
    if not node or not (MOTION_ROOT / "node_modules").exists():
        return None
    try:
        result = subprocess.run(
            [node, "scripts/doctor.mjs", "--matting", "--json"],
            cwd=str(MOTION_ROOT),
            capture_output=True,
            text=True,
            timeout=180,
            encoding="utf-8",
            errors="replace",
            env=autopilot._agent_env(),
        )
        report = json.loads(result.stdout[result.stdout.find("{"):])
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return None
    _state["doctor"], _state["doctor_at"] = report, time.time()
    return report


def _missing_py() -> list[str]:
    python = _venv_python()
    if not python.is_file():
        return list(PY_EXTRAS.values())
    probe = "import importlib.util as u, json; print(json.dumps([m for m in %r if not u.find_spec(m)]))" % list(PY_EXTRAS)
    try:
        out = subprocess.run([str(python), "-c", probe], capture_output=True, text=True, timeout=30).stdout
        return [PY_EXTRAS[name] for name in json.loads(out.strip() or "[]")]
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return list(PY_EXTRAS.values())


def _ffmpeg_ok() -> bool:
    path = autopilot._search_path()
    return all(shutil.which(name, path=path) for name in ("ffmpeg", "ffprobe"))


def _speech_ok() -> bool:
    return SPEECH_DIR.is_dir() and any(SPEECH_DIR.rglob("*.onnx")) and any(SPEECH_DIR.rglob("*tokens.txt"))


def _motion_ok() -> bool:
    return (MOTION_ROOT / "AGENTS.md").is_file() and (MOTION_ROOT / "package.json").is_file()


def status(refresh: bool = False) -> dict:
    node_ok, node_detail = _node_ok()
    report = _doctor(refresh) if node_ok else None
    runtime_ok = bool(report and report.get("ok"))
    failed = [c["name"] for c in (report or {}).get("checks", []) if not c.get("ok")]
    missing = _missing_py()
    agents = autopilot.runners()
    agent_ok = any(row["available"] and row.get("signed_in") is not False for row in agents)
    items = [
        {"key": "ffmpeg", "label": "FFmpeg", "ok": _ffmpeg_ok(), "detail": ""},
        {"key": "speech", "label": "语音识别模型", "ok": _speech_ok(), "detail": ""},
        {"key": "node", "label": "Node.js 22+", "ok": node_ok, "detail": node_detail},
        {"key": "motion", "label": "Agent Motion 工程", "ok": _motion_ok(), "detail": ""},
        {
            "key": "runtime",
            "label": "抠像 / FFmpeg / Chromium",
            "ok": runtime_ok,
            "detail": "就绪" if runtime_ok else ("缺：" + "、".join(failed) if failed else "未安装"),
        },
        {"key": "python", "label": "字体与图像工具", "ok": not missing, "detail": "就绪" if not missing else "缺：" + "、".join(missing)},
        {"key": "agent", "label": "AI 助手", "ok": agent_ok, "detail": "就绪" if agent_ok else "需要安装并登录一个"},
    ]
    return {
        "ok": all(item["ok"] for item in items),
        "items": items,
        "fixing": _state["fixing"],
        "step": _state["step"],
        "error": _state["error"],
    }


def fix_all() -> dict:
    with _lock:
        if _state["fixing"]:
            return status()
        _state.update(fixing=True, step="", error="")
    threading.Thread(target=_fix, daemon=True).start()
    return status()


def _fix() -> None:
    try:
        if not _motion_ok():
            _state["step"] = "motion"
            _fetch_motion()
        if not _ffmpeg_ok():
            _state["step"] = "ffmpeg"
            _fetch_ffmpeg()
        if not _speech_ok():
            _state["step"] = "speech"
            _fetch_speech()
        if not _node_ok()[0]:
            _state["step"] = "node"
            autopilot._install_node()
            if not _node_ok()[0]:
                raise RuntimeError("Node.js 安装后仍不可用，请重启电脑再试")
        report = _doctor(refresh=True)
        if not (report and report.get("ok")):
            _state["step"] = "runtime"
            node = shutil.which("node", path=autopilot._search_path())
            result = subprocess.run(
                [node, "scripts/bootstrap.mjs"],
                cwd=str(MOTION_ROOT),
                capture_output=True,
                text=True,
                timeout=3600,
                encoding="utf-8",
                errors="replace",
                env=autopilot._agent_env(),
            )
            if result.returncode != 0:
                raise RuntimeError("Agent Motion 安装失败：" + (result.stderr or result.stdout or "")[-300:])
            _doctor(refresh=True)
        missing = _missing_py()
        if missing:
            _state["step"] = "python"
            _pip_install(missing)
        if not any(row["available"] for row in autopilot.runners()):
            _state["step"] = "agent"
            autopilot.install("cursor")
            while autopilot._installs.get("cursor", {}).get("state") == "running":
                time.sleep(2)
            error = autopilot._installs.get("cursor", {}).get("error")
            if error:
                raise RuntimeError(error)
    except Exception as exc:  # noqa: BLE001 — surface any installer failure in the UI
        _state["error"] = str(exc)[:400]
    finally:
        _state.update(fixing=False, step="")


def _pip_install(packages: list[str]) -> None:
    python = _venv_python()
    uv = next((MOTION_ROOT / ".runtime").rglob("uv.exe"), None) if (MOTION_ROOT / ".runtime").exists() else None
    if uv:
        command = [str(uv), "pip", "install", "--python", str(python), *packages]
    else:
        command = [str(python), "-m", "pip", "install", *packages]
    result = subprocess.run(
        command, capture_output=True, text=True, timeout=1200, encoding="utf-8", errors="replace", env=autopilot._agent_env()
    )
    if result.returncode != 0:
        raise RuntimeError("Python 工具安装失败：" + (result.stderr or result.stdout or "")[-300:])


def _download(url: str, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_name(dest.name + ".part")
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(request, timeout=60) as resp, part.open("wb") as handle:
        shutil.copyfileobj(resp, handle, 1 << 20)
    part.replace(dest)
    return dest


def _fetch_motion() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        archive = _download(MOTION_ZIP, Path(tmp) / "motion.zip")
        with zipfile.ZipFile(archive) as zf:
            zf.extractall(tmp)
        top = next(p for p in Path(tmp).iterdir() if p.is_dir())
        MOTION_ROOT.mkdir(parents=True, exist_ok=True)
        for child in top.iterdir():
            target = MOTION_ROOT / child.name
            if not target.exists():
                shutil.move(str(child), str(target))
    if not _motion_ok():
        raise RuntimeError("制作工程下载不完整，请检查网络后再试")


def _fetch_ffmpeg() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        archive = _download(FFMPEG_ZIP, Path(tmp) / "ffmpeg.zip")
        with zipfile.ZipFile(archive) as zf:
            for name in zf.namelist():
                if name.endswith(("/bin/ffmpeg.exe", "/bin/ffprobe.exe")):
                    FFMPEG_DIR.mkdir(parents=True, exist_ok=True)
                    with zf.open(name) as src, (FFMPEG_DIR / Path(name).name).open("wb") as dst:
                        shutil.copyfileobj(src, dst)
    if not _ffmpeg_ok():
        raise RuntimeError("FFmpeg 下载不完整，请检查网络后再试")


def _fetch_speech() -> None:
    archive = _download(SPEECH_TAR, TOOLS / "downloads" / "sensevoice.tar.bz2")
    SPEECH_DIR.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, "r:bz2") as tar:
        for member in tar.getmembers():
            name = Path(member.name).name
            if member.isfile() and (name.endswith(".onnx") or name == "tokens.txt"):
                member.name = name
                tar.extract(member, SPEECH_DIR)
    archive.unlink(missing_ok=True)
    if not _speech_ok():
        raise RuntimeError("语音识别模型下载不完整，请检查网络后再试")


def warm() -> None:
    """Run the slow doctor check in the background at server start so the first page load is instant."""
    threading.Thread(target=lambda: status(refresh=True), daemon=True).start()
