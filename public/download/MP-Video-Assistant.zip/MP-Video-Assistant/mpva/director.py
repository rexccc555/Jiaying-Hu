"""AI Director: understand speech, emit Edit Plan visuals. Never invent spoken words."""

from __future__ import annotations

import json
import os
import re

from mpva.captions import card_blurb, duration_limit, hook_title
from mpva.edit_plan import COMPONENTS, quote_is_safe
from mpva.llm import chat_json, configured

_NUM = re.compile(
    r"(?<!\w)((?:\$\s*)?(?:\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+\s*(?:trillion|billion|million|亿|万|%|％)|\d{2,}))",
    re.I,
)


def direct(plan: dict, *, mode: str) -> dict:
    render_mode = "clean" if mode == "formal" else mode
    transcript = plan.get("edited_transcript") or plan.get("original_transcript") or ""
    topic = (plan.get("clip") or {}).get("topic") or "Update"
    visuals = _base_visuals(plan, topic, render_mode)
    visuals.extend(_heuristic_visuals(plan, transcript, topic, render_mode))
    extras = _llm_visuals(plan, transcript, topic, render_mode)
    visuals.extend(extras)
    plan["visuals"] = _sanitize_visuals(
        visuals, transcript, render_mode, plan.get("duration") or 0, plan=plan
    )
    plan["captions"] = _emphasize(plan.get("captions") or [], topic, render_mode)
    plan["mode"] = render_mode
    return plan


def _named_brand(plan: dict) -> bool:
    name = str((plan.get("brand") or {}).get("name") or "").strip()
    return bool(name) and name != "Member of Parliament"


def _base_visuals(plan: dict, topic: str, mode: str) -> list[dict]:
    if mode == "clean":
        return []
    hook = hook_title(topic, 12) or topic[:12]
    items = [{"time": 0.12, "component": "Headline", "text": hook, "duration": 2.2}]
    if _named_brand(plan) and mode == "enhanced":
        brand = plan.get("brand") or {}
        items.append(
            {
                "time": 0.35,
                "component": "LowerThird",
                "text": brand.get("name"),
                "meta": brand.get("role") or "",
                "duration": 3.6,
            }
        )
    return items


def _heuristic_visuals(plan: dict, transcript: str, topic: str, mode: str) -> list[dict]:
    if mode == "clean":
        return []
    out = []
    duration = float(plan.get("duration") or 8)
    match = _NUM.search(transcript)
    if match:
        out.append({"time": min(12.4, max(4.0, duration * 0.28)), "component": "BigNumber", "text": match.group(0), "duration": 3.2})
    if mode == "enhanced":
        quote = _short_quote(transcript)
        if quote:
            out.append({"time": min(18.0, max(6.0, duration * 0.45)), "component": "Quote", "text": quote, "duration": 3.6})
    return out


def _llm_visuals(plan: dict, transcript: str, topic: str, mode: str) -> list[dict]:
    if mode == "clean" or not configured() or len(transcript) < 20:
        return []
    try:
        parsed = chat_json(
            (
                "You cut overlays for short social video. "
                "Do not invent spoken words. Do not score political opinions. "
                "No EndCard, no logo sting, no progress bar, no Member of Parliament lower-third. "
                "Allowed: Headline, Quote. Quote.text MUST be copied verbatim and stay under 18 characters. "
                "Headline is a 2-8 character hook, not the full transcript. "
                "Times are seconds on the CUT timeline. "
                "Return JSON {visuals:[{time,component,text,duration}]}."
            ),
            json.dumps(
                {
                    "topic": topic,
                    "duration": plan.get("duration"),
                    "brief": (plan.get("brief") or "")[:400],
                    "transcript": transcript[:4000],
                    "rules": "Follow the staff brief. No end card. Headline max 12 characters. Quote must be verbatim.",
                },
                ensure_ascii=False,
            ),
            timeout=40,
        )
        return list(parsed.get("visuals") or [])
    except Exception:
        return []


def _sanitize_visuals(visuals: list[dict], transcript: str, mode: str, duration: float, plan: dict | None = None) -> list[dict]:
    plan = plan or {}
    brief = str(plan.get("brief") or "")
    allowed = {"Headline", "Captions"}
    if mode in {"social", "enhanced"}:
        allowed.update({"Quote", "BigNumber"})
    if mode == "enhanced":
        allowed.update({"ImageCard", "Broll", "Location", "SplitScreen"})
    if _named_brand(plan):
        allowed.update({"LowerThird", "Logo"})
    if re.search(r"片尾|关注我|end ?card", brief, re.I):
        allowed.add("EndCard")
    seen = set()
    out = []
    for item in visuals:
        component = str(item.get("component") or "")
        if component not in COMPONENTS or component not in allowed:
            continue
        text = str(item.get("text") or "").strip()
        if component == "Headline":
            text = hook_title(text, 12) or text[:12]
        if component == "Quote":
            if not quote_is_safe(text, transcript):
                continue
            if len(re.sub(r"\s+", "", text)) > 22:
                text = _short_quote(text) or text[:18]
                if not quote_is_safe(text, transcript):
                    continue
        if component == "BigNumber":
            if not _NUM.search(text or ""):
                continue
            compact = re.sub(r"\s+", "", text)
            if compact in {"1", "0"}:
                continue
            if text not in transcript and compact not in re.sub(r"\s+", "", transcript):
                continue
        if component == "Headline" and any(row["component"] == "Headline" for row in out):
            continue
        if component == "LowerThird" and text in {"", "Member of Parliament"}:
            continue
        time = max(0.0, float(item.get("time") or 0))
        dur = max(0.8, float(item.get("duration") or 2.8))
        if component == "Headline":
            dur = min(dur, 2.4)
        key = (component, round(time, 1), text)
        if key in seen:
            continue
        seen.add(key)
        row = {
            "time": round(min(time, max(0.0, duration - 0.4)), 2),
            "component": component,
            "text": text,
            "duration": round(dur, 2),
        }
        if item.get("meta"):
            row["meta"] = str(item["meta"])
        out.append(row)
    out.sort(key=lambda row: (row["time"], row["component"]))
    return out[:16]


def _emphasize(captions: list[dict], topic: str, mode: str) -> list[dict]:
    if mode == "clean":
        return captions
    keys = [part.lower() for part in re.split(r"\s+", topic) if len(part) > 3]
    if topic:
        keys.append(topic.lower())
    out = []
    for item in captions:
        row = dict(item)
        text = str(row.get("text") or "").lower()
        row["emphasis"] = any(key in text or text in key for key in keys if key)
        out.append(row)
    return out


def _short_quote(transcript: str) -> str:
    parts = re.split(r"[.!?。！？，,]", transcript)
    for part in parts:
        text = part.strip(" \"'“”")
        n = len(re.sub(r"\s+", "", text))
        if 4 <= n <= 22:
            return text
    return ""


def plan_from_assets(assets: list[dict], *, title: str = "", brief: str = "") -> dict:
    videos = [item for item in assets if item.get("kind") == "video"]
    speeches = [item for item in assets if item.get("speech") or item.get("role") == "speech"]
    intent = _classify_intent(assets, videos, speeches)
    heading = title or "Update"
    if intent == "interview":
        from mpva.clean import run_clean
        from mpva.viewpoints import complete_span, find_viewpoints

        lead = max(speeches or videos, key=lambda item: (len(item.get("transcript") or ""), float(item.get("duration") or 0)))
        words = run_clean(lead.get("words") or [])
        for word in words:
            if word.get("suggested_cut") and word.get("kind") in {"filler", "repeat"} and word.get("override") is None:
                word["override"] = "cut"
        clips = find_viewpoints(words, float(lead.get("duration") or 0), brief=brief)[:4]
        limit = duration_limit(brief, float(lead.get("duration") or 0))
        if not clips:
            start, end, text = complete_span(
                words,
                float(lead.get("duration") or 0),
                target=float(limit or 32),
                max_s=float(limit or 40),
            )
            clips = [
                {
                    "id": "clip01",
                    "topic": hook_title(text or heading, 12) or "Remarks",
                    "title": hook_title(text or heading, 12) or "Remarks",
                    "start": round(start, 2),
                    "end": round(end, 2),
                    "seconds": round(end - start, 1),
                    "summary": (text or lead.get("transcript") or "")[:280],
                    "source_label": lead.get("file") or "",
                }
            ]
        named = bool(os.environ.get("MP_DISPLAY_NAME"))
        for clip in clips:
            if limit and float(clip.get("end") or 0) - float(clip.get("start") or 0) > limit:
                clip["end"] = round(float(clip["start"]) + limit, 2)
                clip["seconds"] = round(limit, 1)
            topic = hook_title(clip.get("topic") or clip.get("summary") or heading, 12) or heading
            clip["kind"] = "speech"
            clip["topic"] = topic
            clip["title"] = topic
            clip["caption"] = card_blurb(clip.get("summary") or "")
            clip["source_asset"] = lead.get("id")
            clip["show_logo"] = named
            clip["show_name"] = named
            clip["caption_style"] = "clean"
            clip["trim_in"] = 0
            clip["trim_out"] = 0
        return {"intent": "interview", "lead": lead.get("id"), "words": words, "clips": clips, "title": heading}
    from mpva.story import build_schemes, event_title

    heading = event_title(title, brief, assets)
    schemes = build_schemes(assets, target_seconds=60, title=heading, brief=brief)
    drafts = []
    for clip, letter in zip(schemes[:3], "ABC"):
        clip["id"] = f"draft{letter}"
        clip["topic"] = heading
        clip["title"] = heading
        clip["kind"] = "draft"
        clip["show_logo"] = bool(os.environ.get("MP_DISPLAY_NAME"))
        clip["show_name"] = bool(os.environ.get("MP_DISPLAY_NAME"))
        clip["caption"] = card_blurb(clip.get("summary") or clip.get("title") or "")
        clip["caption_style"] = "clean"
        drafts.append(clip)
    return {"intent": "event", "lead": None, "words": [], "clips": drafts, "title": heading}


def _classify_intent(assets: list[dict], videos: list[dict], speeches: list[dict]) -> str:
    guessed = "interview"
    if len(videos) >= 3 or any(item.get("kind") == "photo" for item in assets):
        guessed = "event"
    elif speeches:
        lead = max(speeches, key=lambda item: float(item.get("duration") or 0))
        if float(lead.get("duration") or 0) >= 60 and len(videos) <= 2:
            guessed = "interview"
        elif len(videos) > 1:
            guessed = "event"
    decided = _llm_intent(assets, guessed)
    return decided or guessed


def _llm_intent(assets: list[dict], guessed: str) -> str:
    if not configured():
        return guessed
    summary = []
    for item in assets:
        summary.append(
            {
                "id": item.get("id"),
                "file": item.get("file"),
                "duration": item.get("duration"),
                "speech": item.get("speech"),
                "role": item.get("role"),
                "description": item.get("visual_description"),
                "transcript": (item.get("transcript") or "")[:240],
            }
        )
    try:
        parsed = chat_json(
            (
                "Classify a batch of political-office media. "
                "Return JSON {intent: interview|event}. "
                "interview = one talking-head speech/interview to split into topic clips. "
                "event = multiple shots/photos of the same activity to make one recap. "
                "Do not rank political views."
            ),
            json.dumps({"guess": guessed, "assets": summary}, ensure_ascii=False)[:8000],
            timeout=40,
        )
        intent = str(parsed.get("intent") or guessed)
        return intent if intent in {"interview", "event"} else guessed
    except Exception:
        return guessed
