from __future__ import annotations

import copy
import os
import threading
from pathlib import Path
from typing import Any

from fastapi import Body, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.cors import CORSMiddleware

from mpva import autopilot, envcheck
from mpva.captions import card_blurb
from mpva.envfile import load_env
from mpva.jobs import create_job, get, save
from mpva.paths import ROOT, UPLOADS, WEB
from mpva.pipeline import export_job, generate, patch_clip, preview_clip, regenerate, try_another
from mpva.render import PRESETS, STYLES

load_env(ROOT)

PORT = int(os.environ.get("MPVA_PORT") or 1780)
LOCAL_ORIGINS = [f"http://127.0.0.1:{PORT}", f"http://localhost:{PORT}"]
VIDEO_EXT = {".mp4", ".mov", ".mkv", ".m4v", ".webm", ".avi"}


def create_app() -> FastAPI:
    app = FastAPI(title="MP Video Assistant")
    app.add_middleware(CORSMiddleware, allow_origins=LOCAL_ORIGINS, allow_methods=["*"], allow_headers=["*"])

    @app.middleware("http")
    async def local_only(request: Request, call_next):
        origin = request.headers.get("origin")
        if request.method not in {"GET", "HEAD", "OPTIONS"} and origin and origin not in LOCAL_ORIGINS:
            return JSONResponse({"detail": "Only this computer can control the assistant."}, status_code=403)
        return await call_next(request)

    @app.get("/api/env")
    def env_status(refresh: str = "0") -> dict[str, Any]:
        return envcheck.status(refresh=_flag(refresh))

    @app.post("/api/env/fix")
    def env_fix() -> dict[str, Any]:
        return envcheck.fix_all()

    @app.post("/api/agents/{name}/install")
    def install_agent(name: str) -> dict[str, Any]:
        try:
            autopilot.install(name)
        except RuntimeError as exc:
            raise HTTPException(400, str(exc)) from exc
        return list_agents()

    @app.post("/api/agents/{name}/login")
    def login_agent(name: str) -> dict[str, Any]:
        try:
            autopilot.login(name)
        except RuntimeError as exc:
            raise HTTPException(400, str(exc)) from exc
        return {"ok": True}

    @app.post("/api/jobs")
    async def upload(
        files: list[UploadFile] = File(default=[]),
        file: UploadFile | None = File(default=None),
        language: str = Form("auto"),
        title: str = Form(""),
        brief: str = Form(""),
        auto_film: str = Form("0"),
        agent: str = Form(""),
        refs: list[UploadFile] = File(default=[]),
    ) -> dict[str, Any]:
        incoming = [item for item in files if item and item.filename]
        if file and file.filename:
            incoming = incoming or [file]
        if not incoming:
            raise HTTPException(400, "Drop at least one video or photo.")
        UPLOADS.mkdir(parents=True, exist_ok=True)
        job = create_job(incoming[0].filename or "Upload", UPLOADS / "pending")
        folder = UPLOADS / job["id"]
        folder.mkdir(parents=True, exist_ok=True)
        saved = []
        for index, item in enumerate(incoming):
            data = await item.read()
            if len(data) < 32:
                continue
            suffix = Path(item.filename or f"file{index}.mp4").suffix or ".mp4"
            name = Path(item.filename or f"clip{index}{suffix}").name
            dest = folder / name
            if dest.exists():
                dest = folder / f"{index}_{name}"
            dest.write_bytes(data)
            saved.append(dest)
        if not saved:
            raise HTTPException(400, "Those files were too small.")
        video = next((path for path in saved if path.suffix.lower() in VIDEO_EXT), saved[0])
        job["video"] = str(video)
        job["language"] = (language or "auto").strip().lower()
        job["title"] = (title or Path(incoming[0].filename or "Update").stem).strip()
        job["brief"] = (brief or "").strip()[:800]
        job["refs"] = await _save_refs(refs, UPLOADS / f"{job['id']}_refs")
        job["auto_film"] = _flag(auto_film)
        job["agent_runner"] = (agent or "").strip().lower()
        job["log"] = [f"{len(saved)} file(s) received."]
        job["steps"] = []
        save(job)
        return _public(job)

    @app.get("/api/jobs/{job_id}")
    def read_job(job_id: str) -> dict[str, Any]:
        job = get(job_id)
        if not job:
            raise HTTPException(404, "Job not found")
        return _public(job)

    @app.get("/api/jobs/{job_id}/source")
    def source_video(job_id: str) -> FileResponse:
        job = get(job_id)
        if not job:
            raise HTTPException(404, "Job not found")
        path = Path(job["video"])
        if not path.is_file():
            raise HTTPException(404, "Source missing")
        return FileResponse(path, filename=path.name)

    @app.post("/api/jobs/{job_id}/generate")
    def start_generate(job_id: str) -> dict[str, Any]:
        job = get(job_id)
        if not job:
            raise HTTPException(404, "Job not found")
        if job.get("status") == "working":
            return _public(job)
        threading.Thread(target=_safe, args=(generate, job_id), daemon=True).start()
        job["status"] = "working"
        save(job)
        return _public(job)

    @app.get("/api/agents")
    def list_agents() -> dict[str, Any]:
        return {"runners": autopilot.runners(), "default": autopilot.default_runner(), "node": autopilot.node_status()}

    @app.post("/api/jobs/{job_id}/film")
    def start_film(job_id: str, payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
        try:
            job = autopilot.start(job_id, str(payload.get("agent") or "") or None)
        except RuntimeError as exc:
            raise HTTPException(400, str(exc)) from exc
        return _public(job)

    @app.post("/api/jobs/{job_id}/film/cancel")
    def cancel_film(job_id: str) -> dict[str, Any]:
        try:
            return _public(autopilot.cancel(job_id))
        except RuntimeError as exc:
            raise HTTPException(404, str(exc)) from exc

    @app.post("/api/jobs/{job_id}/regenerate")
    def start_regenerate(job_id: str, payload: dict[str, Any] = Body(default={})) -> dict[str, Any]:
        job = get(job_id)
        if not job:
            raise HTTPException(404, "Job not found")
        clip_id = str(payload.get("clip_id") or "") or None
        brief = payload.get("brief")
        kwargs = {}
        if brief is not None:
            kwargs["brief"] = str(brief)[:800]
        threading.Thread(target=_safe, args=(regenerate, job_id, clip_id), kwargs=kwargs, daemon=True).start()
        job["status"] = "working"
        save(job)
        return _public(job)

    @app.post("/api/jobs/{job_id}/clips/{clip_id}/again")
    def do_again(job_id: str, clip_id: str) -> dict[str, Any]:
        job = get(job_id)
        if not job:
            raise HTTPException(404, "Job not found")
        threading.Thread(target=_safe, args=(try_another, job_id, clip_id), daemon=True).start()
        job["status"] = "rendering"
        save(job)
        return _public(job)

    @app.post("/api/jobs/{job_id}/clips/{clip_id}/edit")
    def do_edit(job_id: str, clip_id: str, payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        job = get(job_id)
        if not job:
            raise HTTPException(404, "Job not found")
        threading.Thread(target=_safe, args=(patch_clip, job_id, clip_id, payload), daemon=True).start()
        job["status"] = "rendering"
        save(job)
        return _public(job)

    @app.post("/api/jobs/{job_id}/clips/{clip_id}/preview")
    def do_preview(
        job_id: str,
        clip_id: str,
        mode: str = Form("clean"),
        accept_pending: str = Form("1"),
    ) -> dict[str, Any]:
        chosen = mode if mode in STYLES else "clean"
        threading.Thread(
            target=_safe,
            args=(preview_clip, job_id, clip_id),
            kwargs={"mode": chosen, "accept_pending": _flag(accept_pending)},
            daemon=True,
        ).start()
        job = get(job_id)
        if job:
            job["status"] = "rendering"
            save(job)
            return _public(job)
        raise HTTPException(404, "Job not found")

    @app.post("/api/jobs/{job_id}/clips/{clip_id}/export")
    def do_export(
        job_id: str,
        clip_id: str,
        presets: str = Form("vertical"),
        mode: str = Form("clean"),
        accept_pending: str = Form("1"),
    ) -> dict[str, Any]:
        keys = [part.strip() for part in presets.split(",") if part.strip() in PRESETS] or ["vertical"]
        chosen = mode if mode in STYLES else "clean"
        threading.Thread(
            target=_safe,
            args=(export_job, job_id, clip_id, keys),
            kwargs={"mode": chosen, "accept_pending": _flag(accept_pending)},
            daemon=True,
        ).start()
        job = get(job_id)
        if job:
            job["status"] = "exporting"
            save(job)
            return _public(job)
        raise HTTPException(404, "Job not found")

    @app.get("/api/jobs/{job_id}/file/{clip_id}/{name}")
    def download(job_id: str, clip_id: str, name: str) -> FileResponse:
        allowed = {f"{key}.mp4" for key in PRESETS} | {
            "pack.json",
            "edit_plan.json",
            "jianying_draft.zip",
            "source.srt",
            "PROMPT.txt",
            "final.mp4",
        }
        if name not in allowed:
            raise HTTPException(400, "Unknown file")
        job = get(job_id)
        if not job:
            raise HTTPException(404, "Job not found")
        folder = Path(job["video"]).parent / clip_id
        path = folder / name
        if name == "edit_plan.json":
            path = folder / "jianying_draft" / "edit_plan.json"
        if not path.is_file():
            raise HTTPException(404, "File not ready")
        return FileResponse(path, filename=name)

    if WEB.is_dir():
        app.mount("/", StaticFiles(directory=str(WEB), html=True), name="web")
    return app


REF_EXT = VIDEO_EXT | {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"}


async def _save_refs(items: list[UploadFile], folder: Path) -> list[str]:
    saved = []
    for index, item in enumerate(item for item in items if item and item.filename):
        suffix = Path(item.filename).suffix.lower()
        if suffix not in REF_EXT or index >= 3:
            continue
        data = await item.read()
        if len(data) < 32:
            continue
        folder.mkdir(parents=True, exist_ok=True)
        dest = folder / f"ref{index + 1}{suffix}"
        dest.write_bytes(data)
        saved.append(str(dest))
    return saved


def _flag(value: str) -> bool:
    return str(value).strip().lower() not in {"0", "false", "no", "off", ""}


def _safe(fn, *args, **kwargs) -> None:
    job_id = args[0]
    try:
        fn(*args, **kwargs)
    except Exception as exc:
        job = get(job_id)
        if not job:
            return
        job["status"] = "failed"
        job["error"] = str(exc)
        job.setdefault("log", []).append(str(exc))
        save(job)


def _public(job: dict) -> dict[str, Any]:
    data = copy.deepcopy(job)
    data.pop("video", None)
    data.pop("alts", None)
    data.pop("words", None)
    data["refs"] = [Path(path).name for path in job.get("refs") or []]
    data["motion_prompt"] = job.get("motion_prompt") or ""
    if job.get("agent"):
        agent = {key: value for key, value in job["agent"].items() if key not in {"log", "source"}}
        agent["tail"] = autopilot.log_tail(job)
        if agent.get("state") == "queued":
            agent["ahead"] = autopilot.ahead_of(job["id"])
        if agent.get("state") == "running":
            agent["phase"] = autopilot.phase(job)
        agent["estimate_min"] = autopilot.estimate_minutes(job.get("duration") or 0)
        data["agent"] = agent
    assets = []
    for item in data.get("assets") or []:
        row = {key: value for key, value in item.items() if key not in {"path", "words", "keyframes"}}
        row["word_count"] = len(item.get("words") or [])
        row["frame_count"] = len(item.get("keyframes") or [])
        assets.append(row)
    data["assets"] = assets
    clips = []
    for clip in data.get("clips") or []:
        story = clip.get("story")
        if story:
            beats = []
            for beat in story.get("beats") or []:
                row = dict(beat)
                for key in ("video", "audio"):
                    if row.get(key):
                        row[key] = {k: v for k, v in row[key].items() if k != "path"}
                if row.get("photos"):
                    row["photos"] = [{k: v for k, v in photo.items() if k != "path"} for photo in row["photos"]]
                beats.append(row)
            clip = dict(clip)
            clip["story"] = {"title": story.get("title"), "target": story.get("target"), "beats": beats}
        plan = clip.get("edit_plan") or {}
        clip["caption"] = clip.get("caption") or card_blurb(clip.get("summary") or clip.get("title") or "")
        clip["suggested_title"] = clip.get("topic") or clip.get("title") or ""
        clip["transcript_text"] = plan.get("edited_transcript") or clip.get("summary") or ""
        if isinstance(clip.get("edit_plan"), dict) and "keep" in clip["edit_plan"]:
            clip["edit_plan"] = {
                "captions": (clip["edit_plan"].get("captions") or [])[:40],
                "duration": clip["edit_plan"].get("duration"),
                "titles": clip["edit_plan"].get("titles") or [],
            }
        clips.append(clip)
    data["clips"] = clips
    return data
