"""Run a local coding agent (Codex / Cursor CLI / Claude Code) on a staged Agent Motion film.

The agent uses the user's own login and quota. We only launch it and collect the MP4.
"""

from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from mpva.jobs import get, save
from mpva.motion import MOTION_ROOT
from mpva.paths import FFMPEG_DIR

ACTIVE = {"queued", "running"}
_run_lock = threading.Lock()
_procs: dict[str, subprocess.Popen] = {}

RUNNERS = {
    "codex": {
        "label": "Codex CLI",
        "exe": ["codex"],
        "args": ["exec", "--skip-git-repo-check", "--dangerously-bypass-approvals-and-sandbox"],
        "install": "npm install -g @openai/codex",
        "login": "codex login",
        "login_args": ["login"],
        "status_args": ["login", "status"],
    },
    "cursor": {
        "label": "Cursor CLI",
        "exe": ["agent", "cursor-agent"],
        "args": ["-p", "--force", "--output-format", "stream-json"],
        "install": "irm 'https://cursor.com/install?win32=true' | iex",
        "login": "agent login",
        "login_args": ["login"],
        "status_args": ["status"],
    },
    "claude": {
        "label": "Claude Code",
        "exe": ["claude"],
        "args": ["-p", "--dangerously-skip-permissions", "--output-format", "stream-json", "--verbose"],
        "install": "npm install -g @anthropic-ai/claude-code",
        "login": "claude",
        "login_args": [],
        "status_args": None,
    },
}

# Our own gateway settings must not leak into the user's agent login.
_PRIVATE_ENV = ("OPENAI_API_KEY", "OPENAI_BASE_URL", "OPENAI_MODEL")
_installs: dict[str, dict] = {}
_status_cache: dict[str, tuple[float, bool | None]] = {}


def _search_path() -> str:
    """PATH plus the user/machine PATH from the registry, so a CLI installed after startup is found."""
    parts = [os.environ.get("PATH", ""), str(FFMPEG_DIR)]
    if os.name == "nt":
        import winreg

        for hive, key in (
            (winreg.HKEY_CURRENT_USER, "Environment"),
            (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"),
        ):
            try:
                with winreg.OpenKey(hive, key) as handle:
                    parts.append(os.path.expandvars(winreg.QueryValueEx(handle, "Path")[0]))
            except OSError:
                pass
        appdata = os.environ.get("APPDATA")
        if appdata:
            parts.append(str(Path(appdata) / "npm"))
        local = os.environ.get("LOCALAPPDATA")
        if local:
            parts.append(str(Path(local) / "cursor-agent"))
    return os.pathsep.join(part for part in parts if part)


def _exe(name: str) -> str | None:
    path = _search_path()
    for candidate in RUNNERS[name]["exe"]:
        found = shutil.which(candidate, path=path)
        if found:
            return found
    return None


def _signed_in(name: str, exe: str) -> bool | None:
    args = RUNNERS[name].get("status_args")
    if args is None:
        return None
    cached = _status_cache.get(name)
    if cached and time.time() - cached[0] < 30:
        return cached[1]
    try:
        result = subprocess.run(
            [exe, *args], capture_output=True, text=True, timeout=20, encoding="utf-8", errors="replace", env=_agent_env()
        )
        text = f"{result.stdout}\n{result.stderr}".lower()
        value = result.returncode == 0 and not any(word in text for word in ("not logged in", "not authenticated", "login required"))
    except (OSError, subprocess.TimeoutExpired):
        value = None
    _status_cache[name] = (time.time(), value)
    return value


def _agent_env() -> dict:
    if os.environ.get("MPVA_AGENT_KEEP_OPENAI") == "1":
        env = dict(os.environ)
    else:
        env = {key: value for key, value in os.environ.items() if key not in _PRIVATE_ENV}
    env["PATH"] = _search_path()
    env.setdefault("PYTHONIOENCODING", "utf-8")
    if "cursor-sandbox" in env.get("PLAYWRIGHT_BROWSERS_PATH", ""):
        env.pop("PLAYWRIGHT_BROWSERS_PATH")
    return env


def runners() -> list[dict]:
    custom = (os.environ.get("MPVA_AGENT_CMD") or "").strip()
    rows = []
    for name, spec in RUNNERS.items():
        exe = _exe(name)
        rows.append(
            {
                "id": name,
                "label": spec["label"],
                "available": bool(exe),
                "signed_in": _signed_in(name, exe) if exe else False,
                "install": spec["install"],
                "login": spec["login"],
                "installing": _installs.get(name, {}).get("state") == "running",
                "install_step": _installs.get(name, {}).get("step", ""),
                "install_error": _installs.get(name, {}).get("error", ""),
                "needs_node": name != "cursor",
            }
        )
    if custom:
        rows.append({"id": "custom", "label": "MPVA_AGENT_CMD", "available": True, "signed_in": None, "install": "", "login": ""})
    return rows


def node_status() -> dict:
    entry = _installs.get("node", {})
    return {
        "available": bool(_npm()),
        "installing": entry.get("state") == "running",
        "error": entry.get("error", ""),
    }


def _npm() -> str | None:
    return shutil.which("npm", path=_search_path())


def install(name: str) -> dict:
    if name != "node" and name not in RUNNERS:
        raise RuntimeError(f"未知的助手：{name}")
    if _installs.get(name, {}).get("state") == "running":
        return _installs[name]
    entry = {"state": "running", "error": "", "log": "", "step": ""}
    _installs[name] = entry
    threading.Thread(target=_install, args=(name,), daemon=True).start()
    return entry


def _install(name: str) -> None:
    entry = _installs[name]
    try:
        if name == "node" or (name != "cursor" and not _npm()):
            entry["step"] = "node"
            node = entry if name == "node" else {"state": "running", "error": ""}
            _installs["node"] = node
            _install_node()
            if not _npm():
                raise RuntimeError("Node.js 装完了但没找到 npm。请重启电脑后再点一次。")
            node["state"] = "done"
            if name == "node":
                entry["state"] = "done"
                return
        entry["step"] = name
        if name == "cursor":
            if os.name != "nt":
                command = ["bash", "-c", "curl https://cursor.com/install -fsS | bash"]
            else:
                command = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", RUNNERS[name]["install"]]
        else:
            command = [_npm() or "npm", *RUNNERS[name]["install"].split()[1:]]
        result = _quiet(command, timeout=900)
        entry["log"] = (result.stdout + "\n" + result.stderr)[-3000:]
        if result.returncode != 0 or not _exe(name):
            raise RuntimeError((result.stderr or result.stdout or "安装失败").strip()[-400:])
        entry["state"] = "done"
    except (OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
        entry["error"] = str(exc)[:400]
        entry["state"] = "failed"
        if entry.get("step") == "node" and name != "node":
            _installs["node"] = {"state": "failed", "error": entry["error"]}


def _quiet(command: list[str], *, timeout: float) -> subprocess.CompletedProcess:
    return subprocess.run(
        command, capture_output=True, text=True, timeout=timeout, encoding="utf-8", errors="replace", env=_agent_env()
    )


def _install_node() -> None:
    """Install Node.js LTS. Windows shows its own admin (UAC) prompt; the user must click Yes."""
    if os.name != "nt":
        raise RuntimeError("请先从 https://nodejs.org 安装 Node.js LTS")
    if shutil.which("winget", path=_search_path()):
        result = _quiet(
            [
                "winget", "install", "-e", "--id", "OpenJS.NodeJS.LTS",
                "--accept-source-agreements", "--accept-package-agreements", "--silent",
            ],
            timeout=1200,
        )
        if _npm():
            return
        if result.returncode == 0:
            return
    _install_node_msi()


def _install_node_msi() -> None:
    import json
    import tempfile
    import urllib.request

    with urllib.request.urlopen("https://nodejs.org/dist/index.json", timeout=30) as resp:
        releases = json.loads(resp.read().decode("utf-8"))
    version = next(item["version"] for item in releases if item.get("lts"))
    url = f"https://nodejs.org/dist/{version}/node-{version}-x64.msi"
    dest = Path(tempfile.gettempdir()) / f"node-{version}-x64.msi"
    if not dest.is_file():
        urllib.request.urlretrieve(url, dest)
    result = _quiet(["msiexec", "/i", str(dest), "/passive", "/norestart"], timeout=1200)
    if result.returncode not in (0, 3010):
        raise RuntimeError(f"Node.js 安装没完成（代码 {result.returncode}）。如果弹出管理员确认，请点「是」后再试。")


def login(name: str) -> None:
    """Open the agent's own sign-in in a visible window; the user finishes it in the browser."""
    exe = _exe(name) if name in RUNNERS else None
    if not exe:
        raise RuntimeError("先安装这个助手")
    _status_cache.pop(name, None)
    command = [exe, *RUNNERS[name]["login_args"]]
    if os.name == "nt":
        subprocess.Popen(command, env=_agent_env(), creationflags=subprocess.CREATE_NEW_CONSOLE)
    else:
        subprocess.Popen(command, env=_agent_env())


def default_runner() -> str | None:
    wanted = (os.environ.get("MPVA_AGENT") or "").strip().lower()
    available = [name for name in RUNNERS if _exe(name)]
    if (os.environ.get("MPVA_AGENT_CMD") or "").strip():
        available.append("custom")
    if wanted in available:
        return wanted
    return available[0] if available else None


def task_line(work_rel: str) -> str:
    return f"请完整读取并严格执行 {work_rel}PROMPT.txt 中的任务，全部完成后再结束。"


def build_command(name: str, work_rel: str) -> list[str]:
    line = task_line(work_rel)
    if name == "custom":
        template = os.environ.get("MPVA_AGENT_CMD") or ""
        return [
            _unquote(part).replace("{prompt}", line).replace("{prompt_file}", f"{work_rel}PROMPT.txt")
            for part in shlex.split(template, posix=False)
        ]
    if name not in RUNNERS:
        raise RuntimeError(f"未知的助手：{name}")
    exe = _exe(name)
    if not exe:
        spec = RUNNERS[name]
        raise RuntimeError(f"没找到 {spec['label']}。先运行：{spec['install']}，再运行：{spec['login']}")
    override = os.environ.get(f"MPVA_{name.upper()}_ARGS")
    args = [_unquote(part) for part in shlex.split(override, posix=False)] if override else list(RUNNERS[name]["args"])
    return [exe, *args, line]


def _unquote(part: str) -> str:
    if len(part) >= 2 and part[0] == part[-1] and part[0] in "\"'":
        return part[1:-1]
    return part


def find_film(work: Path, since: float = 0.0) -> Path | None:
    final = work / "final.mp4"
    if final.is_file() and final.stat().st_mtime >= since:
        return final
    skip = ("person", "matte", "preview", "alpha", "foreground", "frames")
    found = [
        path
        for path in work.rglob("*.mp4")
        if path.stat().st_mtime >= since and not any(word in path.as_posix().lower() for word in skip)
    ]
    return max(found, key=lambda path: path.stat().st_size) if found else None


def log_tail(job: dict, limit: int = 3000) -> str:
    path = Path(((job.get("agent") or {}).get("log")) or "")
    if not path.is_file():
        return ""
    with path.open("rb") as handle:
        handle.seek(0, os.SEEK_END)
        size = handle.tell()
        handle.seek(max(0, size - limit * 8))
        raw = handle.read().decode("utf-8", errors="replace")
    lines = [readable(line) for line in raw.splitlines()[1:] or raw.splitlines()]
    return "\n".join(line for line in lines if line)[-limit:]


def readable(line: str) -> str:
    """Turn one stream-json event (Cursor / Claude) into a short human line; plain text passes through."""
    text = line.strip()
    if not text.startswith("{"):
        return text
    try:
        event = json.loads(text)
    except ValueError:
        return text
    kind = event.get("type")
    if kind == "assistant":
        out = []
        for part in (event.get("message") or {}).get("content") or []:
            if part.get("type") == "text" and part.get("text", "").strip():
                out.append(part["text"].strip())
            elif part.get("type") == "tool_use":
                out.append("▶ " + _tool_brief(part.get("name", ""), part.get("input") or {}))
        return "\n".join(out)
    if kind == "tool_call" and event.get("subtype") == "started":
        call = event.get("tool_call") or {}
        name = next(iter(call), "")
        return "▶ " + _tool_brief(name.replace("ToolCall", ""), (call.get(name) or {}).get("args") or {})
    if kind == "result":
        return "■ " + str(event.get("result") or event.get("subtype") or "done")[:400]
    return ""


def _tool_brief(name: str, args: dict) -> str:
    for key in ("command", "path", "file_path", "pattern", "query", "url"):
        if args.get(key):
            return f"{name}: {str(args[key])[:160]}"
    return name


def start(job_id: str, runner: str | None = None) -> dict:
    job = get(job_id)
    if not job:
        raise RuntimeError("找不到任务")
    motion = job.get("motion") or {}
    if not motion.get("work"):
        raise RuntimeError("这个任务还没准备好字幕和提示词")
    previous = job.get("agent") or {}
    if previous.get("state") in ACTIVE:
        return job
    if previous.get("pid") and _alive(int(previous["pid"])):
        previous.update(state="running", error="")
        job["agent"] = previous
        save(job)
        return job
    name = runner or default_runner()
    if not name:
        raise RuntimeError("这台电脑还没装 AI 助手命令行（Codex / Cursor CLI / Claude Code）")
    work = Path(motion["work"])
    work_rel = Path(os.path.relpath(work, MOTION_ROOT)).as_posix().rstrip("/") + "/"
    command = build_command(name, work_rel)
    job["agent"] = {
        "runner": name,
        "state": "queued",
        "log": str(work / "agent.log"),
        "queued": _now(),
        "film": "",
        "error": "",
    }
    save(job)
    threading.Thread(target=_run, args=(job_id, command, work), daemon=True).start()
    return job


def cancel(job_id: str) -> dict:
    job = get(job_id)
    if not job:
        raise RuntimeError("找不到任务")
    proc = _procs.get(job_id)
    agent = job.get("agent") or {}
    if proc and proc.poll() is None:
        _kill(proc)
    elif agent.get("pid") and _alive(int(agent["pid"])):
        _kill_pid(int(agent["pid"]))
    if agent.get("state") in ACTIVE:
        agent["state"] = "cancelled"
        agent["ended"] = _now()
        job["agent"] = agent
        save(job)
    return job


def _run(job_id: str, command: list[str], work: Path) -> None:
    with _run_lock:
        job = get(job_id)
        if not job or (job.get("agent") or {}).get("state") != "queued":
            return
        _update(job_id, state="running", started=_now())
        began = time.time()
        log_path = work / "agent.log"
        env = _agent_env()
        limit = float(os.environ.get("MPVA_AGENT_TIMEOUT_MIN") or 150) * 60
        flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
        code: int | None = None
        error = ""
        try:
            with log_path.open("ab") as out:
                out.write(f"\n=== {_now()} {' '.join(command[:-1])} \n".encode("utf-8"))
                out.flush()
                proc = subprocess.Popen(
                    command,
                    cwd=str(MOTION_ROOT),
                    stdin=subprocess.DEVNULL,
                    stdout=out,
                    stderr=subprocess.STDOUT,
                    env=env,
                    creationflags=flags,
                )
                _procs[job_id] = proc
                _bind_to_server(proc)
                _update(job_id, pid=proc.pid)
                try:
                    code = proc.wait(timeout=limit)
                except subprocess.TimeoutExpired:
                    _kill(proc)
                    error = f"超过 {int(limit // 60)} 分钟仍未完成，已停止"
        except OSError as exc:
            error = f"无法启动助手：{exc}"
        finally:
            _procs.pop(job_id, None)
        if (get(job_id) or {}).get("agent", {}).get("state") == "cancelled":
            return
        film = find_film(work, began)
        if film:
            _deliver(job_id, film)
            return
        if not error:
            error = f"助手已结束（退出码 {code}），但没找到成片 MP4。看下方日志。"
        _update(job_id, state="failed", ended=_now(), error=error)


def _deliver(job_id: str, film: Path) -> None:
    job = get(job_id)
    if not job:
        return
    clip_dir = Path(job["video"]).parent / "film01"
    clip_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(film, clip_dir / "final.mp4")
    url = f"/api/jobs/{job_id}/file/film01/final.mp4"
    for clip in job.get("clips") or []:
        if clip.get("id") == "film01":
            clip["preview"] = url
            clip.setdefault("exports", {})["final"] = url
    job.setdefault("exports", {}).setdefault("film01", {})["final"] = url
    agent = job.get("agent") or {}
    agent.update(state="done", ended=_now(), film=url, source=str(film))
    job["agent"] = agent
    save(job)


def _update(job_id: str, **fields) -> None:
    job = get(job_id)
    if not job:
        return
    agent = job.get("agent") or {}
    agent.update(fields)
    job["agent"] = agent
    save(job)


def estimate_minutes(seconds: float) -> int:
    """Rough wall-clock for one film: mostly design and checking, which grows slowly with length."""
    return int(max(45, 40 + 1.4 * float(seconds or 0)))


def phase(job: dict) -> str:
    """Which stage the film is in, read from what the agent has produced so far."""
    work = Path(((job.get("motion") or {}).get("work")) or "")
    if not work.is_dir():
        return "cutout"
    if (work / "final.mp4").is_file() or (work / "render").is_dir():
        return "finish"
    if (work / "person" / "alpha.mp4").is_file():
        return "design"
    return "cutout"


def ahead_of(job_id: str) -> list[dict]:
    """Films running or queued before this one."""
    from mpva.paths import JOBS

    mine = ((get(job_id) or {}).get("agent") or {}).get("queued") or ""
    rows = []
    for path in JOBS.glob("*.json"):
        if path.stem == job_id:
            continue
        agent = (get(path.stem) or {}).get("agent") or {}
        if agent.get("state") == "running" or (agent.get("state") == "queued" and (agent.get("queued") or "") < mine):
            rows.append({"id": path.stem, "state": agent["state"], "started": agent.get("started") or ""})
    return rows


RESTART_NOTE = "网站重启，已停止。需要的话再点「让 AI 助手开始做」。"


def stop_leftovers() -> int:
    """On server start: kill agents left by a previous run and clear the queue. Returns how many were stopped."""
    from mpva.paths import JOBS

    stopped = 0
    for path in JOBS.glob("*.json"):
        job = get(path.stem)
        agent = (job or {}).get("agent") or {}
        if agent.get("state") not in ACTIVE:
            continue
        pid = int(agent.get("pid") or 0)
        if pid and _alive(pid):
            _kill_pid(pid)
        work = Path(((job.get("motion") or {}).get("work")) or "")
        since = datetime.fromisoformat(agent["started"]).timestamp() if agent.get("started") else time.time()
        film = find_film(work, since) if work.is_dir() else None
        if film:
            _deliver(job["id"], film)
        else:
            _update(job["id"], state="cancelled", ended=_now(), error=RESTART_NOTE)
        stopped += 1
    return stopped


def stop_all() -> None:
    """On server shutdown."""
    for proc in list(_procs.values()):
        if proc.poll() is None:
            _kill(proc)


_kill_job = None


def _bind_to_server(proc: subprocess.Popen) -> None:
    """Windows: put the agent in a Job Object that dies with this server process, even on crash or force-kill."""
    global _kill_job
    if os.name != "nt":
        return
    import ctypes
    from ctypes import wintypes

    kernel = ctypes.windll.kernel32
    if _kill_job is None:
        class Basic(ctypes.Structure):
            _fields_ = [
                ("PerProcessUserTimeLimit", ctypes.c_int64),
                ("PerJobUserTimeLimit", ctypes.c_int64),
                ("LimitFlags", wintypes.DWORD),
                ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t),
                ("ActiveProcessLimit", wintypes.DWORD),
                ("Affinity", ctypes.c_size_t),
                ("PriorityClass", wintypes.DWORD),
                ("SchedulingClass", wintypes.DWORD),
            ]

        class Io(ctypes.Structure):
            _fields_ = [(name, ctypes.c_uint64) for name in ("r", "w", "o", "rb", "wb", "ob")]

        class Extended(ctypes.Structure):
            _fields_ = [
                ("BasicLimitInformation", Basic),
                ("IoInfo", Io),
                ("ProcessMemoryLimit", ctypes.c_size_t),
                ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t),
                ("PeakJobMemoryUsed", ctypes.c_size_t),
            ]

        kernel.CreateJobObjectW.restype = wintypes.HANDLE
        handle = kernel.CreateJobObjectW(None, None)
        info = Extended()
        info.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        kernel.SetInformationJobObject(wintypes.HANDLE(handle), 9, ctypes.byref(info), ctypes.sizeof(info))
        _kill_job = handle
    kernel.OpenProcess.restype = wintypes.HANDLE
    target = kernel.OpenProcess(0x0100 | 0x0001, False, proc.pid)  # SET_QUOTA | TERMINATE
    if target:
        kernel.AssignProcessToJobObject(wintypes.HANDLE(_kill_job), wintypes.HANDLE(target))
        kernel.CloseHandle(wintypes.HANDLE(target))


def _alive(pid: int) -> bool:
    if os.name != "nt":
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    import ctypes

    kernel = ctypes.windll.kernel32
    handle = kernel.OpenProcess(0x1000, False, pid)
    if not handle:
        return False
    try:
        code = ctypes.c_ulong()
        return bool(kernel.GetExitCodeProcess(handle, ctypes.byref(code))) and code.value == 259
    finally:
        kernel.CloseHandle(handle)


def _kill(proc: subprocess.Popen) -> None:
    _kill_pid(proc.pid)


def _kill_pid(pid: int) -> None:
    if os.name == "nt":
        subprocess.run(["taskkill", "/T", "/F", "/PID", str(pid)], capture_output=True)
    else:
        os.kill(pid, 9)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()
