from __future__ import annotations

import re

from mpva.agent import edit_speech
from mpva.clean import join_text, sentence_groups

_PREAMBLE = re.compile(
    r"^(thank you|thanks|you guys|good morning|good afternoon|madam president|mr\.? speaker|"
    r"distinguished senator|please join|it'?s (an )?honou?r|yielding|counterparts|"
    r"大家好|谢谢大家|各位)",
    re.I,
)
_CLAUSE = re.compile(
    r"^(and|but|so|now|because|however|the|this|that|we|i|in|if)$",
    re.I,
)


def find_viewpoints(words: list[dict], duration: float, brief: str = "") -> list[dict]:
    speech = [item for item in words if item.get("kind") != "silence" and item.get("text") and not str(item["text"]).startswith("[")]
    clips, _model = edit_speech(speech, duration, brief=brief)
    if clips:
        return clips
    packed = _pack(speech, duration)
    spans = _sentence_spans(speech)
    return _snap_clips(packed, spans, duration) or packed


def complete_span(words: list[dict], duration: float, *, target: float = 32, max_s: float = 40, skip_before: float = 0.0) -> tuple[float, float, str]:
    sentences = _drop_preamble(_sentence_spans(words))
    sentences = [item for item in sentences if float(item["start"]) >= skip_before - 0.05]
    if not sentences:
        start = max(0.0, skip_before)
        end = min(duration or start + target, start + target)
        return start, max(start + 8.0, end), ""
    start = float(sentences[0]["start"])
    end = start
    parts = []
    for item in sentences:
        nxt = float(item["end"])
        if nxt - start > max_s and parts:
            break
        end = nxt
        parts.append(item["text"])
        if end - start >= target:
            break
    if end - start < 12:
        end = min(duration or end + target, start + target)
    return start, end, " ".join(parts)


def _pack(words: list[dict], duration: float, min_s: float = 20, max_s: float = 38) -> list[dict]:
    sentences = _drop_preamble(_sentence_spans(words))
    if not sentences:
        return []
    clips: list[dict] = []
    start_i = 0
    index = 1
    while start_i < len(sentences) and len(clips) < 4:
        start = sentences[start_i]["start"]
        end_i = start_i
        while end_i + 1 < len(sentences) and sentences[end_i + 1]["end"] - start <= max_s:
            end_i += 1
            if sentences[end_i]["end"] - start >= min_s:
                break
        if sentences[end_i]["end"] - start < min_s and end_i + 1 < len(sentences):
            end_i += 1
        end = min(duration or sentences[end_i]["end"], sentences[end_i]["end"])
        text = " ".join(item["text"] for item in sentences[start_i : end_i + 1])
        if end - start >= 14:
            clips.append(_clip(index, text, start, end))
            index += 1
        start_i = end_i + 1
    return clips


def _snap_clips(clips: list[dict], sentences: list[dict], duration: float) -> list[dict]:
    if not clips or not sentences:
        return clips
    starts = [item["start"] for item in sentences]
    ends = [item["end"] for item in sentences]
    out = []
    for index, clip in enumerate(clips, start=1):
        start = min(starts, key=lambda stamp: abs(stamp - float(clip["start"])))
        later = [stamp for stamp in ends if stamp > start + 14]
        if not later:
            continue
        wanted = min(float(clip["end"]), start + 38)
        end = min(later, key=lambda stamp: abs(stamp - wanted))
        if end - start < 14:
            end = later[0]
        if end - start > 42:
            capped = [stamp for stamp in later if 20 <= stamp - start <= 40]
            end = capped[-1] if capped else min(start + 38, later[-1])
        end = min(duration or end, end)
        text = " ".join(item["text"] for item in sentences if item["start"] >= start - 0.05 and item["end"] <= end + 0.05)
        row = _clip(index, text or clip.get("summary") or "", start, end)
        row["topic"] = clip.get("topic") or row["topic"]
        row["title"] = clip.get("title") or clip.get("topic") or row["topic"]
        out.append(row)
    return out


def _sentence_spans(words: list[dict]) -> list[dict]:
    out = []
    for group in sentence_groups(words, pause=0.55):
        for piece in _split_long_group(group):
            text = join_text(piece)
            if not text:
                continue
            out.append({"start": float(piece[0]["start"]), "end": float(piece[-1]["end"]), "text": text})
    return out


def _split_long_group(group: list[dict], max_s: float = 9.5) -> list[list[dict]]:
    if not group:
        return []
    if float(group[-1]["end"]) - float(group[0]["start"]) <= max_s:
        return [group]
    pieces: list[list[dict]] = [[group[0]]]
    for prev, item in zip(group, group[1:]):
        dur = float(item["end"]) - float(pieces[-1][0]["start"])
        gap = float(item["start"]) - float(prev["end"])
        word = str(item.get("text") or "")
        if dur >= max_s:
            pieces.append([item])
        elif dur >= 5.5 and (gap >= 0.32 or _CLAUSE.match(word)):
            pieces.append([item])
        else:
            pieces[-1].append(item)
    return pieces


def _drop_preamble(sentences: list[dict], limit: float = 28.0) -> list[dict]:
    i = 0
    while i < len(sentences) - 1 and sentences[i]["start"] < limit:
        text = sentences[i]["text"].strip()
        if _PREAMBLE.search(text) or _mostly_thanks(text):
            i += 1
            continue
        break
    return sentences[i:] or sentences


def _mostly_thanks(text: str) -> bool:
    lowered = text.lower()
    if any(token in lowered for token in ("thank you", "thanks", "yielding", "madam president", "distinguished senator")):
        return True
    hits = sum(1 for token in ("thank", "honor", "honour", "counterparts") if token in lowered)
    return hits >= 2


def _clip(index: int, text: str, start: float, end: float) -> dict:
    return {
        "id": f"clip{index:02d}",
        "topic": _topic(text, index),
        "title": _topic(text, index),
        "start": round(start, 2),
        "end": round(end, 2),
        "seconds": round(end - start, 1),
        "summary": text[:280],
        "source_label": _tc(start, end),
        "accepted": False,
    }


def _tc(start: float, end: float) -> str:
    def one(t: float) -> str:
        t = max(0.0, float(t))
        return f"{int(t // 60):02d}:{int(t % 60):02d}"

    return f"{one(start)}–{one(end)}"


def _topic(text: str, index: int) -> str:
    lowered = (text or "")[:180].lower()
    mapping = [
        ("hous", "Housing"),
        ("住房", "Housing"),
        ("房屋", "Housing"),
        ("health", "Health"),
        ("医疗", "Health"),
        ("卫生", "Health"),
        ("cost of living", "Cost of living"),
        ("生活成本", "Cost of living"),
        ("communit", "Community"),
        ("社区", "Community"),
        ("climate", "Climate"),
        ("气候", "Climate"),
        ("educat", "Education"),
        ("教育", "Education"),
        ("transport", "Transport"),
        ("交通", "Transport"),
        ("econom", "Economy"),
        ("经济", "Economy"),
        ("wall street", "Economy"),
        ("rescue", "Economy"),
        ("credit", "Economy"),
        ("job", "Jobs"),
        ("就业", "Jobs"),
        ("tax", "Tax"),
        ("税收", "Tax"),
        ("business", "Local businesses"),
        ("企业", "Local businesses"),
        ("商户", "Local businesses"),
    ]
    for needle, label in mapping:
        if needle in lowered:
            return label
    return f"Viewpoint {index}"
