from __future__ import annotations

import re

_PUNCT_END = tuple(".!?。！？")
_PUNCT_SOFT = tuple(",，;；:")


def collapse_repeats(words: list[dict]) -> list[dict]:
    out: list[dict] = []
    for item in words:
        text = str(item.get("text") or "").strip()
        if not text or text.startswith("["):
            continue
        if out and _same(out[-1]["text"], text) and float(item.get("start") or 0) <= float(out[-1]["end"]) + 0.85:
            out[-1]["end"] = max(float(out[-1]["end"]), float(item.get("end") or 0))
            continue
        row = dict(item)
        row["text"] = squeeze_cjk(text)
        out.append(row)
    return out


def pack_cues(
    words: list[dict],
    *,
    max_words: int = 22,
    max_chars: int = 96,
    max_sec: float = 8.5,
) -> list[dict]:
    items = collapse_repeats(words)
    cues: list[dict] = []
    buf: list[dict] = []

    def emit(chunk: list[dict]) -> None:
        if not chunk:
            return
        cjk = any(_cjk(item["text"]) for item in chunk)
        joiner = "" if cjk else " "
        cues.append(
            {
                "text": squeeze_cjk(joiner.join(item["text"] for item in chunk)),
                "start": round(float(chunk[0]["start"]), 3),
                "end": round(max(float(chunk[-1]["end"]), float(chunk[0]["start"]) + 0.8), 3),
                "emphasis": any(item.get("emphasis") for item in chunk),
            }
        )

    def flush(*, force: bool = False) -> None:
        if not buf:
            return
        text = buf[-1]["text"]
        last = text[-1] if text else ""
        dur = float(buf[-1]["end"]) - float(buf[0]["start"])
        chars = sum(len(row["text"]) for row in buf)
        too_long = dur >= max_sec or len(buf) >= max_words or chars >= max_chars
        if last in _PUNCT_END or force:
            emit(buf)
            buf.clear()
            return
        if too_long:
            split_at = next((i for i in range(len(buf) - 2, 3, -1) if buf[i]["text"][-1:] in _PUNCT_SOFT), None)
            if split_at:
                emit(buf[: split_at + 1])
                rest = buf[split_at + 1 :]
                buf.clear()
                buf.extend(rest)
                return
            emit(buf)
            buf.clear()

    for item in items:
        buf.append(item)
        flush()
    flush(force=True)
    return cues


def squeeze_cjk(text: str) -> str:
    if not text:
        return ""
    if not any("\u4e00" <= ch <= "\u9fff" for ch in text):
        return text
    return re.sub(r"(?<=[\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])", "", text)


def card_blurb(text: str, limit: int = 140) -> str:
    parts = [part for part in re.split(r"\s+", (text or "").strip()) if part]
    cleaned = []
    for part in parts:
        if cleaned and _same(cleaned[-1], part):
            continue
        cleaned.append(part)
    joined = squeeze_cjk(" ".join(cleaned))
    first = re.split(r"[.!?。！？]", joined, maxsplit=1)[0].strip(" ,，")
    if 12 <= len(first) <= limit:
        return first
    if len(joined) <= limit:
        return joined
    return joined[: limit - 1].rstrip() + "…"


def hook_title(text: str, limit: int = 12) -> str:
    raw = re.sub(r"\s+", "", (text or "").strip())
    if not raw:
        return ""
    parts = [part for part in re.split(r"[，,。！？!?、]", raw) if part]
    ranked = sorted(
        parts,
        key=lambda part: (
            0 if any(token in part for token in ("起飞", "谁懂", "太", "绝", "housing", "crisis")) else 1,
            abs(len(part) - 7),
        ),
    )
    pick = ranked[0] if ranked else raw
    if len(pick) <= limit:
        return pick
    return pick[:limit]


def duration_limit(brief: str, source: float = 0.0) -> float | None:
    match = re.search(r"(\d+(?:\.\d+)?)\s*(?:秒|s)(?:内|以内|左右)?", brief or "", re.I)
    if not match:
        return None
    limit = float(match.group(1))
    if source and source > 0:
        return min(limit, source)
    return limit


def _cjk(text: str) -> bool:
    return any("\u4e00" <= ch <= "\u9fff" for ch in text)


def _same(a: str, b: str) -> bool:
    return re.sub(r"[^\w\u4e00-\u9fff]+", "", a).lower() == re.sub(r"[^\w\u4e00-\u9fff]+", "", b).lower()
