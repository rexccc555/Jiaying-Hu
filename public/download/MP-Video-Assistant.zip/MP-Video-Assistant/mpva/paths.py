from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "mpva"
JOBS = DATA / "jobs"
UPLOADS = DATA / "uploads"
OUTPUTS = DATA / "outputs"
WEB = ROOT / "web_mpva"
TOOLS = ROOT / "tools"
FFMPEG_DIR = TOOLS / "ffmpeg" / "bin"
MODELS = ROOT / "data" / "models"
