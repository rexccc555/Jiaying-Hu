"""Media Intelligence: index every video/photo before the Director writes a script."""

from __future__ import annotations

import re
from pathlib import Path

from mpva.asr import transcribe_speech
from mpva.ffmpeg_tools import extract_wav, find_bin, probe, run

IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
VIDEO_EXT = {".mp4", ".mov", ".mkv", ".m4v", ".webm", ".avi"}

_ROLE_HINTS = (
    (("logo",), "logo"),
    (("握手", "handshake", "greeting"), "handshake"),
    (("合影", "group", "photo-op"), "group"),
    (("下车", "抵达", "到达", "入场", "走进", "arrival"), "arrival"),
    (("离场", "离开", "送别", "departure"), "leave"),
    (("群众", "crowd", "attendee", "交流", "游行"), "crowd"),
    (("参观", "walkthrough", "venue"), "broll"),
    (("讲话", "采访", "interview", "speech", "主机位", "keynote"), "speech"),
    (("手机", "phone", "vertical", "reels"), "phone"),
)


def index_folder(folder: Path, *, language: str = "auto", on_line=None) -> list[dict]:
    log = on_line or (lambda _line: None)
    files = sorted(
        [path for path in folder.iterdir() if path.is_file() and path.suffix.lower() in IMAGE_EXT | VIDEO_EXT],
        key=lambda path: path.name.lower(),
    )
    assets = []
    for index, path in enumerate(files):
        log(f"Indexing {path.name}")
        assets.append(analyze_file(path, asset_id=f"a{index+1:02d}", language=language, on_line=log))
    return assets


def analyze_file(path: Path, *, asset_id: str, language: str = "auto", on_line=None) -> dict:
    log = on_line or (lambda _line: None)
    suffix = path.suffix.lower()
    name = path.name
    kind = "photo" if suffix in IMAGE_EXT else "video"
    if kind == "photo":
        info = _image_probe(path)
        role = _role_from_name(name) or ("logo" if _looks_logo(name, info) else "photo")
        return {
            "id": asset_id,
            "file": name,
            "path": str(path),
            "kind": "logo" if role == "logo" else "photo",
            "duration": 0,
            "people": [],
            "scene": _scene_from_name(name),
            "speech": False,
            "shot": "still",
            "orientation": _orientation(info.get("width") or 1, info.get("height") or 1),
            "quality": {"sharpness": _sharpness(info), "stability": 1.0},
            "visual_description": _describe(name, role, False, ""),
            "usable_ranges": [],
            "transcript": "",
            "words": [],
            "role": role,
            "width": info.get("width") or 0,
            "height": info.get("height") or 0,
            "has_audio": False,
        }
    info = probe(path)
    width, height = info.get("width") or 0, info.get("height") or 0
    duration = float(info.get("duration") or 0)
    has_audio = bool(info.get("has_audio"))
    loudness = _loudness(path) if has_audio else -90.0
    words, transcript = [], ""
    speech = has_audio and loudness > -46 and duration >= 1.2
    if speech:
        try:
            wav = path.with_suffix(".wav")
            if not wav.is_file():
                extract_wav(path, wav)
            words, _, _ = transcribe_speech(wav, language=language, on_line=log)
            transcript = " ".join(item.get("text") or "" for item in words if not str(item.get("text") or "").startswith("["))
            if len(transcript.strip()) < 8:
                speech = False
        except Exception as exc:
            log(f"{name}: no transcript ({exc})")
            speech = False
    hinted = _role_from_name(name)
    if hinted:
        role = hinted
    elif speech:
        role = "speech"
    else:
        role = "broll"
    if role == "speech":
        people = ["speaker"]
    elif role in {"crowd", "handshake", "group", "arrival", "leave"}:
        people = ["speaker", "crowd"] if role != "crowd" else ["crowd"]
    else:
        people = ["crowd"] if not speech else ["speaker"]
    usable = _usable(duration, words, speech)
    return {
        "id": asset_id,
        "file": name,
        "path": str(path),
        "kind": "video",
        "duration": round(duration, 2),
        "people": people,
        "scene": _scene_from_name(name),
        "speech": speech,
        "shot": "medium" if min(width, height) >= 720 else "close",
        "orientation": _orientation(width, height),
        "quality": {"sharpness": _sharpness(info), "stability": 0.78 if role == "phone" else 0.88},
        "visual_description": _describe(name, role, speech, transcript),
        "usable_ranges": usable,
        "transcript": transcript[:4000],
        "words": words[:2500],
        "role": role,
        "width": width,
        "height": height,
        "has_audio": has_audio,
        "loudness": loudness,
    }


def main_speech(assets: list[dict]) -> dict | None:
    speeches = [item for item in assets if item.get("role") == "speech" or item.get("speech")]
    if not speeches:
        return None
    return max(speeches, key=lambda item: (len(item.get("transcript") or ""), item.get("duration") or 0))


def broll_assets(assets: list[dict]) -> list[dict]:
    lead = (main_speech(assets) or {}).get("id")
    out = []
    for item in assets:
        if item.get("kind") != "video":
            continue
        if item.get("id") == lead:
            continue
        if item.get("role") in {"logo", "speech"}:
            continue
        out.append(item)
    return out


def photo_assets(assets: list[dict]) -> list[dict]:
    return [item for item in assets if item.get("kind") == "photo"]


def logo_asset(assets: list[dict]) -> dict | None:
    return next((item for item in assets if item.get("kind") == "logo" or item.get("role") == "logo"), None)


def _role_from_name(name: str) -> str | None:
    lowered = name.lower()
    for needles, role in _ROLE_HINTS:
        if any(needle in lowered or needle in name for needle in needles):
            return role
    return None


def _scene_from_name(name: str) -> str:
    lowered = name.lower()
    mapping = [
        ("parliament", "parliament"),
        ("国会", "parliament"),
        ("school", "school"),
        ("学校", "school"),
        ("housing", "housing"),
        ("住房", "housing"),
        ("transport", "transport"),
        ("交通", "transport"),
        ("auckland", "auckland"),
        ("社区", "community_event"),
        ("community", "community_event"),
    ]
    for needle, scene in mapping:
        if needle in lowered or needle in name:
            return scene
    return "community_event"


def _orientation(width: int, height: int) -> str:
    if width <= 0 or height <= 0:
        return "unknown"
    ratio = width / height
    if ratio > 1.2:
        return "horizontal"
    if ratio < 0.85:
        return "vertical"
    return "square"


def _sharpness(info: dict) -> float:
    pixels = max(1, int(info.get("width") or 0) * int(info.get("height") or 0))
    return round(min(1.0, pixels / 2_000_000), 2)


def _looks_logo(name: str, info: dict) -> bool:
    if "logo" in name.lower():
        return True
    width, height = int(info.get("width") or 0), int(info.get("height") or 0)
    return bool(width and height and abs(width - height) < 40 and max(width, height) <= 1024)


def _describe(name: str, role: str, speech: bool, transcript: str) -> str:
    snippet = re.sub(r"\s+", " ", transcript).strip()[:80]
    if speech and snippet:
        return f"{role}: {snippet}"
    labels = {
        "speech": "Speaker on camera",
        "broll": "Event B-roll",
        "crowd": "Crowd / attendees",
        "handshake": "Greeting or handshake",
        "group": "Group photo moment",
        "arrival": "Arrival",
        "leave": "Leaving the event",
        "phone": "Handheld phone footage",
        "photo": "Still photograph",
        "logo": "Brand logo",
    }
    return f"{labels.get(role, role)} ({name})"


def _usable(duration: float, words: list[dict], speech: bool) -> list[list[float]]:
    if duration <= 0.4:
        return [[0.0, duration]] if duration > 0 else []
    if speech and words:
        start = max(0.0, float(words[0]["start"]))
        end = min(duration, float(words[-1]["end"]))
        if end - start >= 0.8:
            return [[round(start, 2), round(end, 2)]]
    pad = 0.35 if duration > 1.2 else 0.0
    return [[round(pad, 2), round(max(pad + 0.2, duration - pad), 2)]]


def _image_probe(path: Path) -> dict:
    try:
        info = probe(path)
        if info.get("width"):
            return info
    except Exception:
        pass
    return {"width": 1080, "height": 1080, "duration": 0, "has_audio": False}


def _loudness(path: Path) -> float:
    try:
        text = run(
            [find_bin("ffmpeg"), "-i", str(path), "-af", "volumedetect", "-f", "null", "-"],
            timeout=120,
        )
    except Exception:
        return -90.0
    match = re.search(r"mean_volume:\s*(-?\d+(?:\.\d+)?)", text)
    return float(match.group(1)) if match else -90.0
