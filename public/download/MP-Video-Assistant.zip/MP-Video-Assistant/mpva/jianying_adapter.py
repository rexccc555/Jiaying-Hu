"""Adapter: our edit_plan.json → Jianying Headless plan.

We do not vendor Jianying Headless. Its original code is personal/non-commercial;
commercial or office deployment needs the author's written permission.
The CLI only runs on Apple Silicon Mac + Jianying Pro 11.5 (or compatible 11.4.2).
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path


README = """MP Video Assistant — Jianying draft package
==============================================

1. This folder's edit_plan.json is OUR contract. Keep it.
2. jianying_plan.json is the Headless-shaped export. If Headless
   changes fields, only JianyingAdapter needs updating.

To build a native 剪映 draft on a matching Mac:

  export JIANYING_HEADLESS_ROOT=/absolute/path/to/jianying-headless
  python3 "$JIANYING_HEADLESS_ROOT/skills/yichen-jianying-edit/scripts/headless_draft.py" build \\
    --plan "/absolute/path/to/jianying_plan.json" --out "/absolute/path/to/jianying_build"

Requirements (upstream, not ours):
  Apple Silicon, macOS 26+, 剪映专业版 11.5.0 (11.4.2 has a compat config).
  Not an official Jianying SDK. Not Windows.

License: Jianying Headless original code is personal/non-commercial.
Get written authorization before institutional or commercial use.

Open the generated draft in 剪映专业版. Fix shots, captions, and timing there.
Do not publish unreviewed political copy.
"""


def write_draft(plan: dict, dest: Path) -> Path:
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "edit_plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    mapped = to_headless(plan)
    (dest / "jianying_plan.json").write_text(json.dumps(mapped, ensure_ascii=False, indent=2), encoding="utf-8")
    (dest / "OPEN_ON_MAC.txt").write_text(README, encoding="utf-8")
    _zip_draft(dest)
    return dest


def to_headless(plan: dict) -> dict:
    project = plan.get("project") or {}
    materials = []
    seen = {}
    clips_by_track: dict[str, list] = {}
    for item in plan.get("timeline") or []:
        source = str(item.get("source") or "")
        if source and source not in seen:
            mid = f"m{len(seen) + 1:02d}"
            seen[source] = mid
            kind = item.get("kind") or "video"
            materials.append({"id": mid, "path": source, "type": "image" if kind == "image" else ("audio" if kind == "audio" else "video")})
        track = item.get("track") or "main"
        clips_by_track.setdefault(track, []).append(
            {
                "material_id": seen.get(source, ""),
                "source_start": item.get("source_start"),
                "source_end": item.get("source_end"),
                "timeline_start": item.get("timeline_start"),
                "duration": item.get("duration"),
                "kind": item.get("kind") or "video",
            }
        )
    tracks = [{"name": name, "type": _track_type(name, rows), "clips": rows} for name, rows in clips_by_track.items()]
    if plan.get("captions"):
        tracks.append(
            {
                "name": "captions",
                "type": "text",
                "clips": [
                    {"text": row.get("text"), "timeline_start": row.get("start"), "duration": round(float(row.get("end") or 0) - float(row.get("start") or 0), 3)}
                    for row in plan.get("captions") or []
                ],
            }
        )
    if plan.get("titles"):
        tracks.append(
            {
                "name": "titles",
                "type": "text",
                "clips": [
                    {"text": row.get("text"), "timeline_start": row.get("start"), "duration": row.get("duration")}
                    for row in plan.get("titles") or []
                ],
            }
        )
    return {
        "name": project.get("name") or "Rough Cut",
        "canvas": {"width": int(project.get("width") or 1080), "height": int(project.get("height") or 1920), "fps": int(project.get("fps") or 30)},
        "materials": materials,
        "tracks": tracks,
        "notes": plan.get("notes") or "",
    }


def try_headless(draft_dir: Path) -> dict:
    root = Path(os.environ.get("JIANYING_HEADLESS_ROOT") or "")
    plan = draft_dir / "jianying_plan.json"
    if not root.is_dir():
        return {
            "ok": False,
            "status": "plan_ready",
            "detail": "Jianying Headless 未安装。已写出 edit_plan.json，请拷到匹配的 Mac 再生成剪映草稿。",
        }
    if sys.platform != "darwin":
        return {
            "ok": False,
            "status": "plan_ready",
            "detail": "当前是 Windows。Headless 只支持 Apple Silicon Mac + 剪映专业版。草稿 JSON 已打好包。",
        }
    script = root / "skills" / "yichen-jianying-edit" / "scripts" / "headless_draft.py"
    if not script.is_file():
        script = root / "headless_draft.py"
    if not script.is_file():
        return {"ok": False, "status": "plan_ready", "detail": f"找不到 headless_draft.py：{root}"}
    out = draft_dir / "jianying_build"
    try:
        subprocess.run(
            [sys.executable, str(script), "build", "--plan", str(plan.resolve()), "--out", str(out.resolve())],
            check=True,
            capture_output=True,
            text=True,
            timeout=180,
            encoding="utf-8",
            errors="replace",
        )
    except Exception as exc:
        return {"ok": False, "status": "plan_ready", "detail": str(exc)[:400]}
    return {"ok": True, "status": "draft_ready", "detail": str(out), "build": str(out)}


def _zip_draft(dest: Path) -> Path:
    zipped = dest.with_suffix(".zip")
    with zipfile.ZipFile(zipped, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in dest.rglob("*"):
            if path.is_file():
                zf.write(path, path.relative_to(dest.parent))
    return zipped


def _track_type(name: str, rows: list) -> str:
    if name in {"audio"} or any(row.get("kind") == "audio" for row in rows):
        return "audio"
    return "video"
