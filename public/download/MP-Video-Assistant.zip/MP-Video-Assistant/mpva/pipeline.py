from __future__ import annotations

import json
import os
import shutil
from pathlib import Path

from mpva import autopilot, envcheck
from mpva.assemble import story_captions
from mpva.design import render_design
from mpva.director import direct, plan_from_assets
from mpva.ffmpeg_tools import probe
from mpva.intel import index_folder, main_speech
from mpva.jobs import get, log, save
from mpva.motion import stage_film
from mpva.render import PRESETS


def brand() -> dict:
    return {
        "name": os.environ.get("MP_DISPLAY_NAME") or "Member of Parliament",
        "role": os.environ.get("MP_DISPLAY_ROLE") or "Parliament of New Zealand",
    }


def _step(job: dict, key: str, label: str, done: bool = False) -> None:
    steps = {item["key"]: item for item in job.get("steps") or []}
    steps[key] = {"key": key, "label": label, "done": done}
    order = ["understand", "transcribe", "captions", "stage"]
    job["steps"] = [steps[name] for name in order if name in steps] + [item for item in steps.values() if item["key"] not in order]
    job["progress"] = label
    save(job)


def generate(job_id: str) -> dict:
    job = get(job_id)
    if not job:
        raise RuntimeError("找不到任务")
    if (job.get("agent") or {}).get("state") in autopilot.ACTIVE:
        job = autopilot.cancel(job_id)
    job["status"] = "working"
    job["error"] = ""
    job["steps"] = []
    folder = Path(job["video"]).parent
    _step(job, "understand", "Reading the talking-head")
    log(job, "Reading the talking-head")
    assets = index_folder(folder, language=job.get("language") or "auto", on_line=lambda line: log(job, line))
    job["assets"] = assets
    _step(job, "understand", "Reading the talking-head", True)
    _step(job, "transcribe", "Writing a complete SRT", True)
    lead = main_speech(assets)
    if not lead:
        raise RuntimeError("需要一段口播视频（Agent Motion 是真人口播成片，不是多段活动混剪）。")
    job["video"] = lead["path"]
    job["duration"] = lead.get("duration") or 0
    job["words"] = lead.get("words") or []
    job["intent"] = "talking-head"
    if (job.get("brief") or "").strip():
        log(job, f"Staff brief: {(job.get('brief') or '')[:200]}")
    _step(job, "captions", "Writing a complete SRT")
    staged = stage_film(job, lead, words=job["words"], env_ready=envcheck.status()["ok"])
    job["motion"] = {k: v for k, v in staged.items() if k != "prompt"}
    job["motion_prompt"] = staged["prompt"]
    log(job, "Agent Motion inputs staged: source.mp4 + source.srt")
    _step(job, "captions", "Writing a complete SRT", True)
    _step(job, "stage", "Handing off to Agent Motion")
    clip_dir = folder / "film01"
    clip_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(staged["srt"], clip_dir / "source.srt")
    (clip_dir / "PROMPT.txt").write_text(staged["prompt"], encoding="utf-8")
    clip = {
        "id": "film01",
        "topic": job.get("title") or "口播成片",
        "title": job.get("title") or "口播成片",
        "summary": staged["prompt"],
        "seconds": round(float(job.get("duration") or 0), 1),
        "accepted": False,
        "kind": "talking-head",
        "caption": "原片 + 完整 SRT 已交给 Agent Motion。成片是 MP4 + 可编辑 Three.js 工程。",
        "motion": job["motion"],
        "preview": "",
        "exports": {
            "srt": f"/api/jobs/{job_id}/file/film01/source.srt",
            "prompt": f"/api/jobs/{job_id}/file/film01/PROMPT.txt",
        },
    }
    job["clips"] = [clip]
    job.setdefault("exports", {})["film01"] = clip["exports"]
    _step(job, "stage", "Handing off to Agent Motion", True)
    job["status"] = "review"
    job["progress"] = "Agent Motion ready"
    job.pop("agent", None)
    save(job)
    runner = job.get("agent_runner") or autopilot.default_runner()
    if job.get("auto_film") and runner:
        log(job, f"Starting {runner} on Agent Motion")
        return autopilot.start(job_id, runner)
    log(job, "Open vendor/agent-motion in Cursor and send PROMPT.txt")
    return job


def _windowed(clip: dict) -> dict:
    item = dict(clip)
    start = float(clip.get("start") or 0) + float(clip.get("trim_in") or 0)
    end = float(clip.get("end") or 0) + float(clip.get("trim_out") or 0)
    item["start"] = round(max(0.0, start), 2)
    item["end"] = round(max(item["start"] + 2.0, end), 2)
    item["seconds"] = round(item["end"] - item["start"], 1)
    return item


def preview_clip(
    job_id: str,
    clip_id: str,
    *,
    mode: str = "clean",
    accept_pending: bool = True,
    keep_working: bool = False,
    recut: bool = True,
) -> dict:
    job, clip, src, folder = _prepare_export(job_id, clip_id, "rendering")
    window = _windowed(clip)
    plan = build_timeline(job, clip)
    draft_dir = folder / "jianying_draft"
    write_draft(plan, draft_dir)
    headless = try_headless(draft_dir)
    log(job, f"Edit plan written · {headless.get('status')}: {headless.get('detail','')[:180]}")
    clip["timeline"] = {"duration": plan.get("duration"), "tracks": sorted({row.get("track") for row in plan.get("timeline") or []})}
    clip["draft"] = {
        "status": headless.get("status"),
        "detail": headless.get("detail"),
        "plan": f"/api/jobs/{job_id}/file/{clip_id}/edit_plan.json",
        "zip": f"/api/jobs/{job_id}/file/{clip_id}/jianying_draft.zip",
    }
    job["draft"] = clip["draft"]
    cut = folder / "cut_vertical.mp4"
    if clip.get("story"):
        render_story(clip["story"], job.get("assets") or [], cut, folder / "edit")
    else:
        try:
            render_timeline_proxy(plan, cut, folder / "edit")
        except Exception:
            render_interview(
                src,
                cut,
                start=float(window["start"]),
                end=float(window["end"]),
                words=job.get("words") or [],
                edit_dir=folder / "edit",
                captions=plan.get("captions") or [],
            )
    dest = folder / "vertical.mp4"
    if cut.is_file():
        dest.write_bytes(cut.read_bytes())
    clip["edit_plan"] = {"captions": plan.get("captions") or [], "duration": plan.get("duration"), "titles": plan.get("titles") or []}
    clip["exports"] = {
        "vertical": f"/api/jobs/{job_id}/file/{clip_id}/vertical.mp4" if dest.is_file() else "",
        "edit_plan": clip["draft"]["plan"],
        "draft": clip["draft"]["zip"],
    }
    clip["preview"] = clip["exports"].get("vertical") or ""
    job.setdefault("exports", {})[clip_id] = clip["exports"]
    if not keep_working:
        job["status"] = "review"
        job["progress"] = "Jianying Draft Ready"
    save(job)
    if recut:
        return _self_check(job_id, clip_id, keep_working=keep_working)
    return job


def export_job(job_id: str, clip_id: str, presets: list[str], *, mode: str = "clean", accept_pending: bool = True) -> dict:
    job, clip, src, folder = _prepare_export(job_id, clip_id, "exporting")
    chosen = [key for key in presets if key in PRESETS] or ["vertical"]
    if clip.get("story"):
        exports = dict(clip.get("exports") or {})
        for key in chosen:
            dest = folder / f"{key}.mp4"
            _render_story(job, clip, dest, preset=key, mode=mode)
            exports[key] = f"/api/jobs/{job_id}/file/{clip_id}/{key}.mp4"
        clip["exports"] = exports
        clip["preview"] = exports.get("vertical") or next(iter(exports.values()), "")
        clip["accepted"] = True
        job.setdefault("exports", {})[clip_id] = exports
        job["status"] = "review"
        log(job, "Approved")
        _write_pack(clip, folder)
        save(job)
        return job
    if not clip.get("preview"):
        preview_clip(job_id, clip_id, mode=mode, accept_pending=accept_pending, recut=False)
        job = get(job_id)
        clip = next(item for item in job["clips"] if item["id"] == clip_id)
    clip["accepted"] = True
    job["status"] = "review"
    log(job, "Approved")
    _write_pack(clip, folder)
    save(job)
    return job


def try_another(job_id: str, clip_id: str) -> dict:
    job = get(job_id)
    if not job:
        raise RuntimeError("找不到任务")
    clips = job.get("clips") or []
    clip = next((item for item in clips if item["id"] == clip_id), None)
    if not clip:
        raise RuntimeError("找不到片段")
    alts = job.get("alts") or []
    if job.get("intent") == "event" and alts:
        nxt = alts.pop(0)
        alts.append({k: v for k, v in clip.items() if k not in {"preview", "exports", "edit_plan"}})
        for key, value in nxt.items():
            if key not in {"id"}:
                clip[key] = value
        job["alts"] = alts
        clip.pop("_recut", None)
        save(job)
        return preview_clip(job_id, clip_id)
    from mpva.agent import edit_speech

    avoid = [(float(item.get("start") or 0), float(item.get("end") or 0)) for item in clips]
    fresh, _ = edit_speech(
        job.get("words") or [],
        float(job.get("duration") or 0),
        brief=job.get("brief") or "",
        avoid=avoid,
    )
    if fresh:
        nxt = fresh[0]
        clip["topic"] = nxt.get("topic") or clip.get("topic")
        clip["title"] = nxt.get("title") or nxt.get("topic") or clip.get("title")
        clip["start"] = nxt["start"]
        clip["end"] = nxt["end"]
        clip["seconds"] = nxt.get("seconds") or round(float(nxt["end"]) - float(nxt["start"]), 1)
        clip["summary"] = nxt.get("summary") or ""
        clip["trim_in"] = 0
        clip["trim_out"] = 0
        clip["accepted"] = False
        clip.pop("preview", None)
        clip.pop("exports", None)
        clip.pop("edit_plan", None)
        clip.pop("_recut", None)
        save(job)
        return preview_clip(job_id, clip_id)
    clip["trim_in"] = float(clip.get("trim_in") or 0) - 0.4
    clip["trim_out"] = float(clip.get("trim_out") or 0) + 0.4
    save(job)
    return preview_clip(job_id, clip_id)


def regenerate(job_id: str, clip_id: str | None = None, brief: str | None = None) -> dict:
    job = get(job_id)
    if not job:
        raise RuntimeError("找不到任务")
    if brief is not None:
        incoming = str(brief).strip()[:800]
        if incoming:
            job["brief"] = incoming
            save(job)
    return generate(job_id)


def patch_clip(job_id: str, clip_id: str, payload: dict) -> dict:
    job = get(job_id)
    if not job:
        raise RuntimeError("找不到任务")
    clip = next((item for item in job.get("clips") or [] if item["id"] == clip_id), None)
    if not clip:
        raise RuntimeError("找不到片段")
    action = str(payload.get("action") or "")
    if action == "title":
        title = str(payload.get("title") or "").strip()
        if title:
            clip["title"] = title
            clip["topic"] = title
            if clip.get("story"):
                clip["story"]["title"] = title
                for beat in clip["story"].get("beats") or []:
                    if beat.get("headline"):
                        beat["headline"] = title
    elif action == "trim":
        clip["trim_in"] = float(payload.get("trim_in") or 0)
        clip["trim_out"] = float(payload.get("trim_out") or 0)
    elif action == "remove":
        _remove_piece(clip, payload)
    elif action == "replace":
        _replace_shot(job, clip, int(payload.get("beat_index") or 0))
    elif action == "caption":
        _rewrite_caption(clip, payload)
    save(job)
    return preview_clip(job_id, clip_id, recut=False)


def _remove_piece(clip: dict, payload: dict) -> None:
    story = clip.get("story") or {}
    beats = story.get("beats") or []
    if beats:
        idx = payload.get("beat_index")
        idx = int(idx) if idx is not None else max(0, len(beats) - 2)
        if 0 <= idx < len(beats) and len(beats) > 2:
            beats.pop(idx)
            t = 0.0
            for beat in beats:
                dur = max(0.4, float(beat.get("end") or 0) - float(beat.get("start") or 0))
                beat["start"] = round(t, 2)
                beat["end"] = round(t + dur, 2)
                t += dur
            clip["seconds"] = round(t, 1)
        return
    end = float(clip.get("end") or 0)
    start = float(clip.get("start") or 0)
    clip["end"] = round(max(start + 2.0, end - 4.0), 2)
    clip["seconds"] = round(clip["end"] - start, 1)


def _replace_shot(job: dict, clip: dict, beat_index: int) -> None:
    from mpva.intel import broll_assets, photo_assets
    from mpva.story import _assign_picture

    story = clip.get("story") or {}
    beats = story.get("beats") or []
    if not beats:
        return
    beat = beats[min(max(0, beat_index), len(beats) - 1)]
    if beat.get("role") in {"end", "speech"} and not beat.get("jcut"):
        beat = next((item for item in beats if item.get("jcut") or item.get("role") in {"opener", "arrival", "handshake", "photos", "close"}), beat)
    pool = [item for item in (broll_assets(job.get("assets") or []) + photo_assets(job.get("assets") or [])) if item]
    if not pool:
        return
    current = ((beat.get("video") or {}).get("asset_id")) or ""
    if beat.get("photos"):
        current = (beat["photos"][0] or {}).get("asset_id") or current
    ids = [item["id"] for item in pool]
    nxt = pool[0]
    if current in ids:
        nxt = pool[(ids.index(current) + 1) % len(pool)]
    dur = max(0.4, float(beat.get("end") or 0) - float(beat.get("start") or 0))
    audio = beat.get("audio")
    jcut = beat.get("jcut")
    _assign_picture(beat, nxt, dur)
    if jcut and audio:
        beat["audio"] = audio
        beat["jcut"] = True


def _rewrite_caption(clip: dict, payload: dict) -> None:
    text = str(payload.get("text") or "").strip()
    if not text:
        return
    plan = clip.get("edit_plan") or {}
    captions = plan.get("captions") or []
    idx = payload.get("index")
    if idx is not None and 0 <= int(idx) < len(captions):
        captions[int(idx)]["text"] = text
        return
    old = str(payload.get("old") or "")
    for item in captions:
        if item.get("text") == old:
            item["text"] = text
            return


def _self_check(job_id: str, clip_id: str, *, keep_working: bool = False) -> dict:
    job = get(job_id) or {}
    clip = next((item for item in job.get("clips") or [] if item["id"] == clip_id), None)
    if not clip:
        return job
    issues = inspect_clip(job, clip)
    if not issues:
        log(job, "自我检查: 通过")
        save(job)
        return job
    log(job, "自我检查未通过: " + "；".join(issues[:4]))
    if clip.get("_recut"):
        log(job, "自我检查: 已重剪一次，仍请人工确认")
        save(job)
        return job
    clip["_recut"] = True
    clip["_qa"] = issues
    _apply_recut(job, clip, issues)
    save(job)
    log(job, "自我检查: 正在按问题重剪")
    return preview_clip(job_id, clip_id, keep_working=keep_working, recut=False)


def _apply_recut(job: dict, clip: dict, issues: list[str]) -> None:
    note = " ".join(issues[:4])
    brief = (job.get("brief") or "").strip()
    clip.pop("preview", None)
    clip.pop("exports", None)
    clip.pop("edit_plan", None)
    if clip.get("story"):
        from mpva.story import build_schemes

        schemes = build_schemes(job.get("assets") or [], title=job.get("title") or "", brief=brief)
        pick = schemes[0] if schemes else None
        for scheme in schemes:
            trial = {
                **clip,
                "story": scheme.get("story"),
                "title": scheme.get("title"),
                "seconds": scheme.get("seconds"),
            }
            if not inspect_clip({**job, "clips": [trial]}, trial, llm=False):
                pick = scheme
                break
        if pick:
            for key in ("topic", "title", "summary", "seconds", "story"):
                if key in pick:
                    clip[key] = pick[key]
        return
    from mpva.agent import edit_speech

    avoid = [(float(clip.get("start") or 0), float(clip.get("end") or 0))]
    merged = f"{brief} {note}".strip()
    fresh, _ = edit_speech(
        job.get("words") or [],
        float(job.get("duration") or 0),
        brief=merged,
        avoid=avoid,
    )
    if not fresh:
        fresh, _ = edit_speech(
            job.get("words") or [],
            float(job.get("duration") or 0),
            brief=merged,
        )
    if not fresh:
        return
    nxt = fresh[0]
    clip["topic"] = nxt.get("topic") or clip.get("topic")
    clip["title"] = nxt.get("title") or nxt.get("topic") or clip.get("title")
    clip["start"] = nxt["start"]
    clip["end"] = nxt["end"]
    clip["seconds"] = nxt.get("seconds") or round(float(nxt["end"]) - float(nxt["start"]), 1)
    clip["summary"] = nxt.get("summary") or ""
    clip["trim_in"] = 0
    clip["trim_out"] = 0
    clip["accepted"] = False


def _preview_story(job: dict, clip: dict, folder: Path, *, mode: str, keep_working: bool = False) -> dict:
    dest = folder / "vertical.mp4"
    _render_story(job, clip, dest, preset="vertical", mode=mode)
    clip["exports"] = {"vertical": f"/api/jobs/{job['id']}/file/{clip['id']}/vertical.mp4"}
    clip["preview"] = clip["exports"]["vertical"]
    job.setdefault("exports", {})[clip["id"]] = clip["exports"]
    if not keep_working:
        job["status"] = "review"
    save(job)
    return job


def _render_story(job: dict, clip: dict, dest: Path, *, preset: str, mode: str) -> None:
    story = clip.get("story") or {}
    cut = dest.with_name(f"cut_{dest.stem}.mp4")
    render_story(story, job.get("assets") or [], cut, dest.parent / "edit")
    info = probe(cut)
    captions = story_captions(story, job.get("assets") or [])
    plan = {
        "clip": {
            "id": clip.get("id"),
            "topic": clip.get("topic") or "",
            "title": clip.get("title") or "",
            "start": 0,
            "end": info.get("duration") or 0,
        },
        "duration": round(float(info.get("duration") or 0), 3),
        "mode": "clean",
        "captions": captions,
        "visuals": [],
        "brand": brand(),
        "show_logo": bool(clip.get("show_logo", True)),
        "show_name": bool(clip.get("show_name", True)),
        "original_transcript": " ".join(item["text"] for item in captions),
        "edited_transcript": " ".join(item["text"] for item in captions),
        "brief": job.get("brief") or "",
    }
    for beat in story.get("beats") or []:
        if beat.get("headline"):
            plan["visuals"].append(
                {
                    "time": beat["start"],
                    "component": "Headline",
                    "text": clip.get("title") or beat["headline"],
                    "duration": min(3.0, float(beat["end"]) - float(beat["start"])),
                }
            )
        if beat.get("component") in {"LowerThird", "EndCard"}:
            plan["visuals"].append(
                {
                    "time": beat["start"],
                    "component": beat["component"],
                    "text": brand()["name"] if beat["component"] == "LowerThird" else (clip.get("title") or clip.get("topic") or ""),
                    "meta": brand()["role"],
                    "duration": min(4.4, float(beat["end"]) - float(beat["start"])),
                }
            )
    plan = direct(plan, mode="social")
    clip["edit_plan"] = plan
    render_design(cut, dest, plan, preset=preset)


def _write_pack(clip: dict, folder: Path) -> None:
    plan = clip.get("edit_plan") or {}
    used = []
    if clip.get("source_asset"):
        used.append(clip["source_asset"])
    for beat in (clip.get("story") or {}).get("beats") or []:
        for part in (beat.get("video"), beat.get("audio")):
            if part and part.get("asset_id"):
                used.append(part["asset_id"])
        for photo in beat.get("photos") or []:
            if photo.get("asset_id"):
                used.append(photo["asset_id"])
    pack = {
        "suggested_title": clip.get("title") or clip.get("topic") or "",
        "caption": clip.get("summary") or clip.get("title") or "",
        "transcript": plan.get("edited_transcript") or clip.get("summary") or "",
        "source_clips": sorted(set(used)),
        "note": "Draft for staff confirmation. Do not publish unreviewed political copy.",
    }
    (folder / "pack.json").write_text(json.dumps(pack, ensure_ascii=False, indent=2), encoding="utf-8")


def _prepare_export(job_id: str, clip_id: str, status: str):
    job = get(job_id)
    if not job:
        raise RuntimeError("找不到任务")
    clip = next((item for item in job.get("clips") or [] if item["id"] == clip_id), None)
    if not clip:
        raise RuntimeError("找不到片段")
    job["status"] = status
    save(job)
    src = Path(job["video"])
    folder = src.parent / clip_id
    folder.mkdir(parents=True, exist_ok=True)
    return job, clip, src, folder
