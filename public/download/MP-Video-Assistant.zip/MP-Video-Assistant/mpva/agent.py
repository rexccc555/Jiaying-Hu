"""Clip agent: LLM reads packed phrases, picks complete thoughts, retries if the in-point is junk."""

from __future__ import annotations

import re

from mpva.captions import card_blurb, duration_limit, hook_title, squeeze_cjk
from mpva.clean import join_text, sentence_groups
from mpva.llm import chat_json, configured, last_model

_BAD_START = re.compile(
    r"^(and|but|so|or|is|are|was|were|to|of|the|hard work|thank|thanks|yielding)\b",
    re.I,
)


def pack_phrases(words: list[dict], pause: float = 0.55) -> list[dict]:
    out = []
    for group in sentence_groups(words, pause=pause):
        text = join_text(group)
        if not text:
            continue
        out.append(
            {
                "start": float(group[0]["start"]),
                "end": float(group[-1]["end"]),
                "text": text,
            }
        )
    return out


def wants_one(brief: str, source: float = 0.0) -> bool:
    if source and source < 28:
        return True
    if duration_limit(brief or "", source):
        return True
    return bool(re.search(r"一条|只要一段|one clip|single clip|只要一条", brief or "", re.I))


def _overlaps(start: float, end: float, ranges: list[tuple[float, float]] | None, *, min_overlap: float = 8.0) -> bool:
    for left, right in ranges or []:
        if min(end, right) - max(start, left) > min_overlap:
            return True
    return False


def edit_speech(
    words: list[dict],
    duration: float,
    *,
    brief: str = "",
    avoid: list[tuple[float, float]] | None = None,
) -> tuple[list[dict], str]:
    phrases = pack_phrases(words)
    limit = duration_limit(brief, duration)
    one = wants_one(brief, duration)
    max_s = limit or (min(duration, 38) if duration else 38)
    if limit:
        min_s = min(max(8.0, limit * 0.7), max(6.0, limit - 1.0))
    elif duration and duration < 25:
        min_s = 6
    else:
        min_s = 14
    fallback = _pack(phrases, duration, min_s=min_s, max_s=max_s, avoid=avoid, one=one)
    if not configured() or not phrases:
        return fallback, last_model()
    chosen = _llm_pick(phrases, note="", brief=brief, avoid=avoid, min_s=min_s, max_s=max_s, one=one) or fallback
    issues = _critique(chosen, phrases, brief=brief, max_s=max_s, one=one)
    if issues:
        retry = _llm_pick(
            phrases, note="; ".join(issues), brief=brief, avoid=avoid, min_s=min_s, max_s=max_s, one=one
        )
        if retry:
            retry_issues = _critique(retry, phrases, brief=brief, max_s=max_s, one=one)
            if not retry_issues or len(retry_issues) < len(issues):
                chosen = retry
    if not one and len(chosen) < 2 and (duration or 0) >= 35:
        extra = [
            item
            for item in fallback
            if not _overlaps(item["start"], item["end"], [(c["start"], c["end"]) for c in chosen])
        ]
        chosen = (chosen + extra)[:4]
    return chosen or fallback, last_model()


def _llm_pick(
    phrases: list[dict],
    note: str,
    *,
    brief: str = "",
    avoid: list[tuple[float, float]] | None = None,
    min_s: float = 14,
    max_s: float = 40,
    one: bool = False,
) -> list[dict]:
    numbered = "\n".join(
        f"{index}\t[{item['start']:.2f}-{item['end']:.2f}] {item['text']}" for index, item in enumerate(phrases)
    )
    extra = ""
    if brief.strip():
        extra += (
            f" Staff brief — follow it, including duration and what to skip. "
            f"Do not ignore it: {brief.strip()[:600]}."
        )
        if duration_limit(brief, 0):
            extra += f" Stay close to that length; do not return a stub much shorter than {duration_limit(brief, 0):.0f}s."
    if avoid:
        extra += " Do not reuse these source ranges: " + ", ".join(f"{a:.1f}-{b:.1f}" for a, b in avoid[:8]) + "."
    extra += f" Fix these problems: {note}." if note else ""
    count = "1 independently watchable clip" if one else "2 to 4 independently watchable clips"
    length = f"{min_s:.0f}-{max_s:.0f} seconds"
    try:
        parsed = chat_json(
            (
                "You cut short social videos from real speech. "
                f"Pick {count} from numbered phrases. "
                "from/to are inclusive phrase indexes. Copy those indexes; do not invent times. "
                f"Each clip {length}. If the brief sets a max length, do not exceed it. "
                "Start on a complete thought. Skip greetings unless that is the point of the clip. "
                "Do not invent or rewrite spoken words. Do not rank political views. "
                "topic is a short hook: 2-8 Chinese characters or 1-3 English words, never a full paragraph. "
                "Return JSON {clips:[{topic,from,to}]}."
            ),
            numbered[:14000] + extra,
            timeout=90,
        )
    except Exception:
        return []
    clips = []
    for index, item in enumerate(parsed.get("clips") or [], start=1):
        try:
            start_i = int(item.get("from"))
            end_i = int(item.get("to"))
        except (TypeError, ValueError):
            continue
        if start_i < 0 or end_i >= len(phrases) or end_i < start_i:
            continue
        start = phrases[start_i]["start"]
        end = phrases[end_i]["end"]
        if end - start < min_s - 1:
            continue
        if end - start > max_s:
            end = start + max_s
        if _overlaps(start, end, avoid):
            continue
        text = squeeze_cjk(" ".join(row["text"] for row in phrases[start_i : end_i + 1]))
        if _BAD_START.match(phrases[start_i]["text"].strip()) and start_i == 0 and len(phrases) > 1:
            continue
        topic = hook_title(str(item.get("topic") or text), 12) or f"Viewpoint {index}"
        clips.append(_clip(index, topic, text, start, end))
        if len(clips) >= (1 if one else 4):
            break
    return clips


def _critique(clips: list[dict], phrases: list[dict], *, brief: str = "", max_s: float = 42, one: bool = False) -> list[str]:
    issues = []
    if not clips:
        return ["no clips"]
    if not one and len(clips) < 2:
        issues.append("need 2 to 4 clips from different parts of the speech")
    for clip in clips:
        first = next((row for row in phrases if abs(row["start"] - float(clip["start"])) < 0.2), None)
        text = (first or {}).get("text") or clip.get("summary") or ""
        if _BAD_START.match(text.strip()):
            issues.append(f"{clip.get('id')} starts incomplete: {text[:80]}")
        span = float(clip["end"]) - float(clip["start"])
        if span > max_s + 1.2:
            issues.append(f"{clip.get('id')} longer than {max_s:.0f}s — cut it down")
        if max_s <= 22 and span < max_s * 0.65:
            issues.append(f"{clip.get('id')} too short, aim near {max_s:.0f}s")
    return issues


def _pack(
    phrases: list[dict],
    duration: float,
    min_s: float = 20,
    max_s: float = 38,
    avoid: list[tuple[float, float]] | None = None,
    one: bool = False,
) -> list[dict]:
    usable = [row for row in phrases if not _BAD_START.match(row["text"].strip())] or phrases
    if not usable:
        return []
    clips = []
    i = 0
    n = 1
    cap = 1 if one else 4
    while i < len(usable) and len(clips) < cap:
        start = usable[i]["start"]
        j = i
        while j + 1 < len(usable) and usable[j + 1]["end"] - start <= max_s:
            j += 1
            if usable[j]["end"] - start >= min_s:
                break
        end = min(duration or usable[j]["end"], usable[j]["end"], start + max_s)
        if end - start >= min(min_s, 6) and not _overlaps(start, end, avoid):
            text = squeeze_cjk(" ".join(row["text"] for row in usable[i : j + 1]))
            clips.append(_clip(n, hook_title(text, 12) or card_blurb(text, 24) or f"Viewpoint {n}", text, start, end))
            n += 1
        i = j + 1
    return clips


def _clip(index: int, topic: str, text: str, start: float, end: float) -> dict:
    return {
        "id": f"clip{index:02d}",
        "topic": topic,
        "title": topic,
        "start": round(start, 2),
        "end": round(end, 2),
        "seconds": round(end - start, 1),
        "summary": text[:280],
        "accepted": False,
    }
