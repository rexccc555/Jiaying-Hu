"""AI Director story: speech is the audio backbone; pictures cover it."""

from __future__ import annotations

import re
from pathlib import Path

from mpva.captions import duration_limit
from mpva.intel import broll_assets, main_speech, photo_assets
from mpva.viewpoints import complete_span

_EMPTY = re.compile(
    r"no people|nobody|no one is visible|cityscape|only (?:trees|sky|buildings)|not visible|"
    r"empty (?:street|shot|scene)|tall buildings and trees",
    re.I,
)
_STYLE_ONLY = re.compile(r"简单|明了|短一?点|精简|简短|快一点|竖屏|simple|short recap|keep it short", re.I)
_GENERIC_ASK = re.compile(r"我要剪辑的|我想要|请(?:帮我)?(?:剪|做)|kind of video|please (?:make|edit)", re.I)
_CLIP_STEMS = re.compile(
    r"^(下车|握手|离场|群众|讲话|走进活动|采访|合影|握手现场|arrival|handshake|speech|crowd|interview)$",
    re.I,
)


def wants_simple(brief: str) -> bool:
    return bool(_STYLE_ONLY.search(brief or ""))


def topic_brief(brief: str) -> str:
    text = (brief or "").strip()
    if not text:
        return ""
    leftover = _STYLE_ONLY.sub("", text)
    leftover = _GENERIC_ASK.sub("", leftover).strip(" ，,。.!！")
    if len(leftover) < 4:
        return ""
    return leftover[:400]


def event_title(title: str, brief: str, assets: list[dict]) -> str:
    stems = {Path(item.get("file") or "").stem for item in assets}
    text = (title or "").strip()
    if text and text not in stems and not _CLIP_STEMS.match(text):
        return text[:40]
    topic = topic_brief(brief)
    if topic and len(topic) <= 40:
        return topic
    return "社区活动"


def build_schemes(assets: list[dict], *, target_seconds: float = 60, title: str = "Community event", brief: str = "") -> list[dict]:
    assets = _with_name_roles(assets)
    heading = event_title(title, brief, assets)
    simple = wants_simple(brief)
    limit = duration_limit(brief, 60)
    target = int(limit) if limit else (22 if simple else (28 if target_seconds <= 40 else 32))
    people = _has_people(assets)
    variants = [
        (3, "scheme-community", "Community-led", "Leads with people, speech audio continues underneath."),
        (1, "scheme-arrival", "Arrival-led", "Opens on arrival, then event pictures over the same speech."),
        (2, "scheme-speech", "Speech-led", "Opens on remarks, then event pictures over the same audio."),
    ]
    if not people:
        variants = variants[1:] + variants[:1]
    schemes = []
    for index, (variant, sid, topic, summary) in enumerate(variants, start=1):
        beats = _beats(assets, target, heading, variant=variant, brief=brief)
        duration = round(sum(float(beat["end"]) - float(beat["start"]) for beat in beats), 1)
        schemes.append(
            {
                "id": sid,
                "topic": topic,
                "title": heading,
                "summary": summary,
                "seconds": duration,
                "source_label": f"{int(duration)}s",
                "kind": "scheme",
                "story": {"title": heading, "target": target, "beats": beats},
                "accepted": False,
            }
        )
    return schemes


def build_event_pack(assets: list[dict], *, target_seconds: float = 60, title: str = "Community event") -> list[dict]:
    schemes = build_schemes(assets, target_seconds=target_seconds, title=title)
    highlight = schemes[1] if len(schemes) > 1 else schemes[0]
    highlight = dict(highlight)
    highlight["id"] = "highlight"
    highlight["kind"] = "highlight"
    highlight["topic"] = "Event Highlight"
    return [highlight] + [
        {**item, "id": f"social{index:02d}", "kind": "social", "topic": f"Social {index}"}
        for index, item in enumerate(schemes[:2], start=1)
    ]


def _beats(assets: list[dict], target: int, title: str, *, variant: int, brief: str = "") -> list[dict]:
    speech = main_speech(assets)
    pictures = _ranked_pictures(assets, speech, variant)
    skip = 0.0 if variant != 2 else 6.0
    wanted = float(target)
    audio_in, audio_out, _text = complete_span(
        speech.get("words") or [] if speech else [],
        float((speech or {}).get("duration") or target),
        target=wanted,
        max_s=wanted + 6,
        skip_before=skip,
    )
    topic = (brief or "").strip()
    if topic and speech:
        from mpva.agent import edit_speech

        picks, _ = edit_speech(
            speech.get("words") or [],
            float(speech.get("duration") or target),
            brief=brief,
        )
        if picks:
            pick = picks[min(max(variant - 1, 0), len(picks) - 1)]
            audio_in = float(pick["start"])
            audio_out = min(float(pick["end"]), audio_in + wanted + 6)
    if not speech:
        return _pictures_only(pictures, title, target)

    audio_t = audio_in
    t = 0.0
    beats: list[dict] = []
    used: set[str] = set()

    def remain() -> float:
        return audio_out - audio_t

    def add_aroll(want: float, component: str = "", role: str = "speech") -> None:
        nonlocal audio_t, t
        dur = min(want, remain())
        if dur < 1.1:
            return
        beats.append(
            {
                "start": round(t, 2),
                "end": round(t + dur, 2),
                "role": role,
                "headline": title if component == "Headline" else "",
                "component": component,
                "video": _slice(speech, audio_t, audio_t + dur),
                "audio": _slice(speech, audio_t, audio_t + dur),
                "photos": [],
                "words_from": speech["id"],
            }
        )
        audio_t += dur
        t += dur

    def add_cover(asset: dict | None, want: float, component: str = "", role: str = "broll") -> None:
        nonlocal audio_t, t
        if not asset:
            add_aroll(want, component, role)
            return
        dur = min(_picture_dur(asset, want), remain())
        if dur < 1.1:
            add_aroll(want, component, role)
            return
        beat = {
            "start": round(t, 2),
            "end": round(t + dur, 2),
            "role": role or asset.get("role") or "broll",
            "headline": title if component == "Headline" else "",
            "component": component,
            "audio": _slice(speech, audio_t, audio_t + dur),
            "words_from": speech["id"],
            "jcut": True,
        }
        _assign_picture(beat, asset, dur)
        beats.append(beat)
        used.add(asset.get("id") or "")
        audio_t += dur
        t += dur

    unused = [item for item in pictures if item]
    opener = unused[0] if unused else None
    if variant == 2:
        add_aroll(2.2, "Headline")
        add_aroll(4.6, "LowerThird")
    else:
        add_cover(opener, 2.3, "Headline", (opener or {}).get("role") or "opener")
        if opener:
            unused = unused[1:]

    people_first = [item for item in unused if item.get("role") in {"handshake", "group", "crowd", "photo"} or item.get("kind") == "photo"]
    rest = [item for item in unused if item not in people_first]
    queue = people_first + rest

    if variant != 2:
        if queue:
            first = queue.pop(0)
            add_cover(first, 2.8, "", first.get("role") or "broll")
        add_aroll(3.8 if wants_simple(brief) else 5.0, "LowerThird")
    else:
        if queue:
            first = queue.pop(0)
            add_cover(first, 2.8, "", first.get("role") or "broll")

    while remain() > 1.4 and queue:
        item = queue.pop(0)
        add_cover(item, 2.8 if item.get("kind") == "photo" else 3.2, "", item.get("role") or "broll")
        if remain() > 8 and not wants_simple(brief):
            add_aroll(min(3.4, remain() - 2.4))

    while remain() > 1.4:
        leftover = [item for item in pictures if item.get("id") not in used]
        if leftover:
            add_cover(leftover[0], min(2.8, remain()), "", leftover[0].get("role") or "broll")
        else:
            add_aroll(remain())
            break

    return beats


def _pictures_only(pictures: list[dict], title: str, target: int) -> list[dict]:
    t = 0.0
    beats = []
    each = max(2.4, min(4.8, (target - 2.3) / max(1, len(pictures) or 1)))
    for index, asset in enumerate(pictures[:8] or [None]):
        dur = each if asset else float(target)
        beat = {
            "start": round(t, 2),
            "end": round(t + dur, 2),
            "role": "broll",
            "headline": title if index == 0 else "",
            "component": "Headline" if index == 0 else "",
        }
        _assign_picture(beat, asset, dur)
        beats.append(beat)
        t += dur
    return beats


def _picture_cycle(assets: list[dict], speech: dict | None, variant: int) -> list[dict]:
    return _ranked_pictures(assets, speech, variant)


def _ranked_pictures(assets: list[dict], speech: dict | None, variant: int) -> list[dict]:
    if variant == 2:
        preferred = ["crowd", "handshake", "group", "photo", "arrival", "broll", "leave", "phone"]
    elif variant == 1:
        preferred = ["arrival", "handshake", "crowd", "group", "photo", "broll", "leave", "phone"]
    else:
        preferred = ["handshake", "group", "crowd", "photo", "arrival", "leave", "broll", "phone"]
    extras = [item for item in broll_assets(assets) if not item.get("speech") and item.get("role") != "speech"]
    photos = photo_assets(assets)
    pool = []
    seen = set()
    for role in preferred:
        for item in extras + photos:
            if not item or item is speech or item.get("id") in seen:
                continue
            if item.get("id") == (speech or {}).get("id"):
                continue
            if item.get("role") == role or (role == "photo" and item.get("kind") == "photo"):
                pool.append(item)
                seen.add(item["id"])
    for item in extras + photos:
        if item and item is not speech and item.get("id") not in seen and item.get("id") != (speech or {}).get("id"):
            pool.append(item)
            seen.add(item["id"])
    lively = [item for item in pool if not _is_empty(item)]
    empty = [item for item in pool if _is_empty(item)]
    return lively + empty


def _with_name_roles(assets: list[dict]) -> list[dict]:
    from mpva.intel import _role_from_name

    out = []
    for item in assets:
        row = dict(item)
        hinted = _role_from_name(row.get("file") or "")
        if hinted and not (row.get("speech") and row.get("role") == "speech" and hinted == "speech"):
            if hinted != "speech" or not row.get("speech"):
                row["role"] = hinted
        out.append(row)
    return out


def _has_people(assets: list[dict]) -> bool:
    return any(
        item.get("role") in {"handshake", "group", "crowd", "arrival"} or item.get("kind") == "photo"
        for item in assets
    )


def _is_empty(asset: dict) -> bool:
    return bool(_EMPTY.search(str(asset.get("visual_description") or "")))


def _picture_dur(asset: dict, want: float) -> float:
    if asset.get("kind") in {"photo", "logo"}:
        return min(want, 3.0)
    duration = float(asset.get("duration") or want)
    return min(want, max(1.2, duration - 0.12))


def _slice(asset: dict, start: float, end: float) -> dict:
    return {
        "asset_id": asset["id"],
        "path": asset.get("path"),
        "in": round(start, 2),
        "out": round(end, 2),
    }


def _assign_picture(beat: dict, asset: dict | None, dur: float) -> None:
    if not asset:
        beat["video"] = None
        beat.setdefault("audio", None)
        beat["photos"] = []
        return
    if asset.get("kind") in {"photo", "logo"}:
        beat["video"] = None
        beat["photos"] = [{"asset_id": asset["id"], "path": asset.get("path")}]
        return
    start, end = _span(asset, dur)
    beat["video"] = {"asset_id": asset["id"], "path": asset.get("path"), "in": round(start, 2), "out": round(end, 2)}
    beat["photos"] = []


def _span(asset: dict | None, want: float) -> tuple[float, float]:
    if not asset:
        return 0.0, want
    ranges = asset.get("usable_ranges") or []
    if ranges:
        start, end = float(ranges[0][0]), float(ranges[0][1])
    else:
        start, end = 0.0, float(asset.get("duration") or want)
    available = max(0.4, end - start)
    take = min(want, available)
    return start, start + take
