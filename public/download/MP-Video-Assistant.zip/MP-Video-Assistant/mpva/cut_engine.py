"""Deterministic FFmpeg cut engine. Executes Edit Plan keep-ranges only."""

from __future__ import annotations

from pathlib import Path

from mpva.edit_plan import keep_pairs
from mpva.ffmpeg_tools import find_bin, probe, run
from mpva.render import PRESETS, _fit


def cut_from_plan(src: Path, dest: Path, plan: dict, *, preset: str, reframe: bool = True) -> Path:
    spec = PRESETS[preset]
    clip = plan.get("clip") or {}
    start = float(clip.get("start") or 0)
    end = float(clip.get("end") or 0)
    keeps = keep_pairs(plan)
    if not keeps:
        keeps = [(start, end)]
    dest.parent.mkdir(parents=True, exist_ok=True)
    vf = _fit(spec["width"], spec["height"], reframe=reframe)
    af = "loudnorm=I=-16:TP=-1.5:LRA=11"
    if len(keeps) == 1 and abs(keeps[0][0] - start) < 0.05 and abs(keeps[0][1] - end) < 0.05:
        run(
            [
                find_bin("ffmpeg"),
                "-y",
                "-ss",
                f"{start:.3f}",
                "-to",
                f"{end:.3f}",
                "-i",
                str(src),
                "-vf",
                vf,
                "-af",
                af,
                "-c:v",
                "libx264",
                "-preset",
                "veryfast",
                "-crf",
                "19",
                "-c:a",
                "aac",
                "-b:a",
                "160k",
                str(dest),
            ]
        )
    else:
        expr = "+".join(f"between(t,{a:.3f},{b:.3f})" for a, b in keeps)
        run(
            [
                find_bin("ffmpeg"),
                "-y",
                "-i",
                str(src),
                "-vf",
                f"select='{expr}',setpts=N/FRAME_RATE/TB,{vf}",
                "-af",
                f"aselect='{expr}',asetpts=N/SR/TB,{af}",
                "-c:v",
                "libx264",
                "-preset",
                "veryfast",
                "-crf",
                "19",
                "-c:a",
                "aac",
                "-b:a",
                "160k",
                str(dest),
            ]
        )
    info = probe(dest)
    plan["duration"] = round(float(info.get("duration") or plan.get("duration") or 0), 3)
    return dest
