"""Quality check after a draft cut. Duration-only ffmpeg checks are not enough."""

from __future__ import annotations

import re

from mpva.captions import duration_limit
from mpva.intel import main_speech
from mpva.llm import chat_json, configured
from mpva.story import _is_empty


def inspect_clip(job: dict, clip: dict, *, llm: bool = True) -> list[str]:
    issues = []
    brief = str(job.get("brief") or "").strip()
    seconds = float(clip.get("seconds") or 0)
    limit = duration_limit(brief, float(job.get("duration") or 0))
    if limit and seconds > limit + 1.5:
        issues.append(f"draft is {seconds:.0f}s but brief asked for {limit:.0f}s")
    captions = ((clip.get("edit_plan") or {}).get("captions") or [])[:12]
    for cap in captions:
        text = str(cap.get("text") or "")
        if re.search(r"[\u4e00-\u9fff]\s+[\u4e00-\u9fff]", text):
            issues.append("Chinese captions are spaced into gibberish")
            break
    story = clip.get("story") or {}
    assets = {item.get("id"): item for item in job.get("assets") or []}
    lead = main_speech(job.get("assets") or []) or {}
    for beat in story.get("beats") or []:
        video = beat.get("video") or {}
        asset = assets.get(video.get("asset_id") or "")
        if not asset:
            continue
        if asset.get("role") == "speech" and asset.get("id") != lead.get("id"):
            issues.append(f"used leftover speech clip {asset.get('file')} as B-roll")
        if beat.get("component") == "Headline" and _is_empty(asset):
            issues.append("opens on an empty landscape")
    if llm and configured() and brief and not issues:
        issues.extend(_llm_qc(job, clip, brief, issues))
    seen = []
    for item in issues:
        if item and item not in seen:
            seen.append(item)
    return seen


def _llm_qc(job: dict, clip: dict, brief: str, already: list[str]) -> list[str]:
    captions = [str(item.get("text") or "") for item in ((clip.get("edit_plan") or {}).get("captions") or [])[:8]]
    payload = {
        "brief": brief,
        "title": clip.get("title") or clip.get("topic") or "",
        "seconds": clip.get("seconds"),
        "start": clip.get("start"),
        "end": clip.get("end"),
        "captions": captions,
        "already": already,
        "intent": job.get("intent"),
    }
    try:
        parsed = chat_json(
            (
                "You QA a short social video edit. "
                "Staff brief must be followed (duration, what to skip, how clean). "
                "Do not demand end cards or logos. "
                "Return JSON {ok:boolean, issues:[string]}."
            ),
            str(payload)[:4000],
            timeout=40,
        )
    except Exception:
        return []
    if parsed.get("ok"):
        return []
    return [str(item) for item in (parsed.get("issues") or []) if item][:4]
