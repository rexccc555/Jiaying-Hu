"""Mechanical editor: video-use EDL pipeline (MIT), local ASR, 9:16 crop.

video-use is a Claude-Code skill, not a server. We keep its production rules:
per-segment extract → 30ms audio fades → concat → captions last.
Transcripts come from our on-device ASR, not ElevenLabs.
Captions are sentence cues, not 2-word karaoke.
Strategy approval is automatic; staff still review the draft.
"""

from __future__ import annotations

import json
from pathlib import Path

from mpva.captions import pack_cues
from mpva.ffmpeg_tools import concat_copy, find_bin, probe, run
from mpva.paths import ROOT
from mpva.render import PRESETS, _fit

VENDOR = ROOT / "vendor" / "video-use"


def scribe_payload(words: list[dict]) -> dict:
    rows = []
    for item in words:
        text = str(item.get("text") or "").strip()
        if not text or text.startswith("["):
            continue
        rows.append(
            {
                "type": "word",
                "text": text,
                "start": round(float(item["start"]), 3),
                "end": round(float(item["end"]), 3),
                "speaker_id": "S0",
            }
        )
    return {"words": rows, "text": " ".join(row["text"] for row in rows)}


def sentence_srt(cues: list[dict], dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    index = 1
    for cue in cues:
        text = str(cue.get("text") or "").strip()
        if not text:
            continue
        start = max(0.0, float(cue["start"]))
        end = max(start + 0.4, float(cue["end"]))
        lines.append(str(index))
        lines.append(f"{_ts(start)} --> {_ts(end)}")
        lines.append(text)
        lines.append("")
        index += 1
    dest.write_text("\n".join(lines), encoding="utf-8")
    return dest


def write_edl(edit_dir: Path, sources: dict[str, str], ranges: list[dict], subtitles: Path | None) -> Path:
    edit_dir.mkdir(parents=True, exist_ok=True)
    total = round(sum(float(row["end"]) - float(row["start"]) for row in ranges), 3)
    edl = {
        "version": 1,
        "sources": sources,
        "ranges": ranges,
        "grade": "eq=contrast=1.03:saturation=0.98",
        "overlays": [],
        "subtitles": str(subtitles) if subtitles else "",
        "total_duration_s": total,
    }
    path = edit_dir / "edl.json"
    path.write_text(json.dumps(edl, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def render_interview(
    source: Path,
    dest: Path,
    *,
    start: float,
    end: float,
    words: list[dict],
    edit_dir: Path,
    captions: list[dict] | None = None,
) -> Path:
    edit_dir.mkdir(parents=True, exist_ok=True)
    (edit_dir / "transcripts").mkdir(parents=True, exist_ok=True)
    (edit_dir / "transcripts" / f"{source.stem}.json").write_text(
        json.dumps(scribe_payload(words), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    cues = captions if captions is not None else pack_cues(
        [
            {
                "text": item.get("text"),
                "start": max(0.0, float(item["start"]) - start),
                "end": max(0.06, float(item["end"]) - start),
            }
            for item in words
            if float(item.get("end") or 0) > start and float(item.get("start") or 0) < end
        ]
    )
    srt = sentence_srt(cues, edit_dir / "master.srt")
    ranges = [{"source": source.stem, "start": start, "end": end, "beat": "SPEECH"}]
    write_edl(edit_dir, {source.stem: str(source.resolve())}, ranges, srt)
    return render_edl(edit_dir, dest)


def render_story(story: dict, assets: list[dict], dest: Path, edit_dir: Path) -> Path:
    edit_dir.mkdir(parents=True, exist_ok=True)
    by_id = {item["id"]: item for item in assets}
    parts = []
    clips_dir = edit_dir / "clips_graded"
    clips_dir.mkdir(parents=True, exist_ok=True)
    for index, beat in enumerate(story.get("beats") or []):
        duration = max(0.4, float(beat.get("end") or 0) - float(beat.get("start") or 0))
        part = clips_dir / f"seg_{index:02d}.mp4"
        _render_beat(beat, by_id, part, duration)
        if part.is_file() and part.stat().st_size > 500:
            parts.append(part)
    if not parts:
        raise RuntimeError("No usable beats")
    base = edit_dir / "base.mp4"
    concat_copy(parts, base)
    sentence_srt(_story_words(story, assets), edit_dir / "master.srt")
    dest.parent.mkdir(parents=True, exist_ok=True)
    run([find_bin("ffmpeg"), "-y", "-i", str(base), "-c", "copy", str(dest)])
    _self_eval(dest, sum(float(b["end"]) - float(b["start"]) for b in story.get("beats") or []))
    return dest


def render_timeline_proxy(plan: dict, dest: Path, edit_dir: Path) -> Path:
    sources = {}
    ranges = []
    for item in plan.get("timeline") or []:
        if item.get("kind") in {"audio", "image"}:
            continue
        if item.get("track") not in {"main", "broll"}:
            continue
        src = Path(item.get("source") or "")
        if not src.is_file():
            continue
        key = src.stem
        sources[key] = str(src.resolve())
        ranges.append(
            {
                "source": key,
                "start": float(item.get("source_start") or 0),
                "end": float(item.get("source_end") or 0),
                "beat": str(item.get("track") or "MAIN").upper(),
            }
        )
    if not ranges:
        raise RuntimeError("No video clips in edit plan")
    write_edl(edit_dir, sources, ranges, None)
    return render_edl(edit_dir, dest)


def render_edl(edit_dir: Path, dest: Path) -> Path:
    edl = json.loads((edit_dir / "edl.json").read_text(encoding="utf-8"))
    clips_dir = edit_dir / "clips_graded"
    clips_dir.mkdir(parents=True, exist_ok=True)
    parts = []
    sources = edl["sources"]
    for index, row in enumerate(edl.get("ranges") or []):
        src = Path(sources[row["source"]])
        start = float(row["start"])
        duration = max(0.4, float(row["end"]) - start)
        part = clips_dir / f"seg_{index:02d}.mp4"
        _extract(src, start, duration, part)
        parts.append(part)
    base = edit_dir / "base.mp4"
    concat_copy(parts, base)
    dest.parent.mkdir(parents=True, exist_ok=True)
    run([find_bin("ffmpeg"), "-y", "-i", str(base), "-c", "copy", str(dest)])
    expected = float(edl.get("total_duration_s") or 0)
    _self_eval(dest, expected)
    return dest


def _render_beat(beat: dict, by_id: dict, dest: Path, duration: float) -> None:
    video = beat.get("video") or {}
    audio = beat.get("audio") or {}
    photos = beat.get("photos") or []
    vpath = Path(video.get("path") or "")
    apath = Path(audio.get("path") or "")
    if photos and not vpath.is_file():
        still = dest.with_name(dest.stem + "_still.mp4")
        _stills(photos, still, duration)
        if apath.is_file():
            _mux(still, apath, float(audio.get("in") or 0), duration, dest)
        else:
            still.replace(dest)
        return
    if vpath.is_file() and apath.is_file() and (beat.get("jcut") or apath != vpath):
        _extract_split(vpath, float(video.get("in") or 0), apath, float(audio.get("in") or 0), duration, dest)
        return
    if vpath.is_file():
        _extract(vpath, float(video.get("in") or 0), duration, dest)
        return
    _color(dest, duration)


def _extract(src: Path, start: float, duration: float, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    fade = max(0.0, duration - 0.03)
    vf = _fit(1080, 1920, reframe=True)
    af = f"afade=t=in:st=0:d=0.03,afade=t=out:st={fade:.3f}:d=0.03,loudnorm=I=-16:TP=-1.5:LRA=11"
    run(
        [
            find_bin("ffmpeg"),
            "-y",
            "-ss",
            f"{start:.3f}",
            "-t",
            f"{duration:.3f}",
            "-i",
            str(src),
            "-vf",
            vf,
            "-af",
            af,
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "20",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-b:a",
            "160k",
            str(dest),
        ]
    )


def _extract_split(video: Path, vin: float, audio: Path, ain: float, duration: float, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    fade = max(0.0, duration - 0.03)
    vf = _fit(1080, 1920, reframe=True)
    af = f"afade=t=in:st=0:d=0.03,afade=t=out:st={fade:.3f}:d=0.03,loudnorm=I=-16:TP=-1.5:LRA=11"
    run(
        [
            find_bin("ffmpeg"),
            "-y",
            "-ss",
            f"{vin:.3f}",
            "-t",
            f"{duration:.3f}",
            "-i",
            str(video),
            "-ss",
            f"{ain:.3f}",
            "-t",
            f"{duration:.3f}",
            "-i",
            str(audio),
            "-map",
            "0:v:0",
            "-map",
            "1:a:0",
            "-vf",
            vf,
            "-af",
            af,
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "20",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-b:a",
            "160k",
            "-shortest",
            str(dest),
        ]
    )


def _stills(photos: list[dict], dest: Path, duration: float) -> None:
    usable = [item for item in photos if Path(item.get("path") or "").is_file()]
    if not usable:
        _color(dest, duration)
        return
    src = Path(usable[0]["path"])
    vf = _fit(1080, 1920, reframe=True) + ",format=yuv420p"
    argv = [find_bin("ffmpeg"), "-y"]
    if src.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp", ".bmp"}:
        argv += ["-loop", "1", "-t", f"{duration:.3f}", "-i", str(src)]
    else:
        argv += ["-t", f"{duration:.3f}", "-i", str(src)]
    argv += ["-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-an", str(dest)]
    run(argv)


def _mux(video: Path, audio: Path, ain: float, duration: float, dest: Path) -> None:
    fade = max(0.0, duration - 0.03)
    run(
        [
            find_bin("ffmpeg"),
            "-y",
            "-i",
            str(video),
            "-ss",
            f"{ain:.3f}",
            "-t",
            f"{duration:.3f}",
            "-i",
            str(audio),
            "-map",
            "0:v:0",
            "-map",
            "1:a:0",
            "-af",
            f"afade=t=in:st=0:d=0.03,afade=t=out:st={fade:.3f}:d=0.03,loudnorm=I=-16:TP=-1.5:LRA=11",
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-shortest",
            str(dest),
        ]
    )


def _concat(parts: list[Path], dest: Path) -> None:
    concat_copy(parts, dest)


def _burn(src: Path, dest: Path, srt: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    style = (
        "FontName=Segoe UI,FontSize=16,Bold=1,PrimaryColour=&H00FFFFFF,"
        "OutlineColour=&H00000000,BorderStyle=1,Outline=2,Shadow=0,Alignment=2,MarginV=90"
    )
    escaped = str(srt.resolve()).replace("\\", "/").replace(":", "\\:")
    run(
        [
            find_bin("ffmpeg"),
            "-y",
            "-i",
            str(src),
            "-vf",
            f"subtitles='{escaped}':force_style='{style}'",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "20",
            "-c:a",
            "copy",
            str(dest),
        ]
    )


def _color(dest: Path, duration: float) -> None:
    spec = PRESETS["vertical"]
    run(
        [
            find_bin("ffmpeg"),
            "-y",
            "-f",
            "lavfi",
            "-i",
            f"color=c=0x0b1a28:s={spec['width']}x{spec['height']}:d={duration:.3f}",
            "-f",
            "lavfi",
            "-i",
            "anullsrc=r=48000:cl=stereo",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-shortest",
            str(dest),
        ]
    )


def _story_words(story: dict, assets: list[dict]) -> list[dict]:
    from mpva.assemble import story_captions

    return story_captions(story, assets)


def _self_eval(path: Path, expected: float) -> None:
    if not path.is_file():
        raise RuntimeError("Render produced no file")
    got = float(probe(path).get("duration") or 0)
    if expected and abs(got - expected) > 2.5:
        raise RuntimeError(f"Self-eval failed: rendered {got:.1f}s, plan {expected:.1f}s")


def _ts(seconds: float) -> str:
    total = int(round(max(0.0, seconds) * 1000))
    h, rem = divmod(total, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"
