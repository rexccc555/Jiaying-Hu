from __future__ import annotations

import json
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from mpva.paths import JOBS

_lock = threading.Lock()


def create_job(name: str, video: Path) -> dict:
    job_id = uuid4().hex[:12]
    job = {
        "id": job_id,
        "name": name,
        "status": "uploaded",
        "video": str(video),
        "created": datetime.now(timezone.utc).isoformat(),
        "log": ["Files received."],
        "kind": "speech",
        "title": "",
        "target_seconds": 60,
        "duration": 0,
        "language": "auto",
        "language_detected": "",
        "asr_engine": "",
        "assets": [],
        "words": [],
        "clips": [],
        "edl": {},
        "exports": {},
        "steps": [],
        "intent": "",
        "alts": [],
        "brief": "",
        "error": "",
    }
    save(job)
    return job


def save(job: dict) -> None:
    JOBS.mkdir(parents=True, exist_ok=True)
    path = JOBS / f"{job['id']}.json"
    payload = json.dumps(job, ensure_ascii=False, indent=2)
    tmp = path.with_name(f"{path.stem}.{os.getpid()}.{threading.get_ident()}.tmp")
    with _lock:
        tmp.write_text(payload, encoding="utf-8")
        _replace(tmp, path)


def get(job_id: str) -> dict | None:
    path = JOBS / f"{job_id}.json"
    if not path.is_file():
        return None
    last: Exception | None = None
    for attempt in range(12):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (PermissionError, OSError, json.JSONDecodeError) as exc:
            last = exc
            time.sleep(0.04 * (attempt + 1))
    if last:
        raise last
    return None


def log(job: dict, line: str) -> None:
    job.setdefault("log", []).append(line)
    save(job)


def _replace(tmp: Path, path: Path) -> None:
    last: Exception | None = None
    for attempt in range(16):
        try:
            os.replace(tmp, path)
            return
        except OSError as exc:
            last = exc
            if not _retryable(exc) or attempt == 15:
                break
            time.sleep(0.05 * (attempt + 1))
    try:
        path.write_text(tmp.read_text(encoding="utf-8"), encoding="utf-8")
        tmp.unlink(missing_ok=True)
        return
    except OSError as exc:
        last = exc
    if tmp.exists():
        try:
            tmp.unlink()
        except OSError:
            pass
    raise last or PermissionError(f"无法保存任务文件: {path}")


def _retryable(exc: OSError) -> bool:
    win = getattr(exc, "winerror", None)
    return isinstance(exc, PermissionError) or exc.errno in {13, 11} or win in {5, 32, 33}
