from __future__ import annotations

import os
from pathlib import Path


def load_env(root: Path | None = None) -> None:
    path = (root or Path(__file__).resolve().parent.parent) / ".env"
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value
