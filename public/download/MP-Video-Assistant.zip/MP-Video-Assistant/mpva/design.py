"""Remotion design engine. Falls back to FFmpeg+ASS if Node render is unavailable."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from mpva.captions import pack_cues
from mpva.ffmpeg_tools import find_bin, run
from mpva.paths import ROOT
from mpva.render import PRESETS, _esc, _ts

DESIGN = ROOT / "design"


def render_design(cut: Path, dest: Path, plan: dict, *, preset: str) -> Path:
    spec = PRESETS[preset]
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        return _remotion(cut, dest, plan, spec)
    except Exception as exc:
        plan.setdefault("render_notes", []).append(f"Remotion skipped: {exc}")
        return _ass_overlay(cut, dest, plan, spec)


def available() -> bool:
    return (DESIGN / "package.json").is_file() and (
        shutil.which("npx.cmd") or shutil.which("npx")
    )


def _remotion(cut: Path, dest: Path, plan: dict, spec: dict) -> Path:
    if not (DESIGN / "package.json").is_file():
        raise RuntimeError("design/package.json missing")
    public = DESIGN / "public"
    public.mkdir(parents=True, exist_ok=True)
    shutil.copy2(cut, public / "cut.mp4")
    props = {
        "video": "cut.mp4",
        "durationInSeconds": float(plan.get("duration") or 8),
        "width": spec["width"],
        "height": spec["height"],
        "mode": plan.get("mode") or "clean",
        "topic": (plan.get("clip") or {}).get("topic") or "",
        "name": (plan.get("brand") or {}).get("name") or os.environ.get("MP_DISPLAY_NAME") or "Member of Parliament",
        "role": (plan.get("brand") or {}).get("role") or os.environ.get("MP_DISPLAY_ROLE") or "Parliament of New Zealand",
        "captions": pack_cues(plan.get("captions") or []),
        "visuals": plan.get("visuals") or [],
    }
    props_path = dest.with_suffix(".props.json")
    props_path.write_text(json.dumps(props, ensure_ascii=False), encoding="utf-8")
    local = DESIGN / "node_modules" / ".bin" / ("remotion.cmd" if os.name == "nt" else "remotion")
    if local.is_file():
        cmd = [str(local), "render", "src/index.js", "MpClip", str(dest), f"--props={props_path}", "--timeout=180000"]
    else:
        npx = shutil.which("npx.cmd") or shutil.which("npx")
        if not npx:
            raise RuntimeError("npx missing")
        cmd = [npx, "--yes", "remotion", "render", "src/index.js", "MpClip", str(dest), f"--props={props_path}", "--timeout=180000"]
    env = os.environ.copy()
    env.pop("NODE_OPTIONS", None)
    result = subprocess.run(
        cmd,
        cwd=str(DESIGN),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=420,
        env=env,
        shell=False,
    )
    if result.returncode != 0 or not dest.is_file():
        err = (result.stderr or result.stdout or "Remotion render failed")[-1600:]
        raise RuntimeError(err)
    return dest


def _ass_overlay(cut: Path, dest: Path, plan: dict, spec: dict) -> Path:
    ass = dest.with_suffix(".ass")
    _write_plan_ass(ass, plan, spec["width"], spec["height"])
    run(
        [
            find_bin("ffmpeg"),
            "-y",
            "-i",
            str(cut),
            "-vf",
            f"subtitles='{_esc(ass)}'",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "19",
            "-c:a",
            "copy",
            str(dest),
        ]
    )
    return dest


def _write_plan_ass(path: Path, plan: dict, width: int, height: int) -> None:
    font = "Microsoft YaHei"
    caption_size = 68 if height >= 1600 else 50
    lines = [
        "[Script Info]",
        "ScriptType: v4.00+",
        f"PlayResX: {width}",
        f"PlayResY: {height}",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        f"Style: Caption,{font},{caption_size},&H00FFFFFF,&H000000FF,&H00101828,&H90000000,-1,0,1,5,0,2,48,48,{130 if height >= 1600 else 72},1",
        f"Style: Emph,{font},{caption_size + 8},&H0000E6FF,&H000000FF,&H00101828,&H90000000,-1,0,1,5,0,2,48,48,{130 if height >= 1600 else 72},1",
        f"Style: Title,{font},72,&H00FFFFFF,&H000000FF,&H00101828,&H96000000,-1,0,1,4,0,8,40,40,80,1",
        f"Style: Lower,{font},40,&H00FFFFFF,&H000000FF,&H00101828,&H96000000,-1,0,1,3,0,1,56,56,90,1",
        f"Style: Number,{font},96,&H00FFFFFF,&H000000FF,&H00101828,&H96000000,-1,0,1,5,0,5,40,40,40,1",
        "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    for vis in plan.get("visuals") or []:
        start = float(vis.get("time") or 0)
        end = start + float(vis.get("duration") or 2.5)
        text = _ass(str(vis.get("text") or ""))
        component = vis.get("component")
        if component == "Headline" and text:
            lines.append(f"Dialogue: 0,{_ts(start)},{_ts(end)},Title,,0,0,40,,{text}")
        elif component == "LowerThird":
            meta = _ass(str(vis.get("meta") or ""))
            body = text + (f"\\N{meta}" if meta else "")
            lines.append(f"Dialogue: 0,{_ts(start)},{_ts(end)},Lower,,0,0,40,,{body}")
        elif component == "BigNumber" and text:
            lines.append(f"Dialogue: 0,{_ts(start)},{_ts(end)},Number,,0,0,40,,{text}")
        elif component == "Quote" and text:
            lines.append(f"Dialogue: 0,{_ts(start)},{_ts(end)},Title,,0,0,200,,“{text}”")
    captions = pack_cues(plan.get("captions") or [])
    plan["captions"] = captions
    for cap in captions:
        lines.extend(_caption_lines([cap]))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _caption_lines(group: list[dict]) -> list[str]:
    start = float(group[0]["start"])
    end = float(group[-1]["end"])
    bits = []
    for item in group:
        text = _ass(item["text"])
        if item.get("emphasis"):
            bits.append(r"{\c&H00E6FF&}" + text + r"{\c&HFFFFFF&}")
        else:
            bits.append(text)
    joiner = "" if _cjk("".join(item["text"] for item in group)) else " "
    return [f"Dialogue: 0,{_ts(start)},{_ts(end)},Caption,,0,0,80,,{joiner.join(bits)}"]


def _cjk(text: str) -> bool:
    return any("\u4e00" <= ch <= "\u9fff" for ch in text)


def _ass(text: str) -> str:
    return (text or "").replace("\n", "\\N").replace("{", "(").replace("}", ")")
