"""Handoff to Agent Motion. We do not copy their Skills (noncommercial license)."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

from mpva.captions import pack_cues, squeeze_cjk
from mpva.ffmpeg_tools import find_bin, probe, run
from mpva.paths import ROOT
from mpva.videouse import sentence_srt

MOTION_ROOT = ROOT / "vendor" / "agent-motion"


def ready() -> bool:
    return (MOTION_ROOT / "AGENTS.md").is_file() and (MOTION_ROOT / "package.json").is_file()


def bootstrapped() -> bool:
    return (MOTION_ROOT / "node_modules" / "three").exists() or (MOTION_ROOT / ".runtime").exists()


def write_complete_srt(words: list[dict], dest: Path) -> Path:
    cues = pack_cues(
        [
            {
                "text": squeeze_cjk(str(item.get("text") or "").strip()),
                "start": float(item.get("start") or 0),
                "end": float(item.get("end") or 0),
            }
            for item in words
            if str(item.get("text") or "").strip() and not str(item.get("text") or "").startswith("[")
        ],
        max_sec=4.8,
        max_chars=48,
    )
    dest.parent.mkdir(parents=True, exist_ok=True)
    return sentence_srt(cues, dest)


ENV_READY = (
    "运行环境已由网站预检通过（Node、FFmpeg/libx264、Chromium WebGL2、RVM 抠像、fontTools/scipy/pillow/numpy 都已装好），"
    "不要重复安装或排查环境，直接进入制作；质量检查照常做足。"
)


REF_VIDEO = {".mp4", ".mov", ".mkv", ".m4v", ".webm", ".avi"}
REF_IMAGE = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp"}


def reference_note(refs: list[str], sheets: list[str]) -> str:
    if not refs:
        return ""
    overview = f"（每个视频的关键画面总览：{'、'.join(sheets)}）" if sheets else ""
    return (
        f"风格参考：{'、'.join(refs)}{overview}。这些是视觉参考，不是原片。"
        "先完整观看并分析它们的排版与字体气质、配色、版面密度、镜头与转场节奏、动效方式和空间层次，"
        "把“风格要点”写进 PLAN.md，再用同样的风格包装本片，让成片明显接近参考的感觉；"
        "不要复制参考里的人物、文字、Logo、具体画面和配乐。人物、口播内容与时间仍以原片和 SRT 为准。"
    )


def stage_references(refs: list[str], dest: Path) -> tuple[list[Path], list[Path]]:
    """Copy reference videos/images next to the source and make a 4x3 keyframe sheet per video."""
    shutil.rmtree(dest, ignore_errors=True)
    if not refs:
        return [], []
    dest.mkdir(parents=True, exist_ok=True)
    copied, sheets = [], []
    for index, raw in enumerate(refs, 1):
        src = Path(raw)
        suffix = src.suffix.lower()
        if not src.is_file() or suffix not in REF_VIDEO | REF_IMAGE:
            continue
        target = dest / f"ref-{index}{suffix}"
        shutil.copy2(src, target)
        copied.append(target)
        if suffix in REF_VIDEO:
            sheet = dest / f"ref-{index}-sheet.jpg"
            if _contact_sheet(target, sheet):
                sheets.append(sheet)
    return copied, sheets


def _contact_sheet(video: Path, sheet: Path) -> bool:
    try:
        duration = float(probe(video).get("duration") or 0)
        rate = 12 / duration if duration > 0 else 1
        run(
            [
                find_bin("ffmpeg"), "-y", "-i", str(video),
                "-vf", f"fps={rate:.4f},scale=360:-2,tile=4x3:padding=6:color=white",
                "-frames:v", "1", "-q:v", "3", str(sheet),
            ],
            timeout=300,
        )
        return sheet.is_file()
    except Exception:  # noqa: BLE001 — the sheet is a convenience; the agent can still watch the video
        return False


def agent_prompt(
    *, video: str, srt: str, brief: str, work: str, env_ready: bool = False, refs: list[str] | None = None, sheets: list[str] | None = None
) -> str:
    extra = (brief or "").strip()
    style = extra or ("按风格参考的感觉来做，口播原声保留，不要改口。" if refs else "竖屏 9:16，口播原声保留，画面用排版、空间和转场解释正在说的内容，不要改口。")
    return (
        (ENV_READY if env_ready else "")
        + "先读 AGENTS.md，按需完成安装指南，再读本项目两个本地 Skill。"
        f"根据 {video} 与 {srt} 完成口播视频动效包装。"
        "先制作并检查与原片同步的人物抠像层，再进入合成；保留原口播顺序和时间。"
        f"在 {work} 制作，完成各阶段和实际画面、声音检查，交付 MP4 及可编辑工程。"
        f"最终成片保存为 {work}final.mp4。"
        + reference_note(refs or [], sheets or [])
        + f"我的画幅和风格要求是：{style}"
    )


def stage_film(job: dict, lead: dict, *, words: list[dict], env_ready: bool = False) -> dict:
    if not ready():
        raise RuntimeError("找不到 vendor/agent-motion。请先克隆 https://github.com/erduo1998-cell/agent-motion")
    inputs = MOTION_ROOT / "inputs" / f"film-{job['id']}"
    work = MOTION_ROOT / "work" / f"film-{job['id']}"
    inputs.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    src = Path(lead.get("path") or job["video"])
    dest_video = inputs / "source.mp4"
    if src.resolve() != dest_video.resolve():
        shutil.copy2(src, dest_video)
    srt = write_complete_srt(words or lead.get("words") or [], inputs / "source.srt")
    brief = str(job.get("brief") or "").strip()
    (inputs / "brief.txt").write_text(brief, encoding="utf-8")
    base = f"inputs/film-{job['id']}"
    refs, sheets = stage_references(job.get("refs") or [], inputs / "reference")
    prompt = agent_prompt(
        video=f"{base}/source.mp4",
        srt=f"{base}/source.srt",
        brief=brief,
        work=f"work/film-{job['id']}/",
        env_ready=env_ready,
        refs=[f"{base}/reference/{path.name}" for path in refs],
        sheets=[f"{base}/reference/{path.name}" for path in sheets],
    )
    (work / "PROMPT.txt").write_text(prompt, encoding="utf-8")
    (work / "handoff.json").write_text(
        json.dumps(
            {
                "job_id": job["id"],
                "source": str(dest_video),
                "srt": str(srt),
                "work": str(work),
                "license": "Agent Motion is Motion Craft Community License 1.0 — noncommercial. Commercial/office use needs written authorization from the author.",
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return {
        "root": str(MOTION_ROOT),
        "video": str(dest_video),
        "srt": str(srt),
        "work": str(work),
        "prompt": prompt,
        "bootstrapped": bootstrapped(),
    }


def matte_sample(work: Path, seconds: float = 2.0) -> dict:
    if not bootstrapped():
        return {"ok": False, "detail": "Agent Motion 尚未安装。请在 vendor/agent-motion 运行 node scripts/bootstrap.mjs"}
    out = work / "person-preview"
    try:
        result = subprocess.run(
            [
                "npm",
                "run",
                "matte",
                "--",
                "--input",
                "inputs/source.mp4",
                "--output",
                str(Path("work") / work.name / "person-preview"),
                "--seconds",
                str(seconds),
            ],
            cwd=str(MOTION_ROOT),
            capture_output=True,
            text=True,
            timeout=600,
            encoding="utf-8",
            errors="replace",
        )
    except Exception as exc:
        return {"ok": False, "detail": str(exc)[:400]}
    if result.returncode != 0:
        err = (result.stderr or result.stdout or "")[-500:]
        return {"ok": False, "detail": err or "matting failed"}
    return {"ok": True, "detail": str(out), "foreground": str(out / "foreground.mp4")}
