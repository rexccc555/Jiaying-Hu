"""Keyframe + vision pass. Builds what the Director can actually see."""

from __future__ import annotations

import base64
import json
import os
import re
import urllib.request
from pathlib import Path

from mpva.ffmpeg_tools import find_bin, run
from mpva.intel import _role_from_name
from mpva.llm import model_names


def enrich_assets(assets: list[dict], *, on_line=None) -> list[dict]:
    log = on_line or (lambda _line: None)
    for asset in assets:
        path = Path(asset.get("path") or "")
        if not path.is_file():
            continue
        thumbs = path.parent / "thumbs" / asset["id"]
        frames = _keyframes(path, thumbs, photo=asset.get("kind") in {"photo", "logo"})
        asset["keyframes"] = [{"time": t, "path": str(p)} for t, p in frames]
        seen = _vision(frames, asset, log)
        if seen:
            asset["visual_description"] = seen.get("description") or asset.get("visual_description")
            if seen.get("role") and not (asset.get("speech") and asset.get("role") == "speech"):
                if not _role_from_name(asset.get("file") or ""):
                    asset["role"] = seen.get("role") or asset.get("role")
            asset["people"] = seen.get("people") or asset.get("people") or []
            if seen.get("usable") and not asset.get("speech"):
                asset["usable_ranges"] = seen["usable"]
            asset["shots"] = seen.get("shots") or []
        log(f"Media map: {asset.get('file')} · {asset.get('role')} · {asset.get('visual_description')}")
    return assets


def _keyframes(src: Path, dest: Path, *, photo: bool) -> list[tuple[float, Path]]:
    dest.mkdir(parents=True, exist_ok=True)
    if photo:
        still = dest / "still.jpg"
        try:
            run([find_bin("ffmpeg"), "-y", "-i", str(src), "-frames:v", "1", str(still)])
            return [(0.0, still)] if still.is_file() else []
        except Exception:
            return [(0.0, src)]
    from mpva.ffmpeg_tools import probe

    duration = float(probe(src).get("duration") or 0)
    if duration <= 0:
        return []
    count = 4 if duration < 20 else 6
    times = [1.0, 3.5] if duration > 8 else []
    times += [round(duration * (i + 1) / (count + 1), 2) for i in range(count)]
    times = sorted({t for t in times if 0.15 < t < duration - 0.2})[:8]
    out = []
    for index, stamp in enumerate(times):
        frame = dest / f"k{index:02d}.jpg"
        try:
            run(
                [
                    find_bin("ffmpeg"),
                    "-y",
                    "-ss",
                    f"{stamp:.2f}",
                    "-i",
                    str(src),
                    "-frames:v",
                    "1",
                    "-q:v",
                    "5",
                    str(frame),
                ]
            )
            if frame.is_file():
                out.append((stamp, frame))
        except Exception:
            continue
    return out


def _vision(frames: list[tuple[float, Path]], asset: dict, log) -> dict:
    key = os.environ.get("OPENAI_API_KEY") or ""
    if not key or not frames:
        return {}
    base = (os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
    if not base.endswith("/v1"):
        base += "/v1"
    model = (os.environ.get("OPENAI_VISION_MODEL") or os.environ.get("OPENAI_MODEL") or "gpt-4o-mini").split(",")[0].strip()
    names = []
    vision = (os.environ.get("OPENAI_VISION_MODEL") or "").strip()
    if vision:
        names.append(vision.split(",")[0].strip())
    names.extend(model_names())
    seen = []
    for name in names:
        if name and name not in seen:
            seen.append(name)
    names = [name for name in seen if "0613" not in name] or seen
    content = [
        {
            "type": "text",
            "text": (
                "You map political-office footage. Do not rank political opinions. "
                "Describe what is visible. Return JSON only: "
                "{description, role: speech|arrival|handshake|crowd|broll|photo|logo, "
                "people: [speaker|crowd], shots:[{time,label}], "
                "usable:[[start,end]]}. "
                f"File={asset.get('file')} duration={asset.get('duration')} speech={asset.get('speech')}."
            ),
        }
    ]
    for stamp, path in frames[:6]:
        raw = path.read_bytes()
        if len(raw) < 80:
            continue
        b64 = base64.b64encode(raw).decode("ascii")
        content.append({"type": "text", "text": f"frame at {stamp}s"})
        content.append({"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}})
    last = ""
    for model in names:
        payload = {
            "model": model,
            "temperature": 0.1,
            "messages": [{"role": "user", "content": content}],
            "max_tokens": 500,
        }
        request = urllib.request.Request(
            base + "/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=40) as response:
                data = json.loads(response.read().decode("utf-8"))
            text = (((data.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()
            text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I | re.S)
            parsed = json.loads(text)
            if not isinstance(parsed, dict):
                last = f"{model} not object"
                continue
            role = str(parsed.get("role") or "")
            if role not in {"speech", "arrival", "handshake", "crowd", "broll", "photo", "logo", "leave"}:
                parsed.pop("role", None)
            usable = []
            for row in parsed.get("usable") or []:
                if isinstance(row, (list, tuple)) and len(row) == 2:
                    try:
                        usable.append([round(_seconds(row[0]), 2), round(_seconds(row[1]), 2)])
                    except (TypeError, ValueError):
                        continue
            parsed["usable"] = usable
            return parsed
        except Exception as exc:
            last = str(exc)
            continue
    if last:
        log(f"Vision skipped for {asset.get('file')}: {last}")
    return {}


def _seconds(value) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    match = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*s(?:ec(?:onds?)?)?\s*$", str(value), flags=re.I)
    if match:
        return float(match.group(1))
    return float(str(value).strip())
