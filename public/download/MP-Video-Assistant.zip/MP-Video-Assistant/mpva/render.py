from __future__ import annotations

import os
from pathlib import Path

from mpva.clean import apply_policy, cuts_from_words
from mpva.ffmpeg_tools import find_bin, run

PRESETS = {
    "vertical": {"label": "9:16", "width": 1080, "height": 1920},
    "landscape": {"label": "16:9", "width": 1920, "height": 1080},
    "square": {"label": "1:1", "width": 1080, "height": 1080},
}

STYLES = ("clean", "social", "enhanced", "formal")


def export_clip(
    src: Path,
    dest: Path,
    *,
    words: list[dict],
    start: float,
    end: float,
    preset: str,
    title: str,
    style: str = "clean",
    captions: bool = True,
    reframe: bool = True,
    remove_fillers: bool = True,
    remove_pauses: bool = True,
) -> Path:
    spec = PRESETS[preset]
    window = [item for item in words if item["end"] >= start and item["start"] <= end]
    applied = apply_policy(window, remove_fillers=remove_fillers, remove_pauses=remove_pauses)
    keeps = cuts_from_words(applied, total_duration=end)
    keeps = [(max(start, a), min(end, b)) for a, b in keeps if min(end, b) - max(start, a) > 0.12]
    if not keeps:
        keeps = [(start, end)]
    dest.parent.mkdir(parents=True, exist_ok=True)
    vf = _fit(spec["width"], spec["height"], reframe=reframe)
    ass = dest.with_suffix(".ass")
    _write_ass(ass, applied, keeps, title, spec["width"], spec["height"], style=style, captions=captions)
    if captions or style in {"social", "speech"}:
        vf = vf + f",subtitles='{_esc(ass)}'"
    af = "loudnorm=I=-16:TP=-1.5:LRA=11"
    if len(keeps) == 1 and abs(keeps[0][0] - start) < 0.05 and abs(keeps[0][1] - end) < 0.05:
        run(
            [
                find_bin("ffmpeg"),
                "-y",
                "-ss",
                f"{start:.3f}",
                "-to",
                f"{end:.3f}",
                "-i",
                str(src),
                "-vf",
                vf,
                "-af",
                af,
                "-c:v",
                "libx264",
                "-preset",
                "veryfast",
                "-crf",
                "20",
                "-c:a",
                "aac",
                "-b:a",
                "160k",
                str(dest),
            ]
        )
        return dest
    expr = "+".join(f"between(t,{a:.3f},{b:.3f})" for a, b in keeps)
    run(
        [
            find_bin("ffmpeg"),
            "-y",
            "-i",
            str(src),
            "-vf",
            f"select='{expr}',setpts=N/FRAME_RATE/TB,{vf}",
            "-af",
            f"aselect='{expr}',asetpts=N/SR/TB,{af}",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "20",
            "-c:a",
            "aac",
            "-b:a",
            "160k",
            str(dest),
        ]
    )
    return dest


def _fit(width: int, height: int, reframe: bool) -> str:
    ratio = width / height
    if reframe:
        return (
            f"crop='if(gte(iw/ih,{ratio}),ih*{ratio},iw)':'if(gte(iw/ih,{ratio}),ih,iw/{ratio})'"
            f":'(iw-ow)/2':'(ih-oh)/2',scale={width}:{height}"
        )
    return (
        f"scale={width}:{height}:force_original_aspect_ratio=decrease,"
        f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:black"
    )


def _write_ass(
    path: Path,
    words: list[dict],
    keeps: list[tuple[float, float]],
    title: str,
    width: int,
    height: int,
    *,
    style: str,
    captions: bool,
) -> None:
    mapped = []
    offset = 0.0
    for ks, ke in keeps:
        for word in words:
            if word.get("keep") is False or word.get("kind") == "silence":
                continue
            if word["start"] >= ke or word["end"] <= ks:
                continue
            mapped.append((offset + max(0, word["start"] - ks), offset + min(ke, word["end"]) - ks, word["text"]))
        offset += ke - ks
    font = "Microsoft YaHei"
    caption_size = 64 if height >= 1600 else 48
    title_size = 72 if height >= 1600 else 54
    lines = [
        "[Script Info]",
        "ScriptType: v4.00+",
        f"PlayResX: {width}",
        f"PlayResY: {height}",
        "WrapStyle: 2",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        f"Style: Caption,{font},{caption_size},&H00FFFFFF,&H000000FF,&H00101010,&H80000000,-1,0,1,4,0,2,50,50,{120 if height >= 1600 else 70},1",
        f"Style: Title,{font},{title_size},&H00FFFFFF,&H000000FF,&H00101010,&H96000000,-1,0,1,4,0,8,40,40,70,1",
        f"Style: Lower,{font},42,&H00FFFFFF,&H000000FF,&H00101010,&H96000000,-1,0,1,3,0,1,60,60,90,1",
        "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    name = os.environ.get("MP_DISPLAY_NAME") or "Member of Parliament"
    role = os.environ.get("MP_DISPLAY_ROLE") or "Parliament of New Zealand"
    if style == "social" and title:
        lines.append(f"Dialogue: 0,{_ts(0)},{_ts(3.2)},Title,,0,0,40,,{ _ass_text(title)}")
    if style == "speech":
        lower = _ass_text(f"{name}\\N{role}")
        lines.append(f"Dialogue: 0,{_ts(0)},{_ts(4.5)},Lower,,0,0,40,,{lower}")
    if captions:
        cue = ""
        cue_start = None
        cue_end = None
        limit = 18 if _has_cjk(mapped) else 42
        for start, end, text in mapped:
            if cue_start is None:
                cue_start, cue_end, cue = start, end, text
                continue
            joiner = "" if _glue(cue, text) else " "
            if len(cue + joiner + text) < limit and end - cue_start < 3.2:
                cue += joiner + text
                cue_end = end
            else:
                lines.append(f"Dialogue: 0,{_ts(cue_start)},{_ts(cue_end)},Caption,,0,0,80,,{_ass_text(cue)}")
                cue_start, cue_end, cue = start, end, text
        if cue_start is not None:
            lines.append(f"Dialogue: 0,{_ts(cue_start)},{_ts(cue_end)},Caption,,0,0,80,,{_ass_text(cue)}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _has_cjk(mapped: list[tuple[float, float, str]]) -> bool:
    return any("\u4e00" <= ch <= "\u9fff" for _, _, text in mapped for ch in text)


def _glue(left: str, right: str) -> bool:
    if not left or not right:
        return False
    return ("\u4e00" <= left[-1] <= "\u9fff") or ("\u4e00" <= right[0] <= "\u9fff") or right[0] in ".,!?，。！？、"


def _ass_text(text: str) -> str:
    return (text or "").replace("\n", "\\N").replace("{", "(").replace("}", ")")


def _ts(seconds: float) -> str:
    seconds = max(0.0, seconds)
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def _esc(path: Path) -> str:
    return str(path).replace("\\", "/").replace(":", "\\:").replace("'", r"\'")
