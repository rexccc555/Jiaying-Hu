"""Edit Plan JSON is the product contract: Source → Transcript → Plan → Renderer."""

from __future__ import annotations

from mpva.captions import pack_cues
from mpva.clean import apply_policy, cuts_from_words, join_text


MODES = ("clean", "social", "enhanced")
COMPONENTS = (
    "Captions",
    "Headline",
    "LowerThird",
    "BigNumber",
    "Quote",
    "ImageCard",
    "Broll",
    "Logo",
    "ProgressBar",
    "Location",
    "SplitScreen",
    "EndCard",
)


def build_edit_plan(
    *,
    source: str,
    clip: dict,
    words: list[dict],
    mode: str = "clean",
    accept_pending: bool = False,
    format_name: str = "9:16",
    brand: dict | None = None,
) -> dict:
    mode = mode if mode in MODES else "clean"
    start = float(clip["start"])
    end = float(clip["end"])
    window = [item for item in words if item["end"] >= start and item["start"] <= end]
    applied = apply_policy(
        window,
        remove_fillers=accept_pending,
        remove_pauses=False,
        remove_repeats=accept_pending,
    )
    if not accept_pending:
        for item in applied:
            if item.get("override") == "cut":
                item["keep"] = False
            elif item.get("override") == "keep":
                item["keep"] = True
            else:
                item["keep"] = True
    keeps = cuts_from_words(applied, threshold_sec=1.5, padding_sec=0.12, total_duration=end)
    keeps = [(max(start, a), min(end, b)) for a, b in keeps if min(end, b) - max(start, a) > 0.12]
    if not keeps:
        keeps = [(start, end)]
    cuts = []
    for item in applied:
        pending = bool(item.get("suggested_cut")) and item.get("override") not in {"cut", "keep"}
        accepted = item.get("keep") is False
        if not pending and not accepted:
            continue
        cuts.append(
            {
                "start": round(float(item["start"]), 3),
                "end": round(float(item["end"]), 3),
                "action": "remove",
                "text": item.get("text") or "",
                "reason": item.get("reason") or item.get("kind") or "cut",
                "status": "accepted" if accepted else "pending",
                "word_id": item.get("id"),
            }
        )
    original = [item for item in window if item.get("kind") != "silence"]
    kept = [item for item in applied if item.get("keep") is not False and item.get("kind") != "silence"]
    captions = pack_cues(remap_captions(kept, keeps))
    duration = round(sum(b - a for a, b in keeps), 3)
    return {
        "version": 1,
        "source": source,
        "clip": {
            "id": clip.get("id"),
            "topic": clip.get("topic") or "",
            "title": clip.get("title") or "",
            "summary": clip.get("summary") or "",
            "start": round(start, 3),
            "end": round(end, 3),
        },
        "cuts": cuts,
        "keep": [{"start": round(a, 3), "end": round(b, 3)} for a, b in keeps],
        "format": format_name,
        "mode": mode,
        "duration": duration,
        "original_transcript": join_text(original),
        "edited_transcript": join_text(kept),
        "captions": captions,
        "visuals": [],
        "brand": brand or {},
        "checks": {
            "quotes_unaltered": True,
            "captions_from_transcript": True,
        },
    }


def remap_captions(words: list[dict], keeps: list[tuple[float, float]]) -> list[dict]:
    out = []
    for item in words:
        if item.get("keep") is False or item.get("kind") == "silence":
            continue
        mapped_start = source_to_cut(float(item["start"]), keeps)
        mapped_end = source_to_cut(float(item["end"]), keeps)
        if mapped_end <= mapped_start:
            mapped_end = mapped_start + 0.06
        text = (item.get("text") or "").strip()
        if not text or text.startswith("["):
            continue
        out.append(
            {
                "text": text,
                "start": round(mapped_start, 3),
                "end": round(mapped_end, 3),
                "emphasis": False,
            }
        )
    return out


def source_to_cut(t: float, keeps: list[tuple[float, float]]) -> float:
    offset = 0.0
    for start, end in keeps:
        if t < start:
            return offset
        if t <= end:
            return offset + (t - start)
        offset += end - start
    return offset


def keep_pairs(plan: dict) -> list[tuple[float, float]]:
    rows = plan.get("keep") or []
    return [(float(row["start"]), float(row["end"])) for row in rows]


def quote_is_safe(quote: str, transcript: str) -> bool:
    needle = " ".join((quote or "").split()).strip().lower()
    hay = " ".join((transcript or "").split()).lower()
    if len(needle) < 4:
        return False
    return needle in hay
