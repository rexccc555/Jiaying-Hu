"""Canonical edit_plan.json — our contract. Renderers and Jianying are adapters."""

from __future__ import annotations

from pathlib import Path

from mpva.captions import pack_cues
from mpva.edit_plan import build_edit_plan


def build_timeline(job: dict, clip: dict) -> dict:
    assets = {item.get("id"): item for item in job.get("assets") or []}
    if clip.get("story"):
        return _from_story(job, clip, assets)
    return _from_speech(job, clip, assets)


def _project(name: str) -> dict:
    return {"name": name or "Rough Cut", "width": 1080, "height": 1920, "fps": 30}


def _clip(
    track: str,
    source: str,
    source_start: float,
    source_end: float,
    timeline_start: float,
    *,
    kind: str = "video",
) -> dict:
    duration = max(0.04, float(source_end) - float(source_start))
    return {
        "track": track,
        "kind": kind,
        "source": source,
        "source_start": round(float(source_start), 3),
        "source_end": round(float(source_end), 3),
        "timeline_start": round(float(timeline_start), 3),
        "duration": round(duration, 3),
    }


def _from_speech(job: dict, clip: dict, assets: dict) -> dict:
    lead = assets.get(clip.get("source_asset") or "") or {}
    source = str(lead.get("path") or job.get("video") or "")
    name = Path(source).name or "speech.mp4"
    window = build_edit_plan(
        source=name,
        clip=clip,
        words=job.get("words") or lead.get("words") or [],
        mode="clean",
        accept_pending=True,
        format_name="9:16",
        brand={},
    )
    timeline = []
    t = 0.0
    for row in window.get("keep") or [{"start": clip.get("start") or 0, "end": clip.get("end") or 0}]:
        start = float(row["start"])
        end = float(row["end"])
        timeline.append(_clip("main", source, start, end, t))
        t += end - start
    title = clip.get("title") or clip.get("topic") or Path(name).stem
    return {
        "version": 2,
        "intent": "interview",
        "project": _project(title),
        "timeline": timeline,
        "captions": window.get("captions") or [],
        "titles": [{"start": 0, "duration": min(3.0, t or 3), "text": title}] if title else [],
        "transcript": window.get("edited_transcript") or "",
        "duration": round(t, 3),
        "notes": "Staff must confirm political copy in Jianying before publishing.",
    }


def _from_story(job: dict, clip: dict, assets: dict) -> dict:
    story = clip.get("story") or {}
    timeline = []
    captions = []
    titles = []
    t_end = 0.0
    for beat in story.get("beats") or []:
        start = float(beat.get("start") or 0)
        end = float(beat.get("end") or start)
        t_end = max(t_end, end)
        audio = beat.get("audio") or {}
        video = beat.get("video") or {}
        if audio.get("path"):
            timeline.append(
                _clip("audio", audio["path"], float(audio.get("in") or 0), float(audio.get("out") or 0), start, kind="audio")
            )
        if video.get("path") and beat.get("jcut"):
            timeline.append(
                _clip("broll", video["path"], float(video.get("in") or 0), float(video.get("out") or 0), start)
            )
        elif video.get("path"):
            timeline.append(
                _clip("main", video["path"], float(video.get("in") or 0), float(video.get("out") or 0), start)
            )
        for photo in beat.get("photos") or []:
            if photo.get("path"):
                timeline.append(_clip("broll", photo["path"], 0, max(0.4, end - start), start, kind="image"))
        if beat.get("headline"):
            titles.append({"start": start, "duration": min(3.0, end - start), "text": beat["headline"]})
        words_id = beat.get("words_from") or (audio.get("asset_id") or "")
        asset = assets.get(words_id) or {}
        src_in = float(audio.get("in") or 0)
        src_out = float(audio.get("out") or src_in)
        for word in asset.get("words") or []:
            if word["end"] <= src_in or word["start"] >= src_out:
                continue
            text = (word.get("text") or "").strip()
            if not text or text.startswith("["):
                continue
            captions.append(
                {
                    "text": text,
                    "start": round(start + max(0.0, float(word["start"]) - src_in), 3),
                    "end": round(start + max(0.06, min(src_out, float(word["end"])) - src_in), 3),
                }
            )
    title = clip.get("title") or story.get("title") or "社区活动"
    packed = pack_cues(captions)
    return {
        "version": 2,
        "intent": "event",
        "project": _project(title),
        "timeline": timeline,
        "captions": packed,
        "titles": titles or [{"start": 0, "duration": 3, "text": title}],
        "transcript": " ".join(item.get("text") or "" for item in packed),
        "duration": round(t_end, 3),
        "notes": "Staff must confirm political copy in Jianying before publishing.",
    }
