"""OpenAI-compatible chat. Any chat model on the gateway works; names are not locked."""

from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request

_LAST_MODEL = ""


def last_model() -> str:
    return _LAST_MODEL


def model_names() -> list[str]:
    raw = os.environ.get("OPENAI_MODEL") or "gpt-4o-mini"
    names = [part.strip() for part in raw.split(",") if part.strip()]
    names = names or ["gpt-4o-mini"]
    strong = [name for name in names if "0613" not in name]
    return strong or names


def configured() -> bool:
    return bool(os.environ.get("OPENAI_API_KEY"))


def _endpoint() -> tuple[str, str]:
    key = os.environ.get("OPENAI_API_KEY") or ""
    if not key:
        raise RuntimeError("OPENAI_API_KEY missing")
    base = (os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
    if not base.endswith("/v1"):
        base += "/v1"
    return key, base


def _chat_model(model: str, system: str, user: str, *, timeout: int, temperature: float) -> str:
    key, base = _endpoint()
    payload = {
        "model": model,
        "temperature": temperature,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    }
    request = urllib.request.Request(
        base + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        data = json.loads(response.read().decode("utf-8"))
    return (((data.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()


def chat(system: str, user: str, *, timeout: int = 90, temperature: float = 0.1) -> str:
    global _LAST_MODEL
    last = ""
    for model in model_names():
        try:
            text = _chat_model(model, system, user, timeout=timeout, temperature=temperature)
            if not text:
                last = f"{model} empty"
                continue
            _LAST_MODEL = model
            return text
        except urllib.error.HTTPError as exc:
            last = f"{model}: {exc.read().decode('utf-8', errors='replace')[:240]}"
        except Exception as exc:
            last = f"{model}: {exc}"
    raise RuntimeError(last or "chat failed")


def _as_json(text: str) -> dict:
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I | re.S).strip()
    match = re.search(r"\{.*\}|\[.*\]", text, flags=re.S)
    if match:
        text = match.group(0)
    parsed = json.loads(text)
    if isinstance(parsed, dict):
        return parsed
    return {"items": parsed}


def chat_json(system: str, user: str, *, timeout: int = 90) -> dict:
    global _LAST_MODEL
    last = ""
    prompt = user + "\nReturn JSON only."
    for model in model_names():
        try:
            text = _chat_model(model, system, prompt, timeout=timeout, temperature=0.1)
            if not text:
                last = f"{model} empty"
                continue
            parsed = _as_json(text)
            _LAST_MODEL = model
            return parsed
        except urllib.error.HTTPError as exc:
            last = f"{model}: {exc.read().decode('utf-8', errors='replace')[:240]}"
        except json.JSONDecodeError as exc:
            last = f"{model} bad json: {exc}"
        except Exception as exc:
            last = f"{model}: {exc}"
    raise RuntimeError(last or "chat json failed")
