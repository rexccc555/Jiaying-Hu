﻿# First run installs a private Python into .venv (no admin needed); later runs just start the app.
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
$port = if ($env:MPVA_PORT) { $env:MPVA_PORT } else { "1780" }
$url = "http://127.0.0.1:$port"

try {
  Invoke-WebRequest "$url/api/env" -UseBasicParsing -TimeoutSec 3 | Out-Null
  Write-Host "MP Video Assistant 已经在运行，正在打开浏览器…"
  Start-Process $url
  exit 0
} catch {}

$python = Join-Path $root ".venv\Scripts\python.exe"
$ready = $false
if (Test-Path $python) {
  & $python -c "import fastapi, uvicorn, multipart, sherpa_onnx" 2>$null
  $ready = $LASTEXITCODE -eq 0
}

if (-not $ready) {
  Write-Host ""
  Write-Host "第一次使用，正在准备运行环境（约 2-5 分钟，只需要一次）…"
  $uv = (Get-Command uv -ErrorAction SilentlyContinue).Source
  if (-not $uv) { $uv = Join-Path $env:USERPROFILE ".local\bin\uv.exe" }
  if (-not (Test-Path $uv)) {
    Write-Host "· 下载安装工具"
    Invoke-RestMethod https://astral.sh/uv/install.ps1 | Invoke-Expression
    $uv = Join-Path $env:USERPROFILE ".local\bin\uv.exe"
  }
  if (-not (Test-Path $python)) {
    Write-Host "· 准备 Python"
    & $uv venv .venv --python 3.12
    if ($LASTEXITCODE -ne 0) { throw "Python 准备失败" }
  }
  Write-Host "· 安装组件"
  & $uv pip install --python $python -r requirements.txt
  if ($LASTEXITCODE -ne 0) { throw "组件安装失败，请检查网络后重新双击 start.bat" }
}

Write-Host ""
Write-Host "MP Video Assistant 已启动：$url"
Write-Host "浏览器会自动打开。使用期间请不要关闭这个窗口。"
Write-Host ""
& $python -m mpva --open
